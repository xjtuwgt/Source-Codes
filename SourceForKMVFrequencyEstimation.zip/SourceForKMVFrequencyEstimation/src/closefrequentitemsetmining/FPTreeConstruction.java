/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package closefrequentitemsetmining;

import KMVSynopsis.FASTKMVConstruction;
import KMVSynopsis.Item;
import java.util.ArrayList;

/**
 *
 * @author String
 */
public class FPTreeConstruction {
    
    public FASTKMVConstruction KMVStruction;
    
    public double s_theta;// Support threshold
    public double s_epsilon;//Close parameters
    public ArrayList s_FrequentItems;
    public int[] s_IndexMap;
    
    public FPTreeConstruction(){
    }
    
    public void FrequentItemIdentification(){
        s_FrequentItems = KMVStruction.ItemList;
        double N = KMVStruction.N;
        int m = s_FrequentItems.size();
        while(m > 0){
            Item item = (Item) s_FrequentItems.get(m);
            double k = item.getK();
            double U_k = item.getKMV();
            double freq = (k/U_k)/N;
            if(freq < (1-s_epsilon)*s_theta){
                s_FrequentItems.remove(m);
            }
            m--;
        }
        
        if(s_FrequentItems.isEmpty()){
            System.out.println("No frequent items found");
            System.exit(0);
        }
    }
    
    public void FrequentItemSorting(){
        
    }
}
