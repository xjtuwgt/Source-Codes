/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package closefrequentitemsetmining;

import KMVSynopsis.Item;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

/**
 *
 * @author String
 */
public class FrequentItemset implements Serializable, Cloneable {

    public ArrayList<KMVSynopsis.Item> s_items = new ArrayList<KMVSynopsis.Item>();
    public int s_support;//K_cap
    public double s_KMV;

    public FrequentItemset(ArrayList<KMVSynopsis.Item> items, int support) {
        s_items = items;
        s_support = support;
        Collections.sort(s_items);
    }

    public void addItem(Item i) {
        s_items.add(i);
        Collections.sort(s_items);
    }

    public void setSupport(int support) {
      s_support = support;
    }
    
    public Collection<Item> getItems() {
      return s_items;
    }
    
    public Item getItem(int index) {
      return s_items.get(index);
    }
    
    public int numberOfItems() {
      return s_items.size();
    }
    
    public Object clone() {
      ArrayList<Item> items = new ArrayList<Item>(s_items);
      return new FrequentItemset(items, s_support);
    }
    
    public String toString() {
        StringBuffer buff = new StringBuffer();
        Iterator<Item> i = s_items.iterator();

//        System.out.println(s_items.size());
        while (i.hasNext()) {
            buff.append(i.next().name + " ");
        }
        buff.append(": " + s_support);
        return buff.toString();
    }
}
