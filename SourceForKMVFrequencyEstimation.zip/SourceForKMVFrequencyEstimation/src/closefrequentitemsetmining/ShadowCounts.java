/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package closefrequentitemsetmining;

import java.util.ArrayList;

/**
 *
 * @author String
 */
public class ShadowCounts {
    private ArrayList<Integer> m_counts = new ArrayList<Integer>();
    //shadowCounts 里面记录的是一个整形数组，利用递归层次作为下表
    
    public int getCount(int recursionLevel) {
        if (recursionLevel >= m_counts.size()) {
            return 0;
        } else {
            return m_counts.get(recursionLevel);
        }
    }
    
    public void increaseCount(int recursionLevel, int incr) {
      // basically treat the list like a stack where we
      // can add a new element, or increment the element
      // at the top，如果递归的层次和m_counts相同，则直接添加，如果递归层次属于中间的，则更新
      
      if (recursionLevel == m_counts.size()) {
        // new element
        m_counts.add(incr);
      } else if (recursionLevel == m_counts.size() - 1) {
        // otherwise increment the top
        int n = m_counts.get(recursionLevel).intValue();
        m_counts.set(recursionLevel, (n + incr));
      }
    }

    //删除某个shadowcount
    public void removeCount(int recursionLevel) {
      if (recursionLevel < m_counts.size()) {
        m_counts.remove(recursionLevel);
      }
    }    
}
