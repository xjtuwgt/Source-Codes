/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package closefrequentitemsetmining;

import KMVSynopsis.FASTOffLineKMVConstructionHugeData;
import KMVSynopsis.FASTOffLineKMVConstructionHugeDataOrder;
import KMVSynopsis.Item;
import fileUtil.fileOperator;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author String
 */
public class FPGrowthMiningOnHugeDataOrder {

    protected double s_minSupport = 0.1;
    protected double s_closeParameter = 0.01;
    protected int s_maxItems = -1;

    public fileOperator s_dataSource;//Read
    public String s_dataSourceName;
    
    public fileOperator s_orderDataSource;
    public String s_dataOrderSourceName;

    public fileOperator s_KMVDataSource;//Write

    public long N = 1000;
    public int K = 200;
    public int tempK = 0;

    public String s_KMVDataSourceName;
    FASTOffLineKMVConstructionHugeDataOrder s_KMVConstructionOrder;

    public void setDataSize(long n) {
        N = n;
    }

    public void setKMVSize(int k) {
        K = k;
    }

    public void setKMVDataSourceName(String fileName) {
        s_KMVDataSourceName = fileName;
    }

    public void setOrderDataSourceName(String fileName){
        s_dataOrderSourceName = fileName;
    }
    
    public void setDataSourceName(String fileName) {
        s_dataSourceName = fileName;
    }
    
    public void setThreshold(double supp){
        this.s_minSupport = supp;
    }
    
    public void setCloseParameter(double closePara){
        this.s_closeParameter = closePara;
    }
    /**
     * Holds the large item sets found
     */
    protected FrequentItemSets m_largeItemSets;

    //===========================================
    public void KMVDataSampling() {
        s_KMVConstructionOrder = new FASTOffLineKMVConstructionHugeDataOrder(N, K, s_dataSourceName, s_dataOrderSourceName, s_KMVDataSourceName);
        s_KMVConstructionOrder.setSeed(seed);
//        double startTime = System.currentTimeMillis();
//        s_KMVConstructionOrder.dataSampleWithReplacementOrder();
        s_KMVConstructionOrder.dataSampleWithReplacementOrderAdded1();
//        s_KMVConstruction.dataSampleWithReplacementAnother();
        s_KMVConstructionOrder.GenerateIDList();
        s_KMVConstructionOrder.InvertSketchConstruction();
        
        System.out.println("Database scanning is completed");
//        double endTime = System.currentTimeMillis();
//        double slapTime = (endTime - startTime) / 1000;
//        System.out.println(slapTime);
    }

//The interface to the KMV synopsis
    protected ArrayList<Item> getSingletons() throws Exception {
        ArrayList<Item> singletons = s_KMVConstructionOrder.ItemList;
//        int count = 0;
        for (int i = 0; i < singletons.size(); i++) {
            Item item = singletons.get(i);
            if(item.K > tempK)
            item.setFrequency();
//            System.out.println(item.K + "\t" + item.getName() + "\t" + item.getKMV());
//            if(item.frequency > s_minSupport * (1 - this.s_closeParameter) * N){
//                count++;
//            }
        }
//        System.out.println("Number of frequent items = " + count + "Support = " + (s_minSupport * (1 - this.s_closeParameter) * N));
        return singletons;
    }

    protected Hashtable<String, Integer> getItemHashtable() {
        Hashtable<String, Integer> itemHashtable = s_KMVConstructionOrder.s_itemHash;
        return itemHashtable;
    }

    protected ArrayList<Item> getOrderedSingletons() throws Exception {
        ArrayList<Item> singletons = s_KMVConstructionOrder.ItemList;
        Collections.sort(singletons);
        for (int i = 0; i < singletons.size(); i++) {
            Item item = singletons.get(i);
            item.setFrequency();
        }
        return singletons;
    }

    protected Hashtable<String, Integer> getSortedItemHashtable(ArrayList<Item> singletons) {
        Hashtable<String, Integer> itemHashtable = new Hashtable<String, Integer>();
        for (int i = 0; i < singletons.size(); i++) {
            Item item = singletons.get(i);
            itemHashtable.put(item.getName(), i);
        }
        return itemHashtable;
    }

    /**
     * Construct the frequent pattern tree by inserting each transaction in the
     * data into the tree. Only those items from each transaction that meet the
     * minimum support threshold are inserted.
     *
     * @param singletons the singleton item sets
     * @param dataFileName the data containing the transactions
     * @param minSupport the minimum support
     * @return the root of the tree
     */
    protected FPTreeRoot buildFPTree(ArrayList<Item> singletons, Hashtable<String, Integer> itemHashtable, String dataFileName) {
        fileOperator fo = new fileOperator();
        fo.openReadFile(dataFileName);

        FPTreeRoot tree = new FPTreeRoot();
        double supportThreshold = s_minSupport * (1 - this.s_closeParameter/2) * N;

        System.out.println("Support threshold = " + supportThreshold);

        String line = fo.readByLine();
        int index = 0;
        while (line != null) {
            String[] tokens = line.split(StaticParameters.splitKey);
            ArrayList<Item> transaction = new ArrayList<Item>();
            for (int i = 0; i < tokens.length; i++) {
                int itemIndex = itemHashtable.get(tokens[i]);
                Item itemi = singletons.get(itemIndex);//如果不用排序了是否会更快
                if (itemi.frequency > supportThreshold) {
                    transaction.add(itemi);
                }
            }
            Collections.sort(transaction);
            tree.addItemSet(transaction, 1);
            transaction.clear();
            transaction = null;
            line = fo.readByLine();
            index++;
        }
        fo.openReadFile(dataFileName);
        return tree;
    }

    protected FPTreeRoot FastBuildFPTree(ArrayList<Item> orderedSingletons, Hashtable<String, Integer> ordereditemHashtable, String dataFileName) {
        fileOperator fo = new fileOperator();
        fo.openReadFile(dataFileName);
        FPTreeRoot tree = new FPTreeRoot();

        double supportThreshold = s_minSupport * (1 - this.s_closeParameter/2) * N;

        String line = fo.readByLine();
        int index = 0;
        while (line != null) {
            String[] tokens = line.split(StaticParameters.splitKey);
            ArrayList<Item> transaction = new ArrayList<Item>();
            for (int i = 0; i < tokens.length; i++) {
                int itemIndex = ordereditemHashtable.get(tokens[i]);
                Item itemi = orderedSingletons.get(itemIndex);//如果不用排序了是否会更快
                if (itemi.frequency > supportThreshold) {
                    transaction.add(itemi);
                }
            }
//            Collections.sort(transaction);
            tree.addItemSet(transaction, 1);
            transaction.clear();
            transaction = null;
            line = fo.readByLine();
            index++;
        }
        fo.openReadFile(dataFileName);
        return tree;
    }

//    /**
//     * Find large item sets in the FP-tree.
//     *
//     * @param tree the root of the tree to mine
//     * @param largeItemSets holds the large item sets found
//     * @param recursionLevel the recursion level for the current projected
//     * counts
//     * @param conditionalItems the current set of items that the current
//     * (projected) tree is conditional on
//     * @param minSupport the minimum acceptable support
//     */
//    protected void mineTree(FPTreeRoot tree, FrequentItemSets largeItemSets,
//            int recursionLevel, FrequentItemset conditionalItems) {
//
//        double minSupport = s_minSupport * (1 - this.s_closeParameter/2) * N;
//
//        if (!tree.isEmpty(recursionLevel)) {
////            if (s_maxItems > 0 && recursionLevel >= s_maxItems) {
////                // don't mine any further
////                return;
////            }
//            Map<Item, HeaderTable> headerTable = tree.getHeaderTable();//获得头表
//            Set<Item> keys = headerTable.keySet();
////      System.err.println("Number of freq item sets collected " + largeItemSets.size());
//            Iterator<Item> i = keys.iterator();
//            while (i.hasNext()) {
//                Item item = i.next();
//                HeaderTable itemHeader = headerTable.get(item);
//                // check for minimum support at this level
//                int support = itemHeader.getProjectedCounts().getCount(recursionLevel);
//                if (support >= minSupport) {
//                    // process header list at this recursion level
//                    for (FPTreeNode n : itemHeader.getHeaderList()) {
//                        // push count up path to root
//                        int currentCount = n.getProjectedCount(recursionLevel);
//                        if (currentCount > 0) {
//                            FPTreeNode temp = n.getParent();
//                            while (temp != tree) {
//                                // set/increase for the node
//                                temp.increaseProjectedCount(recursionLevel + 1, currentCount);
//
//                                // set/increase for the header table
//                                headerTable.get(temp.getItem()).
//                                        getProjectedCounts().increaseCount(recursionLevel + 1, currentCount);
//
//                                temp = temp.getParent();
//                            }
//                        }
//                    }
//
//                    FrequentItemset newConditional = (FrequentItemset) conditionalItems.clone();
//
//                    // this item gets added to the conditional items
//                    newConditional.addItem(item);
//                    newConditional.setSupport(support);
//
//                    // now add this conditional item set to the list of large item sets
//                    largeItemSets.addItemSet(newConditional);
//
//                    // now recursively process the new tree
//                    mineTree(tree, largeItemSets, recursionLevel + 1, newConditional);
//
//                    // reverse the propagated counts
//                    for (FPTreeNode n : itemHeader.getHeaderList()) {
//                        FPTreeNode temp = n.getParent();
//                        while (temp != tree) {
//                            temp.removeProjectedCount(recursionLevel + 1);
//                            temp = temp.getParent();
//                        }
//                    }
//
//                    // reverse the propagated counts in the header list
//                    // at this recursion level
//                    for (HeaderTable h : headerTable.values()) {
//                        h.getProjectedCounts().removeCount(recursionLevel + 1);
//                    }
//                }
//            }
//        }
//    }

    /**
     * Find large item sets in the FP-tree.
     *
     * @param tree the root of the tree to mine
     * @param largeItemSets holds the large item sets found
     * @param recursionLevel the recursion level for the current projected
     * counts
     * @param conditionalItems the current set of items that the current
     * (projected) tree is conditional on
     * @param minSupport the minimum acceptable support
     */
    protected void mineKMVTree(FPTreeRoot tree, FrequentItemSets largeItemSets,
            int recursionLevel, FrequentItemset conditionalItems) {

        double minSupport = s_minSupport * (1 - this.s_closeParameter/2) * N;

        if (!tree.isEmpty(recursionLevel)) {
//            if (s_maxItems > 0 && recursionLevel >= s_maxItems) {
//                // don't mine any further
//                return;
//            }
            Map<Item, HeaderTable> headerTable = tree.getHeaderTable();//获得头表
            Set<Item> keys = headerTable.keySet();
//      System.err.println("Number of freq item sets collected " + largeItemSets.size());
            Iterator<Item> i = keys.iterator();
            while (i.hasNext()) {
                Item item = i.next();
                HeaderTable itemHeader = headerTable.get(item);
                // check for minimum support at this level
//                int support = itemHeader.getProjectedCounts().getCount(recursionLevel);//递归的层次应该和KMV的value值相对应
                int K = itemHeader.getProjectedCounts().getCount(recursionLevel);
                if (K < tempK) {
                    continue;
                }
                //Added by Wang
                double KMV = itemHeader.getProjectedKMVs().getKMV(recursionLevel);//获取对应的KMV
                double support = K / KMV;//Estimated support

                if (support >= minSupport) {
                    // process header list at this recursion level
                    for (FPTreeNode n : itemHeader.getHeaderList()) {
                        // push count up path to root
                        int currentCount = n.getProjectedCount(recursionLevel);
                        double currentKMV = n.getProjectedKMV(recursionLevel);
                        if (currentCount > 0) {
                            FPTreeNode temp = n.getParent();
                            while (temp != tree) {
                                // set/increase for the node
                                temp.increaseProjectedCount(recursionLevel + 1, currentCount);
                                //Added by Wang
                                temp.updateProjectedKMV(recursionLevel + 1, currentKMV);

                                // set/increase for the header table
                                headerTable.get(temp.getItem()).
                                        getProjectedCounts().increaseCount(recursionLevel + 1, currentCount);

                                //Added by Wang
                                headerTable.get(temp.getItem()).getProjectedKMVs().updateKMV(recursionLevel + 1, currentKMV);

                                temp = temp.getParent();
                            }
                        }
                    }

                    FrequentItemset newConditional = (FrequentItemset) conditionalItems.clone();

                    // this item gets added to the conditional items
                    newConditional.addItem(item);
                    newConditional.setSupport((int) support);

                    // now add this conditional item set to the list of large item sets
                    largeItemSets.addItemSet(newConditional);

                    // now recursively process the new tree
                    mineKMVTree(tree, largeItemSets, recursionLevel + 1, newConditional);

                    // reverse the propagated counts
                    for (FPTreeNode n : itemHeader.getHeaderList()) {
                        FPTreeNode temp = n.getParent();
                        while (temp != tree) {
                            temp.removeProjectedCount(recursionLevel + 1);
                            temp = temp.getParent();
                        }
                    }

                    // reverse the propagated KMVs
                    for (FPTreeNode n : itemHeader.getHeaderList()) {
                        FPTreeNode temp = n.getParent();
                        while (temp != tree) {
                            temp.removeProjectedKMV(recursionLevel + 1);
//                            temp.removeProjectedCount(recursionLevel + 1);
                            temp = temp.getParent();
                        }
                    }

                    // reverse the propagated counts in the header list
                    // at this recursion level
                    for (HeaderTable h : headerTable.values()) {
                        h.getProjectedCounts().removeCount(recursionLevel + 1);
                    }

                    // reverse the propagated KMVs in the header list
                    // at this recursion level
                    for (HeaderTable h : headerTable.values()) {
                        h.getProjectedKMVs().removeKMV(recursionLevel + 1);
                    }
                }
            }
        }
    }

    public void FPGrowthMiningProcess() throws Exception {
        if(K > 0){
            tempK = (int) (K*this.s_minSupport*((1 + this.s_closeParameter/100)));
//            tempK = (int) (K*this.s_minSupport);
        }
        KMVDataSampling();
        ArrayList<Item> singletons = getSingletons();
        Hashtable<String, Integer> itemHashtable = getItemHashtable();
        FPTreeRoot tree = buildFPTree(singletons, itemHashtable, s_KMVDataSourceName);
        FrequentItemSets largeItemSets = new FrequentItemSets((int) N);
        // mine the tree
        FrequentItemset conditionalItems = new FrequentItemset(new ArrayList<Item>(), 0);
        System.out.println("Tree construction is completed...");
        mineKMVTree(tree, largeItemSets, 0, conditionalItems);
//        mineTree(tree, largeItemSets, 0, conditionalItems);
        tree = null;
        m_largeItemSets = largeItemSets;
        System.out.println("Support threshold: " + this.s_minSupport*(1- this.s_closeParameter/2)*N);
        System.out.println("Number of frequent itemsets mined: " + m_largeItemSets.size());
        System.out.println("=============================================");
//        for(int i = 0; i < m_largeItemSets.size(); i++){
//            System.out.println(m_largeItemSets.getItemSet(i).toString());
//        }
       
    }

    public void saveAllFrequentItems(String fileName) throws IOException {
        fileOperator fo = new fileOperator();
                File file = new File(fileName);
        if(!file.exists()){
            file.createNewFile();
        }
        fo.openWriteFile(fileName);
        for (int i = 0; i < m_largeItemSets.size(); i++) {
            fo.writeFile(m_largeItemSets.getItemSet(i).toString());
        }
        fo.closeWriteFile();
    }
    

    public static void main(String[] args) throws Exception {
//        String fileName = "IBM_BigData";
String fileName = "tweets_RemoveII";
String oFileName = "SRO";
//long N = 366947989;
long N = 13445364;
String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewDataSets\\Orig\\";
String orderFilePath ="C:\\Users\\String\\Document Sources\\FIM Datasets\\NewDataSets\\VaryOrder\\TweetOrder\\";
//String orderFilePath ="C:\\Users\\String\\Document Sources\\FIM Datasets\\NewDataSets\\VaryOrder\\RetailOrder\\";
//        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\";
//        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\";
//        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\";
String orderFileName = orderFilePath + oFileName + ".txt";
        String sourceFileName = filePath + fileName + ".txt";
        String KMVFileName = filePath + "KMVSampleData\\KMV_"+ fileName + N+ ".data";
        
        double threshold = 0.01;
        double closeParameter = 0.1;
//long N = 366947989;
//        long N = 13445364;
//        int  K = 111955;
// long N = 13445364;
//        double  B =   13445364;
//        int K = (int) (B/100000);
//        int K = (int) (B/100);
//int K = 171956;
int K = 111955;
        
        double[] runtimes = new double[10];
        for (int i = 0; i < 10; i++) {
            seed = i + 1;
            System.out.println("Run pass ==============" + (i + 1));
            double startTime = System.currentTimeMillis();
            FPGrowthMiningOnHugeDataOrder fpGrowth = new FPGrowthMiningOnHugeDataOrder();
            fpGrowth.setDataSourceName(sourceFileName);
            fpGrowth.setKMVDataSourceName(KMVFileName);
            fpGrowth.setOrderDataSourceName(orderFileName);
            fpGrowth.setDataSize(N);
            fpGrowth.setKMVSize(K);
            fpGrowth.setThreshold(threshold);
            fpGrowth.setCloseParameter(closeParameter);
            fpGrowth.FPGrowthMiningProcess();

            double endTime = System.currentTimeMillis();
            double slapTime = (endTime - startTime) / 1000;
            System.out.println("Runtime = " + slapTime);
            runtimes[i] = slapTime; 
            String resultFile = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewResutls-Added\\KOrder\\Tweet\\" + fileName + "_" + oFileName+ N + "KMV_K =" + K + "_support_" + threshold + "_close_" + closeParameter + "_Seed_" + seed + ".dat";
            fpGrowth.saveAllFrequentItems(resultFile);
            
            
        }
            for(int i = 0; i < 10; i++){
            System.out.println(runtimes[i]);
        }    
            saveRuntime("C:\\Users\\String\\Document Sources\\FIM Datasets\\NewResutls-Added\\KOrder\\Tweet\\"+ fileName + "_" + oFileName + K + "_" + N +"_" + threshold + "_" + closeParameter + ".txt", runtimes);
    }
    
        public static void saveRuntime(String fileName, double[] runtimes) throws IOException{
                File file = new File(fileName);
        if(!file.exists()){
            file.createNewFile();
        }
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        for(int i = 0; i < runtimes.length; i++){
            fo.writeFile(runtimes[i]+"");
        }
        fo.closeWriteFile();
    }
    
    public static long seed = 1;
    
//======================testing==================================
    public void RunFPGrowth() throws Exception {
        KMVDataSampling();
        ArrayList<Item> singletons = getSingletons();
        Hashtable<String, Integer> itemHashtable = getItemHashtable();
        FPTreeRoot tree = buildFPTree(singletons, itemHashtable, s_KMVDataSourceName);

        FrequentItemSets largeItemSets = new FrequentItemSets((int) N);
        // mine the tree
        FrequentItemset conditionalItems = new FrequentItemset(new ArrayList<Item>(), 0);
        mineKMVTree(tree, largeItemSets, 0, conditionalItems);
    }

    public void FastRunFPGrowth() throws Exception {
        KMVDataSampling();
        ArrayList<Item> singletons = this.getOrderedSingletons();
        Hashtable<String, Integer> itemHashtable = this.getSortedItemHashtable(singletons);
        FastBuildFPTree(singletons, itemHashtable, s_KMVDataSourceName);
    }    

}
