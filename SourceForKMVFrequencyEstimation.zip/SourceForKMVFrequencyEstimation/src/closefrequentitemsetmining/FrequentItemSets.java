/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package closefrequentitemsetmining;

import KMVSynopsis.Item;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;


/**
 *
 * @author String
 */
public class FrequentItemSets implements Serializable {
    protected ArrayList<FrequentItemset> s_sets = new ArrayList<FrequentItemset>();
    protected int s_numberOfTransactions;

    public FrequentItemSets(int numTransactions) {
        s_numberOfTransactions = numTransactions;
    }
    
    public FrequentItemset getItemSet(int index) {
        return s_sets.get(index);
    }
    
    public Iterator<FrequentItemset> iterator() {
      return s_sets.iterator();
    }
    
    public int getNumberOfTransactions() {
      return s_numberOfTransactions;
    }

    public void addItemSet(FrequentItemset setToAdd) {
      s_sets.add(setToAdd);
    }
    
    public void sort(Comparator<FrequentItemset> comp) {
      Collections.sort(s_sets, comp);
    }

    public int size() {
      return s_sets.size();
    }


    public void sort() {
      Comparator<FrequentItemset> compF = new Comparator<FrequentItemset>() {
        public int compare(FrequentItemset one, FrequentItemset two) {
          Collection<Item> compOne = one.getItems();
          Collection<Item> compTwo = two.getItems();
          
//          if (one.getSupport() == two.getSupport()) {
            // if supports are equal then list shorter item sets before longer ones
            if (compOne.size() < compTwo.size()) {
              return -1;
            } else if (compOne.size() > compTwo.size()) {
              return 1;
            } else {
              // compare items
              Iterator<Item> twoIterator = compTwo.iterator();
              for (Item oneI : compOne) {
                Item twoI = twoIterator.next();
                int result = oneI.compareTo(twoI);
                if (result != 0) {
                  return result;
                }
              }
              return 0; // equal
            }
            
//            return 0;
    /*      } else if (one.getSupport() > two.getSupport()) {
            // reverse ordering (i.e. descending by support)
            return -1;
          } */
          
    //      return 1;
        }
      };
      
      sort(compF);
    }
    
    
}
