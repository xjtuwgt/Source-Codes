/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package closefrequentitemsetmining;

import KMVSynopsis.Item;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 * @author String
 */
public class FPTreeNode implements Serializable {
    /** link to another sibling at this level in the tree */
    protected FPTreeNode s_levelSibling;
    protected FPTreeNode s_parent;//父节点，只有一个
    /** item at this node */
    protected Item s_item;//当前节点的信息
    
    /** ID (for graphing the tree) */
    protected int s_ID;

    protected Map<Item, FPTreeNode> s_children = new HashMap<Item, FPTreeNode>();//孩子节点，map结构，将item和TreeNode联系起来
    /** counts associated with projected versions of this node */
    protected ShadowCounts s_projectedCounts = new ShadowCounts();
    protected ShadowKMVs s_projectedKMVs = new ShadowKMVs();
    
   /**
     * Construct a new node with the given parent link and item.
     * 
     * @param parent a pointer to the parent of this node.
     * @param item the item at this node.
     */
    public FPTreeNode(FPTreeNode parent, Item item) {//父节点和item构成当前树节点
      s_parent = parent;
      s_item = item;
    }
    
 /**
     * Insert an item set into the tree at this node. Removes the first item
     * from the supplied item set and makes a recursive call to insert the
     * remaining items.
     * 
     * @param itemSet the item set to insert.要往当前树种插入的itemset
     * @param headerTable the header table for the tree.头表
     * @param incr the amount by which to increase counts.需要给当前树节点添加的计数
     */
    public void addItemSet(Collection<Item> itemSet, Map<Item, HeaderTable> headerTable, int incr) {
     
      Iterator<Item> i = itemSet.iterator();//itemSet,有序的
      
      if (i.hasNext()) {
        Item first = i.next();//得到第一个
        
        FPTreeNode aChild;
        if (!s_children.containsKey(first)) {//如果孩子里面没有这个item
          // not in the tree, so add it.
          aChild = new FPTreeNode(this, first);//新建一个树节点
          s_children.put(first, aChild);//添加到孩子节点数组中
          
          // update the header
          if (!headerTable.containsKey(first)) {//头表中没有这个元素
            headerTable.put(first, new HeaderTable());//在头表中构建一个item和头表的映射
          }
          
          // append new node to header list
          headerTable.get(first).addToList(aChild);//将item相同的用linkedlist连接起来
        } else {
          // get the appropriate child node
          aChild = s_children.get(first);//孩子节点中已经有这个元素，则取出这个孩子节点
        }
        
        // update counts in header table 0 头表中的递归层次为0
        headerTable.get(first).getProjectedCounts().increaseCount(0, incr);//头表中first item对应的count增加
       //Added by Wang
        headerTable.get(first).getProjectedKMVs().updateKMV(0, first.KMV);
        
        // increase the child's count给孩子节点的计数增加，递归层次为0
        aChild.increaseProjectedCount(0, incr);
        aChild.updateProjectedKMV(0, first.KMV);
        
        // proceed recursively
        itemSet.remove(first);//删除第一个节点，继续处理        
        aChild.addItemSet(itemSet, headerTable, incr);
      }
    }    

    /**
     * Increase the projected count at the given recursion level at this
     * node
     * 
     * @param recursionLevel the recursion level to increase the node count
     * at.
     * @param incr the amount by which to increase the count.
     */
    public void increaseProjectedCount(int recursionLevel, int incr) {
      s_projectedCounts.increaseCount(recursionLevel, incr);
    }
    
    /**
     * Remove the projected count at the given recursion level for this
     * node.
     * 
     * @param recursionLevel the recursion level at which to remove the count.
     */
    public void removeProjectedCount(int recursionLevel) {
      s_projectedCounts.removeCount(recursionLevel);
    }
    
    
    //Added by Wang
    public void updateProjectedKMV(int recursionLevel, double kmv) {
      s_projectedKMVs.updateKMV(recursionLevel, kmv);
    }
    
    /**
     * Remove the projected count at the given recursion level for this
     * node.
     * 
     * @param recursionLevel the recursion level at which to remove the count.
     */
    public void removeProjectedKMV(int recursionLevel) {
      s_projectedKMVs.removeKMV(recursionLevel);
    }  

    /**
     * Get the projected count at the given recursion level for this node.
     * 
     * @param recursionLevel the recursion level at which to get the count.
     * @return the count.
     */
    public int getProjectedCount(int recursionLevel) {
      return s_projectedCounts.getCount(recursionLevel);
    }
    
    public double getProjectedKMV(int recursionLevel) {
      return s_projectedKMVs.getKMV(recursionLevel);
    }
    
    public FPTreeNode getParent() {
      return s_parent;
    }
    
    /**
     * Get the item at this node.
     * 
     * @return the item at this node.
     */
    public Item getItem() {
      return s_item;
    }


    protected int assignIDs(int lastID) {
      int currentLastID = lastID + 1;
      s_ID = currentLastID;
      if (s_children != null) {
        Collection<FPTreeNode> kids = s_children.values();
        for (FPTreeNode n : kids) {
          currentLastID = n.assignIDs(currentLastID);
        }
      }
      return currentLastID;
    }    
}
