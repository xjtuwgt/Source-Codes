/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package closefrequentitemsetmining;

import java.util.ArrayList;

/**
 *
 * @author String
 */
public class ShadowKMVs {
    private ArrayList<Double> s_KMVs = new ArrayList<Double>();
    
    public double getKMV(int recursionLevel){
        if(recursionLevel >= s_KMVs.size()){
            return 0;
        }else{
            return s_KMVs.get(recursionLevel);
        }
    }
    
    public void updateKMV(int recursionLevel, double kmv){
        if(recursionLevel == s_KMVs.size()){
            s_KMVs.add(kmv);
        }else if(recursionLevel == s_KMVs.size() - 1){
            double d = s_KMVs.get(recursionLevel).doubleValue();
            if(d < kmv){
                s_KMVs.set(recursionLevel, kmv);
            }
        }
    }
    
    public void removeKMV(int recursionLevel){
        if(recursionLevel < s_KMVs.size()){
            s_KMVs.remove(recursionLevel);
        }
    }
}
