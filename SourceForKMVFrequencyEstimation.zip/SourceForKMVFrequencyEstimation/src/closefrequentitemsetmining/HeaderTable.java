/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package closefrequentitemsetmining;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author String
 */
public class HeaderTable {
    protected List<FPTreeNode> s_headerList = new LinkedList<FPTreeNode>();
    //Headtable 首先有headerList是由树中的节点构成的一个连接结构
    /**
     * Projected header counts for this entry, 投影到这个entry的计数
     */
    protected ShadowCounts s_projectedHeaderCounts = new ShadowCounts();
    
    protected ShadowKMVs s_projectedHeaderKMVs = new ShadowKMVs();
/**
       * Add a tree node into the list for this header entry.
       * 
       * @param toAdd the node to add.
       */
      public void addToList(FPTreeNode toAdd) {
        s_headerList.add(toAdd);
      }
      
      /**
       * Get the list of nodes for this header entry.
       * 
       * @return the list of nodes for this header entry.
       */
      public List<FPTreeNode> getHeaderList() {
        return s_headerList;
      }
      
      /**
       * Get the projected counts for this header entry.
       * 
       * @return the projected counts for this header entry.
       */
      public ShadowCounts getProjectedCounts() {
        return s_projectedHeaderCounts;
      }
      
      /**
       * Get the projected counts for this header entry.
       * 
       * @return the projected counts for this header entry.
       */
      public ShadowKMVs getProjectedKMVs() {
        return s_projectedHeaderKMVs;
      }       
}
