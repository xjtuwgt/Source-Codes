/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package closefrequentitemsetmining;

import KMVSynopsis.FASTKMVConstruction;
import KMVSynopsis.Item;
import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author String
 */
public class FPGrowthMining {

    protected double s_minSupport = 0.1;
    protected double s_closeParameter = 0.01;
    protected int s_maxItems = -1;
    
    
    public fileOperator s_dataSource;//Read
    public String s_dataSourceName;

    public fileOperator s_KMVDataSource;//Write
    public String s_KMVDataSourceName;
    FASTKMVConstruction s_KMVConstruction;
    
    public void setKMVDataSourceName(String fileName){
        
    }
    /**
     * Holds the large item sets found
     */
    protected FrequentItemSets m_largeItemSets;

//The interface to the KMV synopsis
    protected ArrayList<Item> getSingletons() throws Exception {
        ArrayList<Item> singletons = new ArrayList<Item>();
        return singletons;
    }

    /**
     * Construct the frequent pattern tree by inserting each transaction in the
     * data into the tree. Only those items from each transaction that meet the
     * minimum support threshold are inserted.
     *
     * @param singletons the singleton item sets
     * @param data the Instances containing the transactions
     * @param minSupport the minimum support
     * @return the root of the tree
     */
    protected FPTreeRoot buildFPTree(ArrayList<Item> singletons,
            String dataFileName, int minSupport) {

        fileOperator fo = new fileOperator();
        fo.openReadFile(dataFileName);
        FPTreeRoot tree = new FPTreeRoot();
        
        String line = fo.readByLine();
        int index = 0;
        while (line != null) {
            String[] tokens = line.split(",");
            ArrayList<Item> transaction = new ArrayList<Item>();//?????
            Collections.sort(transaction);
            tree.addItemSet(transaction, 1);
            line = fo.readByLine();
            index++;
        }
//        for (int i = 0; i < data.numInstances(); i++) {
//            Instance current = data.instance(i);
//            ArrayList<Item> transaction = new ArrayList<Item>();
//            if (current instanceof SparseInstance) {
//                for (int j = 0; j < current.numValues(); j++) {
//                    int attIndex = current.index(j);
//                    if (singletons.get(attIndex).getFrequency() >= minSupport) {
//                        transaction.add(singletons.get(attIndex));
//                    }
//                }
//                Collections.sort(transaction);
//                tree.addItemSet(transaction, 1);
//            } else {
//                for (int j = 0; j < data.numAttributes(); j++) {
//                    if (!current.isMissing(j)) {
//                        if (current.attribute(j).numValues() == 1
//                                || current.value(j) == m_positiveIndex - 1) {
//                            if (singletons.get(j).getFrequency() >= minSupport) {
//                                transaction.add(singletons.get(j));
//                            }
//                        }
//                    }
//                }
//                Collections.sort(transaction);
//                tree.addItemSet(transaction, 1);
//            }
//        }
        fo.openReadFile(dataFileName);
        return tree;
    }
    
    
 protected void mineTree(FPTreeRoot tree, FrequentItemSets largeItemSets, 
      int recursionLevel, FrequentItemset conditionalItems, int minSupport) {
    
    if (!tree.isEmpty(recursionLevel)) {
      if (s_maxItems > 0 && recursionLevel >= s_maxItems) {
        // don't mine any further
        return;
      }
      
      Map<Item, HeaderTable> headerTable = tree.getHeaderTable();
      Set<Item> keys = headerTable.keySet();
//      System.err.println("Number of freq item sets collected " + largeItemSets.size());
      Iterator<Item> i = keys.iterator();
      while (i.hasNext()) {
        Item item = i.next();
        HeaderTable itemHeader = headerTable.get(item);
        
        // check for minimum support at this level
        int support = itemHeader.getProjectedCounts().getCount(recursionLevel);
        if (support >= minSupport) {          
          // process header list at this recursion level
          for (FPTreeNode n : itemHeader.getHeaderList()) {
            // push count up path to root
            int currentCount = n.getProjectedCount(recursionLevel);
            if (currentCount > 0) {                            
              FPTreeNode temp = n.getParent();
              while (temp != tree) {
                // set/increase for the node
                temp.increaseProjectedCount(recursionLevel + 1, currentCount);

                // set/increase for the header table
                headerTable.get(temp.getItem()).
                getProjectedCounts().increaseCount(recursionLevel + 1, currentCount);
                
                temp = temp.getParent();
              }
            }
          }
          
          FrequentItemset newConditional = (FrequentItemset) conditionalItems.clone();
          
          // this item gets added to the conditional items
          newConditional.addItem(item);
          newConditional.setSupport(support);
          
          // now add this conditional item set to the list of large item sets
          largeItemSets.addItemSet(newConditional);
          
          // now recursively process the new tree
          mineTree(tree, largeItemSets, recursionLevel + 1, newConditional,
              minSupport);
          
          // reverse the propagated counts
          for (FPTreeNode n : itemHeader.getHeaderList()) {
            FPTreeNode temp = n.getParent();
            while (temp != tree) {
              temp.removeProjectedCount(recursionLevel + 1);
              temp = temp.getParent();
            }
          }
          
          // reverse the propagated counts in the header list
          // at this recursion level
          for (HeaderTable h : headerTable.values()) {
            h.getProjectedCounts().removeCount(recursionLevel + 1);
          }          
        }
      }
    }
  }
 
 
 public void FPGrowthMiningProcess(String dataSoureFile, long N) throws Exception {
    int lowerBoundMinSuppAsInstances = (s_minSupport > 1)
    ? (int)s_minSupport : (int)Math.ceil(s_minSupport * N);    
    double currentSupport = s_minSupport;

    // first compute singletons
    ArrayList<Item> singletons = getSingletons();
    // while not enough rules
    
      int currentSupportAsInstances = (currentSupport > 1)
      ? (int)currentSupport
      : (int)Math.ceil(currentSupport * N);
      
      //System.err.println("Current support " + currentSupportAsInstances);
      //ArrayList<BinaryItem> prunedSingletons = removeNonFrequent(singletons);

      // build the FPTree
      FPTreeRoot tree = buildFPTree(singletons, dataSoureFile, currentSupportAsInstances);
//System.out.println("Finished building tree...");
//System.out.println(tree.toString(0));
    /*System.out.println(tree.printHeaderTable(0)); */

      FrequentItemSets largeItemSets = new FrequentItemSets((int) N);
      // mine the tree
      FrequentItemset conditionalItems = 
        new FrequentItemset(new ArrayList<Item>(), 0);
      mineTree(tree, largeItemSets, 0, conditionalItems, currentSupportAsInstances);      
      m_largeItemSets = largeItemSets;
      tree = null;
  } 
    
}
