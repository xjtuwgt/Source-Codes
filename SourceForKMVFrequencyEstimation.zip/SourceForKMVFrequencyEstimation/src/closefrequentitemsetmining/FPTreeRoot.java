/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package closefrequentitemsetmining;

import KMVSynopsis.Item;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author String
 */
public class FPTreeRoot extends FPTreeNode {
    
    
    protected Map<Item, HeaderTable> s_headerTable = new HashMap<Item, HeaderTable>();//根节点将item和对应的headerTable映射起来
    
    
    /**
     * Create a new FPTreeRoot.
     */
    public FPTreeRoot() {
      super(null, null);
    }

    /**
     * Insert an item set into the tree.
     * 
     * @param itemSet the item set to insert into the tree.
     * @param incr the increment by which to increase counters.
     */
    public void addItemSet(Collection<Item> itemSet, int incr) {
      super.addItemSet(itemSet, s_headerTable, incr);
    }
    
    /**
     * Get the header table for this tree.
     * 
     * @return the header table for this tree.
     */
    public Map<Item, HeaderTable> getHeaderTable() {
      return s_headerTable;
    }
    
    public boolean isEmpty(int recursionLevel) {
      for (FPTreeNode c : s_children.values()) {
        if (c.getProjectedCount(recursionLevel) > 0) {
          return false;
        }
      }
      return true;
    }    
}
