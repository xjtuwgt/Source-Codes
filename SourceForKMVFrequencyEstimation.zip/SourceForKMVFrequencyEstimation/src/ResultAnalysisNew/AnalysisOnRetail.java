/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysisNew;

import ResultAnalysis.FrequentItemset;
import fileUtil.fileHandle;
import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**
 *
 * @author String
 */
public class AnalysisOnRetail {
    
    public class ItemSetInformation {

        public HashMap<String, Integer> hashMap;
        public ArrayList<FrequentItemset> arrayList;

        public ItemSetInformation() {
            hashMap = new HashMap();
            arrayList = new ArrayList();
        }
    }
    
    
    public static String trueFilePath = "C:\\Users\\String\\Document Sources\\"
            + "FIM Datasets\\NewExperimentalResults\\AllResults\\Retail\\";
//    public static String minedFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewExperimentalResults\\Retail\\K\\";
    public static String minedFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewExperimentalResults\\VarySize\\Retail\\A\\";
    public static int N = 13445364;
    public static boolean flag = false;
//    public static boolean isSample = false;
    
    public static void main(String[] args){
        fileHandle fh = new fileHandle();
        String[] trueFileNames = fh.getFileNames(trueFilePath, "dat", true);
        String[] minedFileNames = fh.getFileNames(minedFilePath, "dat", true);
        for(int i = 0; i < trueFileNames.length; i++){
            AnalysisOnRetail AOT = new AnalysisOnRetail(); 
            String trueFileNamei = trueFileNames[i];
//            System.out.println(trueFileNamei);
            ItemSetInformation trueItemsets = AOT.AllHashLoading(trueFilePath + trueFileNamei + ".dat");
            double d = AOT.supportExtraction(trueFileNamei);
            for(int j = 0; j < minedFileNames.length; j++){
                String minedFileNamej = minedFileNames[j];
                String suppTemp = "support_"+d;
//                System.out.println(suppTemp);
                if(minedFileNamej.contains(suppTemp)){
                    ItemSetInformation minedItemsets = AOT.SingleLoading(minedFilePath + minedFileNamej + ".dat");
                    double k = AOT.ExtractNumber(minedFileNamej);
//                    if(k==268){
                    double ratio = N/k;
                    double[] resultj = AOT.ComputeRecallAndPrecision(trueItemsets, minedItemsets);
                    System.out.println(k + "\t" + d + "\t" + resultj[0] + "\t" + resultj[1]);
//                    double[] result10 = AOT.ComputeRecallAndPrecision(trueItemsets, minedItemsets, 10);
//                    double error10 = AOT.ComputeMRSE(trueItemsets, minedItemsets, flag, 10, ratio);
//                    double[] result20 = AOT.ComputeRecallAndPrecision(trueItemsets, minedItemsets, 20);
//                    double error20 = AOT.ComputeMRSE(trueItemsets, minedItemsets, flag, 20, ratio);
//                    double[] result50 = AOT.ComputeRecallAndPrecision(trueItemsets, minedItemsets, 50);
//                    double error50 = AOT.ComputeMRSE(trueItemsets, minedItemsets, flag, 50, ratio);
//                    double[] result100 = AOT.ComputeRecallAndPrecision(trueItemsets, minedItemsets, 100);
//                    double error100 = AOT.ComputeMRSE(trueItemsets, minedItemsets, flag, 100, ratio);
//                    double[] result150 = AOT.ComputeRecallAndPrecision(trueItemsets, minedItemsets, 150);
//                    double error150 = AOT.ComputeMRSE(trueItemsets, minedItemsets, flag, 150, ratio);
//                    System.out.println(k + "\t" + d + "\t" + resultj[0] + "\t" + resultj[1] + "\t" + error10 + "\t" + result10[0]+"\t"+
//                            error20 + "\t" + result20[0]+"\t"+ error50 + "\t" + result50[0]+"\t"+ error100 + "\t" + result100[0]+"\t"+ error150 + "\t" + result150[0]);
                    }
                    
//                }
            }
        }
    }
    
    public double supportExtraction(String allFileName){
        String[] tokens = allFileName.split("_");
        for(int i = 0; i < tokens.length; i++){
            if(tokens[i].trim().equals("support")){
                double d = Double.parseDouble(tokens[i+1].trim());
                return d;
            }
        }
        return -1;
    }
    
    public double[] ComputeRecallAndPrecision(ItemSetInformation trueFreqItemset, ItemSetInformation minedFreqItemset){
        double precision = 0;
        double recall = 0;
        int count = 0;
        double R = minedFreqItemset.arrayList.size();
        double T = trueFreqItemset.arrayList.size();
        for(int i = 0; i < minedFreqItemset.arrayList.size(); i++){
            FrequentItemset freqItemseti = minedFreqItemset.arrayList.get(i);
            String itemset = freqItemseti.itemset;
            if(trueFreqItemset.hashMap.containsKey(itemset)){
                count++;
            }
        }
//        System.out.println(count + "\t" + R + "\t" + T);
        precision = count/R;
        recall = count/T;
        double[] results = new double[2];
        results[0] = precision;
        results[1] = recall;
        return results;
    }
    
        public double[] ComputeRecallAndPrecision(ItemSetInformation trueFreqItemset, ItemSetInformation minedFreqItemset, int K){
        double precision = 0;
        double recall = 0;
        double count = 0;
            //        sortFrequentItemset(trueFreqItemset);
        sortFrequentItemset(minedFreqItemset);
        double R = minedFreqItemset.arrayList.size();
        double T = trueFreqItemset.arrayList.size();
        for(int i = 0; i < K; i++){
            FrequentItemset freqItemseti = minedFreqItemset.arrayList.get(i);
            String itemset = freqItemseti.itemset;
            if(trueFreqItemset.hashMap.containsKey(itemset)){
                count++;
            }
        }
//        System.out.println(count + "\t" + R + "\t" + T);
        precision = count/K;
        recall = count/K;
        double[] results = new double[2];
        results[0] = precision;
        results[1] = recall;
        return results;
    }
    
    public double ComputeMRSE(ItemSetInformation trueFreqItemset, ItemSetInformation minedFreqItemset, boolean flag, int K, double ratio){
        double mrse = 0;
//        sortFrequentItemset(trueFreqItemset);
        sortFrequentItemset(minedFreqItemset);
        double[] trueCounts = new double[K];
        double[] mineCounts = new double[K];
        for(int i = 0; i < K; i++){
            FrequentItemset freqItemseti = minedFreqItemset.arrayList.get(i);
            if(flag)
            mineCounts[i] = freqItemseti.count*ratio;
            else
                mineCounts[i] = freqItemseti.count;
            if(trueFreqItemset.hashMap.containsKey(freqItemseti.itemset)){
                trueCounts[i] = trueFreqItemset.hashMap.get(freqItemseti.itemset);
            }
        }
        mrse = estimationError(trueCounts, mineCounts);
        return mrse;
    }    
    
    public double ExtractNumber(String fileName) {
        String[] tokens = fileName.split("_");
        for (int i = 0; i < tokens.length; i++) {
            if (tokens[i].contains("=")) {
                String[] subtokens = tokens[i].split("=");
                double num = Double.parseDouble(subtokens[1].trim());
                return num;
            }
        }
        return -1;
    }
    
    public double estimationError(double[] trueCounts, double[] minedCounts){
        double mrse = 0;
        double K = trueCounts.length;
        for(int i = 0; i < trueCounts.length; i++){
            if(trueCounts[i] == 0){
                K--;
                continue;
            }
            mrse = mrse + (trueCounts[i] - minedCounts[i])*(trueCounts[i] - minedCounts[i]);
        }
        mrse = mrse/K;
        mrse = Math.sqrt(mrse);
        return mrse;
    }

    public ItemSetInformation AllHashLoading(String fileName){
        ItemSetInformation setInfor = new ItemSetInformation();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
            int count = Integer.parseInt(tokens[1].trim());
            FrequentItemset freqitems = new FrequentItemset();
            freqitems.setItemSet(itemset);
            freqitems.setCount(count);
            
            setInfor.hashMap.put(itemset, count);
            setInfor.arrayList.add(freqitems);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        
        return setInfor;
    }
    
    public ItemSetInformation SingleLoading(String fileName){
        ItemSetInformation setInfor = new ItemSetInformation();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
            int count = (int) Double.parseDouble(tokens[1].trim());
            FrequentItemset freqitems = new FrequentItemset();
            freqitems.setItemSet(itemset);
            freqitems.setCount(count);
            
            setInfor.hashMap.put(itemset, count);
            setInfor.arrayList.add(freqitems);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        
        return setInfor;
    }
    
    public void sortFrequentItemset(ItemSetInformation itemsetInfor) {
        Collections.sort(itemsetInfor.arrayList);
    }    
}
