/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysisNew.RecalPrecision;

import ResultAnalysis.FrequentItemset;
import fileUtil.fileHandle;
import fileUtil.fileOperator;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**
 *
 * @author String
 */
public class AccracyCollection {

    public static String trueFilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\AllFIMResults\\";
//    public static String minedFilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\KApriori\\Tweet\\";
    public static String minedFilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\Order\\KApriori-Old\\";
//    public static String minedFilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\KAprioriOld\\Tweet\\";
//    public static String minedFilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\KFP-Growth\\Tweet\\";
//    public static String dataFileName = "T10I4D1000K";
//    public static String dataFileName = "T15I6D1000K"; 
    public static String dataFileName = "tweets_RemoveII";
    
   public static String saveFilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\Order\\Results\\";

//    public static void main(String[] args) throws IOException {
//        fileHandle fh = new fileHandle();
//        String[] fileNames = fh.getFileNames(minedFilePath, "dat", true);
//
//        AccracyCollection AC = new AccracyCollection();
//        double[][] AccuracyMatrix = new double[fileNames.length][];
//        for (int i = 0; i < fileNames.length; i++) {
////            System.out.println(fileNames[i]);
//            AccuracyMatrix[i] = new double[7];
//            double[] paras = AC.parameterParse(fileNames[i]);
//            System.arraycopy(paras, 0, AccuracyMatrix[i], 0, 5);
//            String trueFileName = trueFilePath + dataFileName + "_all_support_" + String.valueOf(paras[1]) + ".dat";
//            HashMap<String, Integer> trueSet = AC.loadTrueFrequentItemsets(trueFileName);
////            ArrayList<String> trueSet = AC.loadTrueFrequentItemsetsAnother(trueFileName);
//            String minedFileName = minedFilePath + fileNames[i] + ".dat";
//            ArrayList<String> minedSet = AC.loadMindedFrequentItemsets(minedFileName);
//            double[] results = AC.computeRecallPrecision(minedSet, trueSet);
//            System.arraycopy(results, 0, AccuracyMatrix[i], 5, 2);
//            System.out.println(paras[0] + "\t" + results[0] + "\t" + results[1]);
//        }
//        AC.saveResults(saveFilePath + dataFileName + ".txt", AccuracyMatrix);
//    }

//   public static void main(String[] args) throws IOException {
//        fileHandle fh = new fileHandle();
//        String[] fileNames = fh.getFileNames(minedFilePath, "dat", true);
//
//        AccracyCollection AC = new AccracyCollection();
//        double[][] AccuracyMatrix = new double[fileNames.length][];
//        for (int i = 0; i < fileNames.length; i++) {
////            System.out.println(fileNames[i]);
//            AccuracyMatrix[i] = new double[7];
//            double[] paras = AC.parameterParseLen(fileNames[i]);
//            System.arraycopy(paras, 0, AccuracyMatrix[i], 0, 5);
//            String trueFileName = trueFilePath + dataFileName + "_N_" + (int)paras[0] + "_all_support_" + String.valueOf(paras[1]) + ".dat";
//            HashMap<String, Integer> trueSet = AC.loadTrueFrequentItemsets(trueFileName);
////            ArrayList<String> trueSet = AC.loadTrueFrequentItemsetsAnother(trueFileName);
//            String minedFileName = minedFilePath + fileNames[i] + ".dat";
//            ArrayList<String> minedSet = AC.loadMindedFrequentItemsets(minedFileName);
//            double[] results = AC.computeRecallPrecision(minedSet, trueSet);
//            System.arraycopy(results, 0, AccuracyMatrix[i], 5, 2);
//            System.out.println(paras[0] + "\t" + results[0] + "\t" + results[1]);
//        }
//        AC.saveResults(saveFilePath + dataFileName + ".txt", AccuracyMatrix);
//    }  
   
   
    public static void main(String[] args) throws IOException {
        fileHandle fh = new fileHandle();
        String[] fileNames = fh.getFileNames(minedFilePath, "dat", true);

        AccracyCollection AC = new AccracyCollection();
        double[][] AccuracyMatrix = new double[fileNames.length][];
        for (int i = 0; i < fileNames.length; i++) {
//            System.out.println(fileNames[i]);
            AccuracyMatrix[i] = new double[2];
//            double[] paras = AC.parameterParseLen(fileNames[i]);
//            System.arraycopy(paras, 0, AccuracyMatrix[i], 0, 5);
            String orderName = AC.parameterParseorder(fileNames[i]);
            String trueFileName = trueFilePath + dataFileName + "_all_support_" + 0.005 + ".dat";
            HashMap<String, Integer> trueSet = AC.loadTrueFrequentItemsets(trueFileName);
//            ArrayList<String> trueSet = AC.loadTrueFrequentItemsetsAnother(trueFileName);
            String minedFileName = minedFilePath + fileNames[i] + ".dat";
            ArrayList<String> minedSet = AC.loadMindedFrequentItemsets(minedFileName);
            double[] results = AC.computeRecallPrecision(minedSet, trueSet);
            System.arraycopy(results, 0, AccuracyMatrix[i],0, 2);
            System.out.println(orderName + "\t" + results[0] + "\t" + results[1]);
        }
        AC.saveResults(saveFilePath + dataFileName + ".txt", AccuracyMatrix);
    }    
    public void saveResults(String fileName, double[][] accuracy) throws IOException {
        File file = new File(fileName);
        if (!file.exists()) {
            file.createNewFile();
        }
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);

        for (int i = 0; i < accuracy.length; i++) {
            String line = "" + accuracy[i][0];
            for (int j = 1; j < accuracy[i].length; j++) {
                line = line + "," + accuracy[i][j];
            }
            fo.writeFile(line);
        }
        fo.closeWriteFile();
    }

    public AccracyCollection() {
    }

    public HashMap<String, Integer> loadTrueFrequentItemsets(String fileName) {
//        System.out.println(fileName);
        HashMap<String, Integer> hashmap = new HashMap();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while (line != null) {
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
//            if(tokens.length<2)
//             System.out.println(line+"\tgdsgsdgds\t"+ fileName);
            int count = (int) Double.parseDouble(tokens[1].trim());
            String items[] = itemset.split(" ");
            String key = sortTokens(items);
//            String key = tokens[0].trim();
//if(tokens.length<1){
//    System.out.println(line);
//}
            
            
            hashmap.put(key, count);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return hashmap;
    }
    
 public ArrayList<String> loadTrueFrequentItemsetsAnother(String fileName) {
//        System.out.println(fileName);
        ArrayList<String> arrayList = new ArrayList();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while (line != null) {
            String[] tokens = line.split(":");
//            String itemset = tokens[0].trim();
//            if(tokens.length<2)
//             System.out.println(line+"\tgdsgsdgds\t"+ fileName);
//            int count = (int) Double.parseDouble(tokens[1].trim());
//            String items[] = itemset.split(" ");
//            String key = sortTokens(items);
            String key = tokens[0].trim();
            arrayList.add(key);
//if(tokens.length<1){
//    System.out.println(line);
//}
            
            
//            hashmap.put(key, count);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return arrayList;
    }    

    public ArrayList<String> loadMindedFrequentItemsets(String fileName) {
        ArrayList<String> arrayList = new ArrayList();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while (line != null) {
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
            String items[] = itemset.split(" ");
            String key = sortTokens(items);
//            String key = tokens[0].trim();
//            int count = (int) Double.parseDouble(tokens[1].trim());
            arrayList.add(key);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return arrayList;
    }
    
    public boolean compareItemset(String trueStr, String mineStr){
        String titems[] = trueStr.split(" ");
        String mitems[] = mineStr.split(" ");
        
        if(titems.length!=mitems.length){
            return false;
        }
        HashMap<String, Integer> hashmap = new HashMap();
        for(int i = 0; i < titems.length; i++){
            hashmap.put(titems[i], i);
        }
        
        int k = 0;
        for(int i = 0; i < mitems.length; i++){
            if(hashmap.containsKey(mitems[i])){
                k++;
            }else{
                return false;
            }
        }
        return true;
    }

    public double[] computeRecallPrecision(ArrayList<String> minedFI, HashMap<String, Integer> trueFI) {
        double T = trueFI.size();
        double R = minedFI.size();
        double K = 0;
        for (int i = 0; i < minedFI.size(); i++) {
            String key = minedFI.get(i);
            if (trueFI.containsKey(key)) {
                K++;
//                System.out.println(key);
            }
        }

//        System.out.println(K +"\t" + R + "\t" + T);
        double[] results = new double[2];
        results[0] = K / R;
        results[1] = K / T;
        return results;
    }
    
    public double[] computeRecallPrecisionAnother(ArrayList<String> minedFI, ArrayList<String> trueFI) {
        double T = trueFI.size();
        double R = minedFI.size();
        double K = 0;
        for (int i = 0; i < minedFI.size(); i++) {
            String mitems = minedFI.get(i);
            for(int j = 0; j < trueFI.size(); j++){
                String titems = trueFI.get(j);
                if(this.compareItemset(titems, mitems)){
                    K++;
                }
            }
        }

        System.out.println(K +"\t" + R + "\t" + T);
        double[] results = new double[2];
        results[0] = K / R;
        results[1] = K / T;
        return results;
    }

    public String sortTokens(String[] tokens) {
        ArrayList<String> arrayList = new ArrayList();
        for (int i = 0; i < tokens.length; i++) {
            arrayList.add(tokens[i]);
        }
        
//        if(tokens.length > 3)
        Collections.sort(arrayList);
        String line = "";
        for (int i = 0; i < arrayList.size(); i++) {
            line = line + arrayList.get(i).toString()+",";
        }
        return line;
    }
    
    public double[] parameterParseLen(String fileName) {
        String[] tokens = fileName.split("_");
        double[] parameters = new double[5];
        for (int i = 0; i < tokens.length; i++) {
            if (tokens[i].trim().equals("support")) {
                double support = Double.parseDouble(tokens[i + 1].trim());
                parameters[1] = support;
            } else if (tokens[i].trim().equals("K")) {
                double K = Double.parseDouble(tokens[i + 1].trim());
                parameters[0] = K;
            } else if (tokens[i].trim().equals("close")) {
                double close = Double.parseDouble(tokens[i + 1].trim());
                parameters[2] = close;
            } else if (tokens[i].trim().equals("eta")) {
                double eta = Double.parseDouble(tokens[i + 1].trim());
                parameters[3] = eta;
            }

            if (tokens[i].trim().equals("seed")) {
                double seed = Double.parseDouble(tokens[i + 1].trim());
                parameters[4] = seed;
            }

        }
        
        String[] subtokens = tokens[1].split("RemoveII");
        double N = Double.parseDouble(subtokens[1].trim());
        parameters[0] = N;
        return parameters;
    }
    
 public String  parameterParseorder(String fileName) {
        String[] tokens = fileName.split("_");
//        double[] parameters = new double[5];
        for (int i = 0; i < tokens.length; i++) {
            if (tokens[i].trim().equals("Order")) {
                return tokens[i+1];
//                double support = Double.parseDouble(tokens[i + 1].trim());
//                parameters[1] = support;
//            } else if (tokens[i].trim().equals("K")) {
//                double K = Double.parseDouble(tokens[i + 1].trim());
//                parameters[0] = K;
//            } else if (tokens[i].trim().equals("close")) {
//                double close = Double.parseDouble(tokens[i + 1].trim());
//                parameters[2] = close;
//            } else if (tokens[i].trim().equals("eta")) {
//                double eta = Double.parseDouble(tokens[i + 1].trim());
//                parameters[3] = eta;
//            }
//
//            if (tokens[i].trim().equals("seed")) {
//                double seed = Double.parseDouble(tokens[i + 1].trim());
//                parameters[4] = seed;
//            }
            }
        }
        
//        String[] subtokens = tokens[1].split("RemoveII");
//        double N = Double.parseDouble(subtokens[1].trim());
//        parameters[0] = N;
        return null;
    }    

    public double[] parameterParse(String fileName) {
        String[] tokens = fileName.split("_");
        double[] parameters = new double[5];
        for (int i = 0; i < tokens.length; i++) {
            if (tokens[i].trim().equals("support")) {
                double support = Double.parseDouble(tokens[i + 1].trim());
                parameters[1] = support;
            } else if (tokens[i].trim().equals("K")) {
                double K = Double.parseDouble(tokens[i + 1].trim());
                parameters[0] = K;
            } else if (tokens[i].trim().equals("close")) {
                double close = Double.parseDouble(tokens[i + 1].trim());
                parameters[2] = close;
            } else if (tokens[i].trim().equals("eta")) {
                double eta = Double.parseDouble(tokens[i + 1].trim());
                parameters[3] = eta;
            }

            if (tokens[i].trim().equals("seed")) {
                double seed = Double.parseDouble(tokens[i + 1].trim());
                parameters[4] = seed;
            }

        }
        return parameters;
    }

}
