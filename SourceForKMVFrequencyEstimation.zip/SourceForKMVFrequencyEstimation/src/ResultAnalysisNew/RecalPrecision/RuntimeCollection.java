/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysisNew.RecalPrecision;

import fileUtil.fileHandle;
import fileUtil.fileOperator;

/**
 *
 * @author String
 */
public class RuntimeCollection {
    
    public static String filePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\Order\\KApriori\\";
    
    public static void main(String []args){
        fileHandle fh = new fileHandle();
        String[] fileNames = fh.getFileNames(filePath, "txt", true);
        for(int i = 0; i < fileNames.length; i++){
            String order = parameterParseorder(fileNames[i]);
            double runtime = runtimeComputaion(filePath + fileNames[i]+".txt");
            System.out.println(order+"\t"+runtime);
        }
    }
    
    public static void printResult(double[] paras, double runtime){
        String line = "";
        for(int i = 0; i < paras.length; i++){
            line = line + + paras[i]+"\t" ;
        }
        line = line  + runtime;
        System.out.println(line);
    }
    
//        public static void printResult(String  order, double runtime){
//        String line = "";
//        for(int i = 0; i < paras.length; i++){
//            line = line + + paras[i]+"\t" ;
//        }
//        line = line  + runtime;
//        System.out.println(line);
//    }
    
    public static double runtimeComputaion(String fileName){
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        double sum = 0;
        int count = 0;
        while(line!=null){
            sum = sum + Double.parseDouble(line.trim());
            count++;
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return sum/count;
    }
    
    public static String  parameterParseorder(String fileName) {
        String[] tokens = fileName.split("_");
//        double[] parameters = new double[5];
        for (int i = 0; i < tokens.length; i++) {
            if (tokens[i].trim().equals("Order")) {
                return tokens[i+1];
//                double support = Double.parseDouble(tokens[i + 1].trim());
//                parameters[1] = support;
//            } else if (tokens[i].trim().equals("K")) {
//                double K = Double.parseDouble(tokens[i + 1].trim());
//                parameters[0] = K;
//            } else if (tokens[i].trim().equals("close")) {
//                double close = Double.parseDouble(tokens[i + 1].trim());
//                parameters[2] = close;
//            } else if (tokens[i].trim().equals("eta")) {
//                double eta = Double.parseDouble(tokens[i + 1].trim());
//                parameters[3] = eta;
//            }
//
//            if (tokens[i].trim().equals("seed")) {
//                double seed = Double.parseDouble(tokens[i + 1].trim());
//                parameters[4] = seed;
//            }
            }
        }
        
//        String[] subtokens = tokens[1].split("RemoveII");
//        double N = Double.parseDouble(subtokens[1].trim());
//        parameters[0] = N;
        return null;
    }    
public static double[] parameterParse(String fileName) {
        String[] tokens = fileName.split("_");
        double[] parameters = new double[5];
        for (int i = 0; i < tokens.length; i++) {
            if (tokens[i].trim().equals("support")) {
                double support = Double.parseDouble(tokens[i + 1].trim());
                parameters[1] = support;
            } else if (tokens[i].trim().equals("K")) {
                double K = Double.parseDouble(tokens[i + 1].trim());
                parameters[0] = K;
            } else if (tokens[i].trim().equals("close")) {
                double close = Double.parseDouble(tokens[i + 1].trim());
                parameters[2] = close;
            } else if (tokens[i].trim().equals("eta")) {
                double eta = Double.parseDouble(tokens[i + 1].trim());
                parameters[3] = eta;
            }

            if (tokens[i].trim().equals("seed")) {
                double seed = Double.parseDouble(tokens[i + 1].trim());
                parameters[4] = seed;
            }
            parameters[0] = Double.parseDouble(tokens[0].trim());
        }
//        String[] subtokens = tokens[1].split("RemoveII");
        double N = Double.parseDouble(tokens[1].trim());
        parameters[0] = N;
        return parameters;
    }    
}
