/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysisNew;

import fileUtil.fileHandle;

/**
 *
 * @author String
 */
public class ChangeFileName {

    public static void main(String[] args) {
        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewExperimentalResults\\Tweets\\A1\\";
        fileHandle fh = new fileHandle();
        String[] fileNames = fh.getFileNames(filePath, "dat");
        for (int i = 0; i < fileNames.length; i++) {
            String fileNamei = fileNames[i];
            String newFilenamei = fileNamei.replaceFirst("_support", "");
            String nnNamei = newFilenamei.replaceFirst("0.008_close", "_support_0.008_close");
//            System.out.println(fileNamei + "\n" + nnNamei);
            System.out.println("ren \"" + fileNamei + "\"  \"" + nnNamei + "\"");
        }
    }
}
