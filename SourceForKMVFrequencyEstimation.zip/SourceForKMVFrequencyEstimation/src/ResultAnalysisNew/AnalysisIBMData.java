/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysisNew;

import ResultAnalysis.FrequentItemset;
import fileUtil.fileHandle;
import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**
 *
 * @author String
 */
public class AnalysisIBMData {
    public static String trueCountFile = "C:\\Users\\String\\Document Sources\\"
            + "FIM Datasets\\NewExperimentalResults\\AllResults\\IBM\\trueCounts.txt";
//    public static String minedFilePath = "C:\\Users\\String\\Document Sources\\"
//            + "FIM Datasets\\NewExperimentalResults\\IBM\\K\\";
    public static String minedFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewExperimentalResults\\VarySize\\IBM\\A1\\";
    
    public static int N = 366947989;
    public static boolean flag = true;
        
    public class ItemSetInformation {

        public HashMap<String, Integer> hashMap;
        public ArrayList<FrequentItemset> arrayList;

        public ItemSetInformation() {
            hashMap = new HashMap();
            arrayList = new ArrayList();                         
        }
    }
    
    public static void main(String[] args){
        AnalysisIBMData AIBM = new AnalysisIBMData();
        ItemSetInformation trueCountItemset = AIBM.AllHashLoading(trueCountFile);
        fileHandle fh = new fileHandle();
        String[] minedFileNames = fh.getFileNames(minedFilePath, "dat", true);
        for(int i = 0; i < minedFileNames.length; i++){
            String fileNamei = minedFileNames[i];
            double support = AIBM.supportExtraction(fileNamei);
            double K = AIBM.ExtractNumber(fileNamei);
            double ratio = N/K;
//            System.out.println(fileNamei + "\t" + support + "\t" + K);
            ItemSetInformation minedItemset =  AIBM.SingleLoading(minedFilePath + fileNamei + ".dat");
            double precision = AIBM.ComputePrecision(trueCountItemset, minedItemset, support);
            System.out.println(K + "\t" + support + "\t" + precision);
//            double error10 = AIBM.ComputeMRSE(trueCountItemset, minedItemset, flag, 10, ratio);
//            double error20 = AIBM.ComputeMRSE(trueCountItemset, minedItemset, flag, 20, ratio);
//            double error50 = AIBM.ComputeMRSE(trueCountItemset, minedItemset, flag, 50, ratio);
//            double error100 = AIBM.ComputeMRSE(trueCountItemset, minedItemset, flag, 100, ratio);
//            double error150 = AIBM.ComputeMRSE(trueCountItemset, minedItemset, flag, 150, ratio);
//            
//            double result10 = AIBM.ComputePrecision(trueCountItemset, minedItemset, support, 10);
//            double result20 = AIBM.ComputePrecision(trueCountItemset, minedItemset, support, 20);
//            double result50 = AIBM.ComputePrecision(trueCountItemset, minedItemset, support, 50);
//            double result100 = AIBM.ComputePrecision(trueCountItemset, minedItemset, support, 100);
//            double result150 = AIBM.ComputePrecision(trueCountItemset, minedItemset, support, 150);
//System.out.println(K + "\t" + support + "\t" + precision + "\t" + error10 + "\t" + result10+"\t"+
//                            error20 + "\t" + result20+"\t"+ error50 + "\t" + result50+"\t"+ error100 + "\t" + result100+"\t"+ error150 + "\t" + result150);     
        }                
    }
    
    public double ComputePrecision(ItemSetInformation trueCountItemset, ItemSetInformation minedFreqItemset, double support){
        double precision = 0;
        int count = 0;
        double R = minedFreqItemset.arrayList.size();
        
        for(int i = 0; i < minedFreqItemset.arrayList.size(); i++){
            FrequentItemset freqItemseti = minedFreqItemset.arrayList.get(i);
            String itemset = freqItemseti.itemset;
            if(trueCountItemset.hashMap.containsKey(itemset)){
                double trueCount = trueCountItemset.hashMap.get(itemset);
                if(trueCount >= N*support){
                    count++;
                }                
            }
        }
//        System.out.println(count + "\t" + R + "\t" + T);
        precision = count/R;
        return precision;
    }
    
    public double ComputePrecision(ItemSetInformation trueCountItemset, ItemSetInformation minedFreqItemset, double support, int K) {
        double precision = 0;
        double count = 0;
        sortFrequentItemset(minedFreqItemset);
//        double R = minedFreqItemset.arrayList.size();
        for (int i = 0; i < K; i++) {
            FrequentItemset freqItemseti = minedFreqItemset.arrayList.get(i);
            String itemset = freqItemseti.itemset;
            if (trueCountItemset.hashMap.containsKey(itemset)) {
                double trueCount = trueCountItemset.hashMap.get(itemset);
                if (trueCount >= N * support) {
                    count++;
                }
            }
        }
//        System.out.println(count + "\t" + R + "\t" + T);
        precision = count / K;
        return precision;
    }
    
    public double ComputeMRSE(ItemSetInformation trueCountItemset, ItemSetInformation minedFreqItemset, boolean flag, int K, double ratio){
        double mrse = 0;
//        sortFrequentItemset(trueFreqItemset);
        sortFrequentItemset(minedFreqItemset);
        double[] trueCounts = new double[K];
        double[] mineCounts = new double[K];
        for(int i = 0; i < K; i++){
            FrequentItemset freqItemseti = minedFreqItemset.arrayList.get(i);
            if(flag)
            mineCounts[i] = freqItemseti.count*ratio;
            else
                mineCounts[i] = freqItemseti.count;
            if(trueCountItemset.hashMap.containsKey(freqItemseti.itemset)){
                trueCounts[i] = trueCountItemset.hashMap.get(freqItemseti.itemset);
            }
        }
        mrse = estimationError(trueCounts, mineCounts);
        return mrse;
    } 

    public double estimationError(double[] trueCounts, double[] minedCounts){
        double mrse = 0;
        double K = trueCounts.length;
        for(int i = 0; i < trueCounts.length; i++){
            if(trueCounts[i] == 0){
                K--;
                continue;
            }
            mrse = mrse + (trueCounts[i] - minedCounts[i])*(trueCounts[i] - minedCounts[i]);
        }
        mrse = mrse/K;
        mrse = Math.sqrt(mrse);
        return mrse;
    }    
    
    
    public double supportExtraction(String allFileName) {
        String[] tokens = allFileName.split("_");
        for (int i = 0; i < tokens.length; i++) {
            if (tokens[i].trim().equals("support")) {
                double d = Double.parseDouble(tokens[i + 1].trim());
                return d;
            }
        }
        return -1;
    }
    
    public double ExtractNumber(String fileName) {
        String[] tokens = fileName.split("_");
        for (int i = 0; i < tokens.length; i++) {
            if (tokens[i].contains("=")) {
                String[] subtokens = tokens[i].split("=");
                double num = Double.parseDouble(subtokens[1].trim());
                return num;
            }
        }
        return -1;
    }    
    
    public ItemSetInformation AllHashLoading(String fileName){
        ItemSetInformation setInfor = new ItemSetInformation();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String[] tokens = line.split("	");
            String itemset = tokens[0].trim();
            int count = Integer.parseInt(tokens[1].trim());
            FrequentItemset freqitems = new FrequentItemset();
            freqitems.setItemSet(itemset);
            freqitems.setCount(count);
            
            setInfor.hashMap.put(itemset, count);
            setInfor.arrayList.add(freqitems);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        
        return setInfor;
    }
    
    public ItemSetInformation SingleLoading(String fileName){
        ItemSetInformation setInfor = new ItemSetInformation();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
            int count = (int) Double.parseDouble(tokens[1].trim());
            FrequentItemset freqitems = new FrequentItemset();
            freqitems.setItemSet(itemset);
            freqitems.setCount(count);
            
            setInfor.hashMap.put(itemset, count);
            setInfor.arrayList.add(freqitems);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        
        return setInfor;
    }
    
    public void sortFrequentItemset(ItemSetInformation itemsetInfor) {
        Collections.sort(itemsetInfor.arrayList);
    }        
}
