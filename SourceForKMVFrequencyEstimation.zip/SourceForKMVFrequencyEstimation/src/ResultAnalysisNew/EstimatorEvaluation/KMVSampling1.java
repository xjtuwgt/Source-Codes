/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysisNew.EstimatorEvaluation;

import BaseLineMethods.Apriori.AprioriItem;
import BaseLineMethods.Apriori.AprioriItemSet;
import HashFunctions.Node;
import KMVSynopsis.FASTOffLineKMVConstructionHugeData;
import ResultAnalysis.FrequentItemset;
import closefrequentitemsetmining.StaticParameters;
import fileUtil.fileOperator;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.Vector;

/**
 *
 * @author String
 */
public class KMVSampling1 {

    public static long seed = 1;
    protected double s_minSupport = 0.001;
    protected double s_closePara = 0.1;

    protected int s_maxItems = -1;
    protected long N = 0;
    public int K = 200;

    public int tempK = 0;
    public Queue<Node> priorityQueue;//Sort by hash values
    public Queue<Node> TIDpriorityQueue;//Sort by transIDs

    public fileOperator s_dataSource;//Read
    public fileOperator s_KMVDataSource;//Write
    public String s_dataSourceName;//Source data
    public String s_KMVDataSourceName;//Sampling data
    FASTOffLineKMVConstructionHugeData s_KMVConstruction;
    //========================================================================== 

//    public fileOperator s_dataSource;//Read
//    public String s_dataSourceName;
    ArrayList<AprioriItem> singletons;
    Hashtable<String, Integer> itemHashtable;

    public void setSupportThrehold(double supp) {
        s_minSupport = supp;
    }

    public void setCloseParameter(double closePara) {
        s_closePara = closePara;
    }

//    ArrayList<Edge> SketchGraph;
//    protected Vector<AprioriItemSet> m_largeItemSets;
    public KMVSampling1() {
    }

    public KMVSampling1(long n, int k, String sourceName, String KMVName) {
        N = n;
        K = k;
        s_dataSourceName = sourceName;
        s_KMVDataSourceName = KMVName;
    }

    public void dataSampleWithReplacement() {
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };

        Random rand = new Random();
        rand.setSeed(seed);
        priorityQueue = new PriorityQueue<>(K, OrderOnHash);
        int TID = 0;
        while (TID < K) {//Buffering data
//            double d = Math.random();
            double d = rand.nextDouble();
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            TID++;
        }

        while (TID < N) {//Sampling process
//            double d = Math.random();
            double d = rand.nextDouble();
            if (d < priorityQueue.peek().getHash()) {
                Node tempNode = new Node(TID, d, null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            TID++;
        }
    }

    public void GenerateIDList() {
        Comparator<Node> OrderOnID = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                long numbera = o1.getID();
                long numberb = o2.getID();
                if (numberb > numbera) {
                    return -1;
                } else if (numberb < numbera) {
                    return 1;
                } else {
                    return 0;
                }

            }
        };

        TIDpriorityQueue = new PriorityQueue<>(K, OrderOnID);
        while (!priorityQueue.isEmpty()) {
            Node node = priorityQueue.poll();
            TIDpriorityQueue.add(node);
        }
        priorityQueue.clear();
        System.out.println(priorityQueue.size() + "\t Here" + TIDpriorityQueue.toArray().length);
        priorityQueue = null;
    }

    public void InvertSketchAndGraphContruction() {
        s_dataSource = new fileOperator();
        s_KMVDataSource = new fileOperator();
        s_dataSource.openReadFile(s_dataSourceName);
        s_KMVDataSource.openWriteFile(s_KMVDataSourceName);
        int hashIndex = 0;//Hash value
        itemHashtable = new Hashtable<String, Integer>();

        singletons = new ArrayList();
//        System.out.println(TIDpriorityQueue.size()+"======================I'am Here");
        int index = 0;
        long scanIndex = 0;//can the original data set
        Node node = TIDpriorityQueue.poll();
        long sampleID = node.getID();
        String line = s_dataSource.readByLine();
        while (index < K && line != null) {
//            System.out.println(index);
            if (line.trim().equals("")) {
                line = s_dataSource.readByLine();
                continue;
            }
            while (scanIndex < sampleID && line != null) {
                if (line.trim().equals("")) {
                    line = s_dataSource.readByLine();
                    continue;
                }
//                System.out.println(scanIndex + "\t" + sampleID);
                line = s_dataSource.readByLine();
                scanIndex++;
            }
            if (scanIndex == sampleID) {//sampled transactions
                s_KMVDataSource.writeFile(line);
                String[] tokens = line.split(StaticParameters.splitKey);
                for (int i = 0; i < tokens.length; i++) {
                    if (itemHashtable.containsKey(tokens[i].trim())) {//update
                        int itemIndex = itemHashtable.get(tokens[i]);
                        AprioriItem temp = singletons.get(itemIndex);
                        temp.increaseCount();
                        temp.addKMV(node.getHash());
                    } else {//New item
                        itemHashtable.put(tokens[i], hashIndex);
                        AprioriItem temp = new AprioriItem(tokens[i]);
//                        temp.increaseCount();
                        temp.addKMV(node.getHash());
                        singletons.add(temp);
                        hashIndex++;
                    }
                }
//                System.out.println(index + "\t" + sampleID + "\t" + scanIndex);
                if (TIDpriorityQueue.isEmpty()) {
                    System.out.println(scanIndex + "I am here!!\t" + index);
//                    System.out.println(scanIndex + "\t" + index + "\t" + TIDpriorityQueue.size() + "\t One items " + singletons.size() + "\t" + hashIndex +  "\t Two items" + SketchGraph.size());
                    TIDpriorityQueue.clear();;
                    TIDpriorityQueue = null;
                    s_dataSource.closeReadFile();
                    s_KMVDataSource.closeWriteFile();
                    return;
                }
                node = TIDpriorityQueue.poll();
                sampleID = node.getID();
                index++;
            }
            line = s_dataSource.readByLine();
            scanIndex++;
        }

        System.out.println(scanIndex + "\t" + index + "\t" + TIDpriorityQueue.size() + "\t One items" + singletons.size());

        TIDpriorityQueue.clear();;
        TIDpriorityQueue = null;
        s_dataSource.closeReadFile();
        s_KMVDataSource.closeWriteFile();
    }
    
    public double[] CountEstimation(String[] items){
//        ArrayList<AprioriItem> arrayList = new ArrayList();
        double maxKMV = 0;
        for(int i = 0; i < items.length; i++){
            if(!itemHashtable.containsKey(items[i])){
                return null;
            }
            int index = this.itemHashtable.get(items[i]);
            AprioriItem aprioriItemi = this.singletons.get(index);
            Collections.sort(aprioriItemi.s_KMVs);
            if(maxKMV < aprioriItemi.s_KMVs.get(aprioriItemi.s_KMVs.size() -1)){
                maxKMV = aprioriItemi.s_KMVs.get(aprioriItemi.s_KMVs.size() -1);
            }
        }
        
        
        AprioriItem itemi = this.singletons.get(this.itemHashtable.get(items[0]));
        List<Double> listi = itemi.s_KMVs;
        List<Double> intersection = new ArrayList(listi);
        List<Double> union = new ArrayList(listi);
        int minK = itemi.K;
        
        for(int i = 1; i < items.length; i++){
            int index  = this.itemHashtable.get(items[i]);
            AprioriItem tempItemi = this.singletons.get(index);
            int tempK = tempItemi.K;
            List<Double> tempListi = tempItemi.s_KMVs;
            intersection.retainAll(tempListi);            
            if(intersection.size() == 0){
                return null;
            }
            if (minK < tempK) {
                minK = tempK;
            }
//            union.removeAll(tempListi);
            union.addAll(tempListi);
        }
        
        if(intersection.size() == 0){
            return null;
        }
//        System.out.println(minK + "\t minum" );
        int secSize = intersection.size();
        Collections.sort(union);
        double KMV = union.get(minK - 1);
        
        double oldEstimation = (secSize*1.0/minK)*((minK - 1)/KMV);
        double newEstimation = secSize/maxKMV;
        
        double[] results = new double[2];
        results[0] = oldEstimation;
        results[1] = newEstimation;
        return results;
    }
    

    public ArrayList<FrequentItemset> loadItemset(String fileName, String split){
        fileOperator fo = new fileOperator();
        ArrayList<FrequentItemset> arrayList = new ArrayList(); 
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String tokens[] = line.split(split);
            String itemset = tokens[0].trim();
            int Count = Integer.parseInt(tokens[1].trim());
            FrequentItemset freqItemset = new FrequentItemset();
            String[] temps = itemset.split(" ");
            if(temps.length > 1){
            freqItemset.setItemSet(itemset);
            freqItemset.setCount(Count);
            arrayList.add(freqItemset);
            }
            line = fo.readByLine();
        }
        fo.closeReadFile();
        
        return arrayList;
    }
//    public Vector<AprioriItemSet> getFrequnetOneItemSet() {
//        Vector<AprioriItemSet> oneItemSet = new Vector();
//        AprioriItemSet tempItemSet;
//        for (int i = 0; i < singletons.size(); i++) {
//            AprioriItem tempItem = singletons.get(i);
//            Collections.sort(tempItem.s_KMVs);
//            String name = tempItem.getName();
//            int hashIndex = itemHashtable.get(name);
//            int items[] = new int[1];
//            items[0] = hashIndex;
//            tempItemSet = new AprioriItemSet((int) N, items);
//            tempItemSet.m_KMV = tempItem.s_KMVs.get(tempItem.K - 1);
//            tempItemSet.s_K = tempItem.K;
//            tempItemSet.s_frequency = tempItemSet.s_K / tempItemSet.m_KMV;
//            if ((tempItemSet.s_frequency > N * s_minSupport*(1-this.s_closePara/2))&&(tempItem.K > tempK)) {
//                oneItemSet.add(tempItemSet);
//                this.m_largeItemSets.add(tempItemSet);
//            }
//        }
//        return oneItemSet;
//    }

//    public Hashtable invertMap() {
//        Hashtable<Integer, String> invertable = new Hashtable();
//        Set<Entry<String, Integer>> set = this.itemHashtable.entrySet();
//        Iterator iterator = set.iterator();
//        while (iterator.hasNext()) {
//            Entry<String, Integer> temp = (Entry<String, Integer>) iterator.next();
//            String value = temp.getKey();
//            int key = temp.getValue();
//            invertable.put(key, value);
//        }
//        return invertable;
//    }
    
    public double[][] estimateError(ArrayList<FrequentItemset> arrayList){
        int S = arrayList.size();
        double[][] countsMatrix = new double[S][];
        for(int i = 0; i < S; i++){
            if(i%500 == 0){
                System.out.println(i);
            }
            countsMatrix[i] = new double[4];
            FrequentItemset itemseti = arrayList.get(i);
            countsMatrix[i][0] = itemseti.count;
            String itemset = itemseti.itemset;
            String tokens[] = itemset.split(" ");
            double[] estimation = this.CountEstimation(tokens);
            if(estimation==null){
                continue;
            }
            countsMatrix[i][1] = estimation[0];
            countsMatrix[i][2] = estimation[1];
            countsMatrix[i][3] = tokens.length;
//            System.out.println(estimation[0] + "\t" + estimation[1] + "\t" + itemseti.count);
        }
        return countsMatrix;
    }

    public void setSeed(long s){
        seed = s;
    }
    
    public double[] RMSECompuation(double[][] countsMatrix){
        double error1 = 0;
        double error2 = 0;
        int K = 0;
        for(int i = 0; i < countsMatrix.length; i++){
            if(countsMatrix[i][3] > 1){
                K++;
                error1 = error1 + (countsMatrix[i][0] - countsMatrix[i][1])*(countsMatrix[i][0] - countsMatrix[i][1]);
                error2 = error2 + (countsMatrix[i][0] - countsMatrix[i][2])*(countsMatrix[i][0] - countsMatrix[i][2]);
            }
        }
        error1 = Math.sqrt(error1/K);
        error2 = Math.sqrt(error2/K);
        double[] results = new double[2];
        results[0] = error1;
        results[1] = error2;
        
        return results;
    }
    
    
    public  void saveCounts(String fileName, double[][] counts) throws IOException{
                File file = new File(fileName);
        if(!file.exists()){
            file.createNewFile();
        }
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        for(int i = 0; i < counts.length; i++){
            String line = "";
            line = line + counts[i][0] + "\t" + counts[i][1] + "\t" + counts[i][2] + "\t" + counts[i][3];
            fo.writeFile(line);
        }
        fo.closeWriteFile();
    }    
    public static void main(String[] args) throws IOException {
        String fileName = "IBM_BigData";
//        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\";
String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\";
        String sourceFileName = filePath + fileName + ".data";
        String KMVFileName = filePath + "KMVSampleData\\KMV_" + fileName + ".data";
        
        String trueFrequentFileName =  "C:\\Users\\String\\Document Sources\\"
            + "FIM Datasets\\NewExperimentalResults\\AllResults\\IBM\\trueCounts.txt";
        String savefilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewExperimentalResults\\EstimationError\\IBM\\";
        
        long N = 366947989;
//        int  K =   112188;
        double  B =   366947989;
        int K = (int) (B/100);
        double[][] countsArray = new double[5][];
//        for(int i = 0; )
        for(int i = 0; i < 1  ; i++){
             
            System.out.println("Pass \t" + (i+1));
        KMVSampling1 sample = new KMVSampling1(N, K, sourceFileName, KMVFileName);
//        KMVSampling sample = new KMVSampling();
        ArrayList<FrequentItemset> arrayList = sample.loadItemset(trueFrequentFileName, "	");
        sample.dataSampleWithReplacement();
        sample.setSeed(i+1);
        sample.GenerateIDList();
        sample.InvertSketchAndGraphContruction();
        double[][] countMatrix = sample.estimateError(arrayList);
        
        countsArray[i] = sample.RMSECompuation(countMatrix);
        System.out.println(countsArray[i][0] + "\t" + countsArray[i][1]);
        sample.saveCounts(savefilePath + "K="+K + seed + ".txt", countMatrix);
        
        System.out.println(arrayList.size());
        }
       for(int i = 0; i < 5; i++){ 
           System.out.println(countsArray[i][0] + "\t" + countsArray[i][1]);
       }
    }
}
