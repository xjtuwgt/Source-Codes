/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysisNew.EstimatorEvaluation;

import BaseLineMethods.Apriori.AprioriItem;
import HashFunctions.Node;
import KMVSynopsis.Item;
import ResultAnalysis.FrequentItemset;
import closefrequentitemsetmining.StaticParameters;
import fileUtil.fileOperator;
import java.io.File;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import randomX.randomLCG;
import randomX.randomX;

/**
 *
 * @author String
 */
public class EstimationErrorAnalysis {
    
     public fileOperator s_dataSource;//Read
    public String s_dataSourceName;
    
    public fileOperator s_KMVDataSource;//Write
    public String s_KMVDataSourceName;
//    HashFunction s_hash;//Read file
    public Hashtable<String, Integer> itemHashtable;
    ArrayList<AprioriItem> singletons;
//    public ArrayList<Item> ItemList;//One items
    public Queue<Node> priorityQueue;//Sort by hash values
    public Queue<Node> TIDpriorityQueue;//Sort by transIDs
    
    public long N = 0;//size of the data set
    public int K = 0; //size of the KMV synopsis
    public long seed = 0;
    
    public void setSeed(long s){
        seed = s;
    }
    
    
    public EstimationErrorAnalysis(){
    }
    
    public EstimationErrorAnalysis(long n, int k){
        N = n;
        K = k;
    }
    
    public EstimationErrorAnalysis(long n, int k, String dataSourceName) {
        N = n;
        K = k;
        s_dataSourceName = dataSourceName;
    }
    
    public EstimationErrorAnalysis(long n, int k, String dataSourceName, String KMVSourceName) {
        N = n;
        K = k;
        s_dataSourceName = dataSourceName;
        s_KMVDataSourceName = KMVSourceName;
    }
    //==========================================================================
    
 public void dataSampleWithReplacementNewAdded(){
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        
        Random rand = new Random(seed);
        long t = rand.nextLong();
        
        Random randi = new Random();
        randi.setSeed(t);
        
//        Random rand = new Random(seed);
//        int t = rand.nextInt();
//        Random randi = new Random(seed + 10000);

//        long t = System.currentTimeMillis();
//        Random rand = new Random(t);
//        t = System.currentTimeMillis();
//        Random randi = new Random(t);
        
//        Random randi = new Random(seed + 1000);
        priorityQueue = new PriorityQueue<>(K,OrderOnHash);
        int TID = 0;
        while (TID < K) {//Buffering data
//            double d = Math.random();


long s = randi.nextLong();
rand = new Random();
rand.setSeed(s*rand.nextLong());
//double d2 = randk.nextDouble();
double d = rand.nextDouble();
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            TID++;
        }
        
        while(TID < N){//Sampling process
//            double d = Math.random();
long s = randi.nextLong();
rand = new Random();
rand.setSeed(s*rand.nextLong());
//double d2 = randk.nextDouble();
double d = rand.nextDouble();
            if(d < priorityQueue.peek().getHash()){
                Node tempNode = new Node(TID,d,null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            TID++;            
        }
    }
 
  public void dataSampleWithReplacementNewAdded1(){
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        
//        Random rand = new Random(seed);
//        int t = rand.nextInt();
//        Random randi = new Random(seed + 10000);

          Random rand = new Random(seed);
        Random randi = new Random(seed + 1000);
//        long t = rand.nextLong();
        
//        Random randi = new Random();
//        randi.setSeed(t);
//        
//        t = rand.nextLong();
//                Random randk = new Random();
//        randk.setSeed(t);
        
//        Random randi = new Random(seed + 1000);
        priorityQueue = new PriorityQueue<>(K,OrderOnHash);
        int TID = 0;
        while (TID < K) {//Buffering data
//            double d = Math.random();


double d0 = rand.nextDouble();
long seed = randi.nextLong();
rand = new Random();
rand.setSeed(seed);
double d = rand.nextDouble();
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            TID++;
        }
        
        while(TID < N){//Sampling process
double d0 = rand.nextDouble();
long seed = randi.nextLong();
rand = new Random();
rand.setSeed(seed);
double d = rand.nextDouble();
            if(d < priorityQueue.peek().getHash()){
                Node tempNode = new Node(TID,d,null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            TID++;            
        }
    }
  
   public void dataSampleWithReplacementSecRand(){
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        
//        Random rand = new Random(seed);
//        int t = rand.nextInt();
//        Random randi = new Random(seed + 10000);
        SecureRandom rand = new SecureRandom();
        rand.setSeed(seed);
       
//        Random rand = new Random(seed);
        int t = rand.nextInt();
        SecureRandom randi = new SecureRandom();
        randi.setSeed(t);
//        Random randk = new Random(seed + 1000000);
        
    
        
        priorityQueue = new PriorityQueue<>(K,OrderOnHash);
        int TID = 0;
        while (TID < K) {//Buffering data
//            double d = Math.random();


long s = randi.nextLong();
rand = new SecureRandom();
rand.setSeed(s);
double d0 = rand.nextDouble();
//double d2 = randk.nextDouble();
double d = rand.nextDouble();
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            TID++;
        }
        
        while(TID < N){//Sampling process
//            double d = Math.random();
long s = randi.nextLong();
rand = new SecureRandom();
rand.setSeed(s);
double d0 = rand.nextDouble();
//double d2 = randk.nextDouble();
double d = rand.nextDouble();
            if(d < priorityQueue.peek().getHash()){
                Node tempNode = new Node(TID,d,null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            TID++;            
        }
    }
 
 
  public void dataSampleWithReplacementRandX(){
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        
//        Random rand = new Random(seed);
//        int t = rand.nextInt();
//        Random randi = new Random(seed + 10000);
        randomX rand;
        rand = new randomLCG();
        rand.setSeed();
       
//        Random rand = new Random(seed);
//        int t = rand.nextInt();
//        SecureRandom randi = new SecureRandom();
//        randi.setSeed(t);
//        Random randk = new Random(seed + 1000000);
        
    
        
        priorityQueue = new PriorityQueue<>(K,OrderOnHash);
        int TID = 0;
        while (TID < K) {//Buffering data
//            double d = Math.random();

//double d2 = randk.nextDouble();
double d = rand.nextDouble();
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            TID++;
        }
        
        while(TID < N){//Sampling process
//            double d = Math.random();
double d = rand.nextDouble();
            if(d < priorityQueue.peek().getHash()){
                Node tempNode = new Node(TID,d,null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            TID++;            
        }
    }
    public void dataSampleWithReplacement(){
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        
        Random rand = new Random(seed);
      
        
        priorityQueue = new PriorityQueue<>(K,OrderOnHash);
        int TID = 0;
        while (TID < K) {//Buffering data
//            double d = Math.random();
double d = rand.nextDouble();
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            TID++;
        }
        
        while(TID < N){//Sampling process
//            double d = Math.random();
double d = rand.nextDouble();
            if(d < priorityQueue.peek().getHash()){
                Node tempNode = new Node(TID,d,null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            TID++;            
        }
    }
    
    public List<Double> findUnion(List<Double> list1, List<Double> list2) {
        List<Double> union = new ArrayList();
        int index1 = 0;
        int index2 = 0;
        while (index1 < list1.size() && index2 < list2.size()) {
            if (list1.get(index1) < list2.get(index2)) {
                union.add(list1.get(index1));
                index1++;
            } else if (list1.get(index1) > list2.get(index2)) {
                union.add(list2.get(index2));
                index2++;
            } else {
                union.add(list1.get(index1));
                index1++;
                index2++;
            }
        }
        if(index1<list1.size()){
            for(;index1<list1.size(); index1++){
                union.add(list1.get(index1));
            }
        }else if(index2 < list2.size()){
            for(;index2 < list2.size(); index2++){
                union.add(list2.get(index2));
            }
        }
        return union;
    }
    
public List<Double> FindInterSection(List<Double> list1, List<Double> list2){
        ArrayList<Double> intersection = new ArrayList();
        int index1 = 0;
        int index2 = 0;
        int k = 0;
        while(index1 < list1.size() && index2 < list2.size()){
            double v1 = list1.get(index1);
            double v2 = list2.get(index2);
//            System.out.println(v1 + "\t" + v2);
            if(v1 == v2){
//                System.out.println("here");
                intersection.add(v1);
                k++;
                index1++;
                index2++;
            }else{
                if(v1 > v2){
                    index2++;
                }else{
                    index1++;
                }
            }
        }
//        System.out.println(k +"tg");
        return intersection;
    }        
    
    public void dataSampleWithReplacementAnother(){
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        
        Random random = new Random();
        random.setSeed(555L);
        
        
        priorityQueue = new PriorityQueue<>(K,OrderOnHash);
        int TID = 0;
        while (TID < K) {//Buffering data
            double d = random.nextDouble();
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            TID++;
        }
        
        while(TID < N){//Sampling process
            double d = random.nextDouble();
            if(d < priorityQueue.peek().getHash()){
                Node tempNode = new Node(TID,d,null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            TID++;            
        }
    }    
    
    public void GenerateIDList(){
        Comparator<Node> OrderOnID = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                long numbera = o1.getID();
                long numberb = o2.getID();
                if (numberb > numbera) {
                    return -1;
                } else if (numberb < numbera) {
                    return 1;
                } else {
                    return 0;
                }

            }
        };
        
        TIDpriorityQueue = new PriorityQueue<>(K,OrderOnID);
        while(!priorityQueue.isEmpty()){
            Node node = priorityQueue.poll();
            TIDpriorityQueue.add(node);
        }
        priorityQueue.clear();
        System.out.println(priorityQueue.size() + "\t" + TIDpriorityQueue.toArray().length);
        
       
//        for(int i = 0; i< temp.length; i++){
//            System.out.println(temp[i].getID());
//        }
//        System.out.println("fdjjkjjjjjjjjjjjjjjjjjj");
        
        priorityQueue = null;
    }
    
    
    public void InvertSketchConstruction(){//Only one scan
        s_dataSource = new fileOperator();
        s_KMVDataSource = new fileOperator();
        s_dataSource.openReadFile(s_dataSourceName);
        s_KMVDataSource.openWriteFile(s_KMVDataSourceName);
        int hashIndex = 0;//Hash value
//        int edgeHashIndex = 0;
        itemHashtable = new Hashtable<String, Integer>();
//        SketchGraph = new HashMap<Edge, Integer>();

        singletons = new ArrayList();
//        System.out.println(TIDpriorityQueue.size()+"======================I'am Here");
        int index = 0;
        long scanIndex = 0;//can the original data set
        Node node = TIDpriorityQueue.poll();
        long sampleID = node.getID();
        String line = s_dataSource.readByLine();
        while (index < K && line != null) {
//            System.out.println(index);
            if (line.trim().equals("")) {
                line = s_dataSource.readByLine();
                continue;
            }
            while (scanIndex < sampleID && line != null) {
                if (line.trim().equals("")) {
                    line = s_dataSource.readByLine();
                    continue;
                }
//                System.out.println(scanIndex + "\t" + sampleID);
                line = s_dataSource.readByLine();
                scanIndex++;
            }
            if (scanIndex == sampleID) {//sampled transactions
                s_KMVDataSource.writeFile(line);
                String[] tokens = line.split(StaticParameters.splitKey);
                for (int i = 0; i < tokens.length; i++) {
                    if (itemHashtable.containsKey(tokens[i].trim())) {//update
                        int itemIndex = itemHashtable.get(tokens[i]);
                        AprioriItem temp = singletons.get(itemIndex);
                        temp.increaseCount();
                        temp.addKMV(node.getHash());
                    } else {//New item
                        itemHashtable.put(tokens[i], hashIndex);
                        AprioriItem temp = new AprioriItem(tokens[i]);
//                        temp.increaseCount();
                        temp.addKMV(node.getHash());
                        singletons.add(temp);
                        hashIndex++;
                    }
                    for (int j = i + 1; j < tokens.length; j++) {
                        if (!itemHashtable.containsKey(tokens[j].trim())) {//update
                            itemHashtable.put(tokens[j], hashIndex);
                            AprioriItem temp = new AprioriItem(tokens[j]);
//                            temp.increaseCount();
                            temp.addKMV(node.getHash());
                            singletons.add(temp);
                            hashIndex++;
                        }

//                        int indi = itemHashtable.get(tokens[i]);
//                        int indj = itemHashtable.get(tokens[j]);
//                        Edge edge;
//                        if (indi < indj) {
//                            edge = new Edge(indi, indj);
//                        } else {
//                            edge = new Edge(indj, indi);
//                        }
//                        if (SketchGraph.containsKey(edge)) {
////                            System.out.println("Here");
//                            SketchGraph.replace(edge, SketchGraph.get(edge) + 1);
//                        } else {
//                            SketchGraph.put(edge, 1);
//                            edgeHashIndex++;
//                        }
                    }
                }
//                System.out.println(index + "\t" + sampleID + "\t" + scanIndex);
                if (TIDpriorityQueue.isEmpty()) {
                    System.out.println(scanIndex + "I am here!!\t" + index);
//                    System.out.println(scanIndex + "\t" + index + "\t" + TIDpriorityQueue.size() + "\t One items " + singletons.size() + "\t" + hashIndex +  "\t Two items" + SketchGraph.size());
                    TIDpriorityQueue.clear();;
                    TIDpriorityQueue = null;
                    s_dataSource.closeReadFile();
                    s_KMVDataSource.closeWriteFile();
//                    for (int i = 0; i < singletons.size(); i++) {
//                        AprioriItem tempItem = singletons.get(i);
//                        Collections.sort(tempItem.s_KMVs);
//                        tempItem.KMV = tempItem.s_KMVs.get(tempItem.K - 2);
//                        tempItem.frequency = tempItem.K / tempItem.KMV;
//                        System.out.println(tempItem.itemName + "\t count " + tempItem.K + "\t" + tempItem.frequency);
//                    }
                    return;
                }
                node = TIDpriorityQueue.poll();
                sampleID = node.getID();
                index++;
            }

            line = s_dataSource.readByLine();
            scanIndex++;
        }

//        System.out.println(scanIndex + "\t" + index + "\t" + TIDpriorityQueue.size() + "\t One items" + singletons.size() + "\t Two items" + SketchGraph.size());

        TIDpriorityQueue.clear();;
        TIDpriorityQueue = null;
        s_dataSource.closeReadFile();
        s_KMVDataSource.closeWriteFile();
    }
    
    
public double[] CountEstimation(String[] items){
//        ArrayList<AprioriItem> arrayList = new ArrayList();
        double maxKMV = 0;
        for(int i = 0; i < items.length; i++){
            if(!itemHashtable.containsKey(items[i])){
                return null;
            }
            int index = this.itemHashtable.get(items[i]);
            AprioriItem aprioriItemi = this.singletons.get(index);
            Collections.sort(aprioriItemi.s_KMVs);
            if(maxKMV < aprioriItemi.s_KMVs.get(aprioriItemi.s_KMVs.size() -1)){
                maxKMV = aprioriItemi.s_KMVs.get(aprioriItemi.s_KMVs.size() -1);
            }
        }
        
        
        AprioriItem itemi = this.singletons.get(this.itemHashtable.get(items[0]));
        List<Double> listi = itemi.s_KMVs;
        List<Double> intersection = new ArrayList(listi);
        List<Double> union = new ArrayList(listi);
        int minK = itemi.K;
        
        for(int i = 1; i < items.length; i++){
            int index  = this.itemHashtable.get(items[i]);
            AprioriItem tempItemi = this.singletons.get(index);
            int tempK = tempItemi.K;
            List<Double> tempListi = tempItemi.s_KMVs;
            intersection = this.FindInterSection(intersection, tempListi);            
            if(intersection.size() == 0){
                return null;
            }
//            System.out.println(minK);
            if (minK > tempK) {
                minK = tempK;
            }
            
//            union.removeAll(tempListi);
//            union.addAll(tempListi);
            union = this.findUnion(union, tempListi);
        }
        
        if(intersection.size() == 0){
            return null;
        }
//        System.out.println(minK + "\t minum" );
        int secSize = intersection.size();
//        Collections.sort(union);
//String s1 = "5945";
//String s2 = "1866";

        double KMV = union.get(minK - 1);

        double KMV1 = union.get(union.size() - 1);
        double maxK = union.size();
        
        double oldEstimation = (secSize*1.0/minK)*((minK - 1)/KMV);
        double newEstimation = secSize/maxKMV;
        double newEstimation1 = (secSize*1.0/maxK)*((maxK - 1)/KMV1);
//        System.out.println(minK + "\t" +KMV +"\t" + union.size()+"\t"+ items.length + "\t" + maxKMV + "\t" + this.K*1.0/this.N);
if(items.length == 2)
        System.out.println(maxK/minK + "\t" + items.length);
        
        double[] results = new double[3];
        results[0] = oldEstimation;
        results[1] = newEstimation;
        results[2] = newEstimation1;
        
        return results;
    }
    
public double[] CountEstimation1(String[] items){
//        ArrayList<AprioriItem> arrayList = new ArrayList();
        double maxKMV = 0;
        for(int i = 0; i < items.length; i++){
            if(!itemHashtable.containsKey(items[i])){
                return null;
            }
            int index = this.itemHashtable.get(items[i]);
            AprioriItem aprioriItemi = this.singletons.get(index);
            Collections.sort(aprioriItemi.s_KMVs);
            if(maxKMV < aprioriItemi.s_KMVs.get(aprioriItemi.s_KMVs.size() -1)){
                maxKMV = aprioriItemi.s_KMVs.get(aprioriItemi.s_KMVs.size() -1);
            }
        }
        
        
        AprioriItem itemi = this.singletons.get(this.itemHashtable.get(items[0]));
        List<Double> listi = itemi.s_KMVs;
        List<Double> intersection = new ArrayList(listi);
        List<Double> union = new ArrayList(listi);
        int minK = itemi.K;
        
        for(int i = 1; i < items.length; i++){
            int index  = this.itemHashtable.get(items[i]);
            AprioriItem tempItemi = this.singletons.get(index);
            int tempK = tempItemi.K;
            List<Double> tempListi = tempItemi.s_KMVs;
            intersection = this.FindInterSection(intersection, tempListi);            
            if(intersection.size() == 0){
                return null;
            }
//            System.out.println(minK);
            if (minK > tempK) {
                minK = tempK;
            }
            
//            union.removeAll(tempListi);
//            union.addAll(tempListi);
            union = this.findUnion(union, tempListi);
        }
        
        if(intersection.size() == 0){
            return null;
        }
//        System.out.println(minK + "\t minum" );
        int secSize = intersection.size();
//        Collections.sort(union);
//String s1 = "5945";
//String s2 = "1866";

        double KMV = union.get(minK - 1);

        double KMV1 = union.get(union.size() - 1);
        double maxK = union.size();
        
        double oldEstimation = (secSize*1.0/minK)*((minK - 1)/KMV);
        double newEstimation = secSize/maxKMV;
        double newEstimation1 = (secSize*1.0/maxK)*((maxK - 1)/KMV1);
//        System.out.println(minK + "\t" +KMV +"\t" + union.size()+"\t"+ items.length + "\t" + maxKMV + "\t" + this.K*1.0/this.N);
if(items.length == 2)
        System.out.println(maxK/minK + "\t" + items.length);
        
        double[] results = new double[4];
        results[0] = oldEstimation;
        results[1] = newEstimation;
        results[2] = newEstimation1;
        results[3] = secSize;
        
        return results;
    }
    
    public ArrayList<FrequentItemset> loadItemset(String fileName, String split){
        fileOperator fo = new fileOperator();
        ArrayList<FrequentItemset> arrayList = new ArrayList(); 
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String tokens[] = line.split(split);
            String itemset = tokens[0].trim();
            int Count = Integer.parseInt(tokens[1].trim());
            FrequentItemset freqItemset = new FrequentItemset();
            freqItemset.setItemSet(itemset);
            freqItemset.setCount(Count);
            arrayList.add(freqItemset);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        
        return arrayList;
    }    
    
     public double[][] estimateError(ArrayList<FrequentItemset> arrayList){
        int S = arrayList.size();
        double[][] countsMatrix = new double[S][];
        for(int i = 0; i < S; i++){
            if(i%500 == 0){
                System.out.println(i);
            }
            countsMatrix[i] = new double[5];
            FrequentItemset itemseti = arrayList.get(i);
            countsMatrix[i][0] = itemseti.count;
            String itemset = itemseti.itemset;
            double[] estimation = new double[4];
            if(itemset.equals("3234 1866")){
                System.out.println("Here");
            }
                
            String tokens[] = itemset.split(" ");
            estimation = this.CountEstimation(tokens);
            if(estimation==null){
                continue;
            }
            countsMatrix[i][1] = estimation[0];
            countsMatrix[i][2] = estimation[1];
            countsMatrix[i][3] = estimation[2];
            countsMatrix[i][4] = tokens.length;
//            System.out.println(estimation[0] + "\t" + estimation[1] + "\t" + itemseti.count);
        }
        return countsMatrix;
    }

 public double[][] estimateError1(ArrayList<FrequentItemset> arrayList){
        int S = arrayList.size();
        double[][] countsMatrix = new double[S][];
        for(int i = 0; i < S; i++){
            if(i%500 == 0){
                System.out.println(i);
            }
            countsMatrix[i] = new double[6];
            FrequentItemset itemseti = arrayList.get(i);
            countsMatrix[i][0] = itemseti.count;
            String itemset = itemseti.itemset;
            double[] estimation = new double[4];
            if(itemset.equals("3234 1866")){
                System.out.println("Here");
            }
                
            String tokens[] = itemset.split(" ");
            estimation = this.CountEstimation1(tokens);
            if(estimation==null){
                continue;
            }
            countsMatrix[i][1] = estimation[0];
            countsMatrix[i][2] = estimation[1];
            countsMatrix[i][3] = estimation[2];
            countsMatrix[i][4] = estimation[3];
            countsMatrix[i][5] = tokens.length;
//            System.out.println(estimation[0] + "\t" + estimation[1] + "\t" + itemseti.count);
        }
        return countsMatrix;
    }
 
     public double[][] estimateErrorTest(ArrayList<FrequentItemset> arrayList){
        int S = arrayList.size();
        double[][] countsMatrix = new double[S][];
        for(int i = 0; i < S; i++){
//            if(i%500 == 0){
//                System.out.println(i);
//            }
            countsMatrix[i] = new double[5];
            FrequentItemset itemseti = arrayList.get(i);
            countsMatrix[i][0] = itemseti.count;
            String itemset = itemseti.itemset;
            double[] estimation = new double[4];
            if(itemset.equals("3234 1866")){
                System.out.println("Here");
                String tokens[] = itemset.split(" ");
             estimation = this.CountEstimation(tokens);
             System.out.println(estimation[0]+"\t" +estimation[1]);
            }
                
            
            if(estimation==null){
                continue;
            }

//            System.out.println(estimation[0] + "\t" + estimation[1] + "\t" + itemseti.count);
        }
        return countsMatrix;
    }
     
       public  void saveCounts(String fileName, double[][] counts) throws IOException{
                File file = new File(fileName);
        if(!file.exists()){
            file.createNewFile();
        }
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        for(int i = 0; i < counts.length; i++){
            String line = "";
            line = line + counts[i][0] + "\t" + counts[i][1] + "\t" + counts[i][2] + "\t" + counts[i][3] + "\t" + counts[i][4];
            fo.writeFile(line);
        }
        fo.closeWriteFile();
    }  
       
        public  void saveCounts1(String fileName, double[][] counts) throws IOException{
                File file = new File(fileName);
        if(!file.exists()){
            file.createNewFile();
        }
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        for(int i = 0; i < counts.length; i++){
            String line = "";
            line = line + counts[i][0] + "\t" + counts[i][1] + "\t" + counts[i][2] + "\t" + counts[i][3] + "\t" + counts[i][4] + "\t" + counts[i][5];
            fo.writeFile(line);
        }
        fo.closeWriteFile();
    }         
    
    public static void main(String[] args) throws IOException{
//        String sourceFileName = "C:\\Users\\String\\Desktop\\testData\\test.txt";
//String KMVFileName = "C:\\Users\\String\\Desktop\\testData\\test_KMV.txt";
        String fileName = "tweets_RemoveII";
        String filePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\data sets\\";
        String KMVFileName = filePath + "KMVSampleData\\sample_"+ fileName + ".data";
        
        

        String trueFrequentFileName =  "C:\\Users\\String\\Document Sources\\SIGMOD\\AllFIMResults\\tweets_RemoveII_all_support_0.002.dat";
        String savefilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\FrequencyEstimation\\T10New\\";
        
        String sourceFileName = filePath + fileName + ".data";
        long N = 13445364;
        int A = 100000;
        for(int i = 1; i < 11; i++){
            int K = i*A;
        EstimationErrorAnalysis KMV = new EstimationErrorAnalysis(N, K, sourceFileName, KMVFileName);
        KMV.setSeed(N*46);
        KMV.dataSampleWithReplacement();
        KMV.GenerateIDList();
        KMV.InvertSketchConstruction();
        ArrayList<FrequentItemset> arrayList = KMV.loadItemset(trueFrequentFileName, ":");
        
        System.out.println(arrayList.size());
//        double[][] countMatrix = KMV.estimateError(arrayList);
        
         double[][] countMatrix = KMV.estimateError1(arrayList);
         for(int j  = 0; j < countMatrix.length; j++){
             countMatrix[j][4] = countMatrix[j][4] * N /K;
         }
        KMV.saveCounts1(savefilePath + fileName + "_K_" + K  + ".txt", countMatrix);
        }
//        System.out.println(slapTime);
        
//        Collections.sort(KMV.ItemList);
//        for(int i = 0; i < KMV.ItemList.size(); i++){
//            System.out.println(KMV.ItemList.get(i).name + "\t" + KMV.ItemList.get(i).K/KMV.ItemList.get(i).KMV);
//        }
    }
}
