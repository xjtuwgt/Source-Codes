/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysisNew;

import fileUtil.fileHandle;
import fileUtil.fileOperator;

/**
 *
 * @author String
 */
public class runtimeExtraction {
    public static String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewExperimentalResults\\IBM\\R\\";
    public static void main(String[] args){
        fileHandle fh = new fileHandle();
        String[] fileNames = fh.getFileNames(filePath, "txt", true);
        double[][] runtimes = new double[fileNames.length][];
        
        for(int i = 0; i < fileNames.length; i++){
            runtimes[i] = new double[12];
            double K = ExtractNumber(fileNames[i]);
            runtimes[i][0] = K;
            double s = ExtractSupport(fileNames[i]);
            runtimes[i][1] = s;
            double[] timesi = getRuntime(filePath + fileNames[i] + ".txt");
            for(int j = 0; j < 10; j++){
                runtimes[i][j+2] = timesi[j];
            }
//            System.out.println(K);
        }
        
        for(int i = 0; i < runtimes.length; i++){
            for(int j = 0; j < runtimes[i].length; j++){
                System.out.print(runtimes[i][j]+"\t");
            }
            System.out.println();
        }
        
    }
    
    public static double ExtractNumber(String fileName) {
        String[] tokens = fileName.split("-");
        double k = Double.parseDouble(tokens[1].trim());
        return k;
    }
    
    public static double ExtractSupport(String fileName) {
        String[] tokens = fileName.split("-");
        double k = Double.parseDouble(tokens[2].trim());
        return k;
    }
    
    public static double[] getRuntime(String fileName){
        fileOperator fo = new fileOperator();
        double[] runtimes = new double[10];
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        int index = 0;
        while(line!=null){
            double d = Double.parseDouble(line.trim());
            runtimes[index] = d;
            line = fo.readByLine();
            index++;
        }
        fo.closeReadFile();
        return runtimes;
    }
}
