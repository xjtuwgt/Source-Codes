/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysisNew;

import ResultAnalysis.FrequentItemset;
import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author String
 */
public class EstimatedErrorComputation {
    
    public class ItemSetInformation {
        public HashMap<String, Integer> hashMap;
        public ArrayList<FrequentItemset> arrayList;

        public ItemSetInformation() {
            hashMap = new HashMap();
            arrayList = new ArrayList();
        }
    }
    
    public static void main(String[] args){
        
    }
    
    public ItemSetInformation LoadTrueFrequentItemsets(String fileName){
        ItemSetInformation setInfor = new ItemSetInformation();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
            int count = (int) Double.parseDouble(tokens[1].trim());
            FrequentItemset freqitems = new FrequentItemset();
            freqitems.setItemSet(itemset);
            freqitems.setCount(count);
            
            setInfor.hashMap.put(itemset, count);
            setInfor.arrayList.add(freqitems);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return setInfor;
    }
}