/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HashFunctions;

import java.util.Comparator;

/**
 *
 * @author String
 */
public class Node {
    private double hash; //hash value  
    private long tid;//the id of the transaction
    private String line;//The content of the transaction
    
    public Node(long _tid, double h, String _line) {  
        tid = _tid;
        hash = h;
        line = _line;
    }  
   
    public void setHash(double h) {  
        hash = h;  
    }  

    public double getHash() {  
        return hash;  
    }
    
    public void setID(long id) {  
        tid = id;  
    }  

    public long getID() {  
        return tid;  
    }
    public void setLine(String _line) {  
        line = _line;  
    }  

    public String getLine() {  
        return line;  
    }      
}
