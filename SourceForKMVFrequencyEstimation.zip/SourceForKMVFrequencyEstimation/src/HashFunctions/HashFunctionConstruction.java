/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HashFunctions;

import java.security.Key;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;


/**
 *
 * @author String
 */
public class HashFunctionConstruction {
    
  public static void main(String[] args) throws Exception {
    Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
    KeyGenerator generator = KeyGenerator.getInstance("AES", "BC");
    generator.init(128);
    Key keyToBeWrapped = generator.generateKey();
    System.out.println("input    : " + new String(keyToBeWrapped.getEncoded()));
   
    
    Cipher cipher = Cipher.getInstance("AESWrap", "BC");
    KeyGenerator KeyGen = KeyGenerator.getInstance("AES", "BC");
    KeyGen.init(256);
    Key wrapKey = KeyGen.generateKey();
    cipher.init(Cipher.WRAP_MODE, wrapKey);
    byte[] wrappedKey = cipher.wrap(keyToBeWrapped);
    System.out.println("wrapped : " + new String(wrappedKey));
    cipher.init(Cipher.UNWRAP_MODE, wrapKey);
    
    Key key = cipher.unwrap(wrappedKey, "AES", Cipher.SECRET_KEY);
    System.out.println("unwrapped: " + new String(key.getEncoded()));
  }    
    
//      public void KMVofHashTest(int K){
//        Comparator<Node> OrderIsdn = new Comparator<Node>() {
//            public int compare(Node o1, Node o2) {
//                // TODO Auto-generated method stub  
//                double numbera = o1.getHash();
//                double numberb = o2.getHash();
//                if (numberb > numbera) {
//                    return 1;
//                } else if (numberb < numbera) {
//                    return -1;
//                } else {
//                    return 0;
//                }
//
//            }
//        };
//        Queue priorityQueue = new PriorityQueue<>(K,OrderIsdn);
//        
//        int index = 0;
////        while(line!=null && index < K){
//          while(index < K){
////              SHAHashValue v = ComputeSHA( yourObject);
////Random r = new Random(v);
////the_random_value = r.getNext();
//            double d = Math.random();
//            Node tempNode = new Node(index,d,null);
//            priorityQueue.add(tempNode);
//            index++;
////             System.out.println(priorityQueue.size());
//
//        }
//        long N = 2000000000;
//        while(index < N){
//            double d = Math.random();
//            if(d < priorityQueue.peek().getHash()){
//                Node tempNode = new Node(index,d,null);
//                priorityQueue.poll();
//                priorityQueue.add(tempNode);
////                System.out.println(priorityQueue.size());
//            }
//            index++;            
//        }
// 
//        System.out.println(index);
////        fo.closeReadFile();
//    }

}
