/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HashFunctions;

import fileUtil.fileOperator;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 *
 * @author String
 */
public class HashFunction {
    String hashFileName = "";
    Queue<Node> priorityQueue;
    
    public HashFunction(){
        
    }
    
    public void setHashFile(String fileName){
        
    }
    
    public double getNextHashValue(){
        return 0;
    }
    
    public void KMVofHashTest(int K){
        Comparator<Node> OrderIsdn = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        priorityQueue = new PriorityQueue<>(K,OrderIsdn);
        
//        fileOperator fo = new fileOperator();
//        nodes = new Node[K];
//        fo.openReadFile(hashFileName);
//        String line = fo.readByLine();
        int index = 0;
//        while(line!=null && index < K){
          while(index < K){
            double d = Math.random();
            Node tempNode = new Node(index,d,null);
            priorityQueue.add(tempNode);
            index++;
//             System.out.println(priorityQueue.size());

        }
        long N = 2000000000;
        while(index < N){
            double d = Math.random();
            if(d < priorityQueue.peek().getHash()){
                Node tempNode = new Node(index,d,null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
//                System.out.println(priorityQueue.size());
            }
            index++;            
        }
 
        System.out.println(index);
//        fo.closeReadFile();
    }
    
    public void printHash(){
        System.out.println(priorityQueue.size());
        System.out.println(priorityQueue.peek().getHash());
    }
    
    public static void main(String[] args){
        HashFunction HF = new HashFunction();
        int K = 50000000;
        HF.KMVofHashTest(K);
        HF.printHash();
    }
}
