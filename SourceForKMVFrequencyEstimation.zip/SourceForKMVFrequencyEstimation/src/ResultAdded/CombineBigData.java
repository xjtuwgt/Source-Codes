/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAdded;

import fileUtil.fileHandle;
import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/**
 *
 * @author String
 */
public class CombineBigData {
    public static HashMap<String, Integer> frequentItemset;
    public static HashMap<String, Integer> frequentItems;
    public static int index = 0;
    public static int itemIndex = 0;
    public static int counts[];
    
    public static String ourFilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\BigData\\eKFP\\";
    public static String minedFilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\BigData\\KFP\\";
    public static String dataFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\NewSplit\\1.data";
    public static String resultFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\NewSplit\\Counts\\1.txt";
    
    
    public static ArrayList<String> loadMindedFrequentItemsets(String fileName){
        ArrayList<String> arrayList = new ArrayList();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while (line != null) {
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
            String items[] = itemset.split(" ");
            String key = sortTokens(items);
//            String key = tokens[0].trim();
//            int count = (int) Double.parseDouble(tokens[1].trim());
            arrayList.add(key);
            if(!frequentItemset.containsKey(key)){
                frequentItemset.put(key, index);
                index++;
            }
            for(int i = 0; i < items.length; i++){
                if(!frequentItems.containsKey(items[i])){
                    frequentItems.put(key, itemIndex);
                    itemIndex++;
                }
            }
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return arrayList;
    }    
    
    public static void main(String[] args){
        fileHandle fh = new fileHandle();
        String[] kfileNames = fh.getFileNames(ourFilePath, "dat");
        String[] RfileNames = fh.getFileNames(minedFilePath, "dat");
        
        frequentItemset = new HashMap();
        frequentItems = new HashMap();
    
        for (int i = 0; i < kfileNames.length; i++) {
            loadMindedFrequentItemsets(ourFilePath + kfileNames[i]);
        }
        for (int i = 0; i < RfileNames.length; i++) {
            loadMindedFrequentItemsets(minedFilePath + RfileNames[i]);
        }
        
        counts = new int[frequentItemset.size()];
        for(int i = 0; i < counts.length; i++){
            counts[i] = 0;
        }
//        Iterator temp = frequentItemset.entrySet().iterator();
//        while(temp.hasNext()){
//            String line = temp.next().toString();
//            String[] tokens = line.split("=");
//            System.out.println(tokens[1]);
////            System.out.println(temp.next());
//        } 

       String[] itemsets = new String[frequentItemset.size()];
       

        Iterator temp = frequentItemset.entrySet().iterator();
        int tempindex = 0;
        while(temp.hasNext()){
            String line = temp.next().toString();
            String[] tokens = line.split("=");
            System.out.println(tokens[0]);
            tempindex = Integer.parseInt(tokens[1].trim());
//            String items[] = tokens[0].split(",");
            itemsets[tempindex] = tokens[0];
//            System.out.println(temp.next());
        }  
        
        System.out.println(itemsets.length);
        constructBitMap();
        //ScanDataBase(itemsets);
        //PrintResult(itemsets);
    }
    
    public static BitSet[] constructBitMap(){
        BitSet[] bitSet = new BitSet[frequentItems.size()];
        for(int i = 0; i < bitSet.length; i++){
            bitSet[i] = new BitSet(5000000);
        }
        fileOperator fo = new fileOperator();
        fo.openReadFile(dataFilePath);
        String line = fo.readByLine();
        int sind = 0;
        while(line!=null){
            String[] tokens = line.split(" ");
            HashMap<String, Integer> hashmap = new HashMap();
            Set<String> set = frequentItems.keySet();
            Iterator iter = set.iterator();
            while(iter.hasNext()){
                String item = iter.next().toString();
                int itemIndex = frequentItems.get(item);
                if(hashmap.containsKey(item)){
                    bitSet[itemIndex].set(sind);
                }
            }
            sind++;
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return bitSet;
    }
    
    public static void ScanDataBase(String[] itemsets){
//        String[] itemsets = new String[frequentItemset.size()];
        fileOperator fo = new fileOperator();
        fo.openReadFile(dataFilePath);
        String line = fo.readByLine();
        int sind = 0;
        while(line!=null){
            String[] tokens = line.split(" ");
            HashMap<String, Integer> hashmap = new HashMap();
            for (int i = 0; i < tokens.length; i++) {
                hashmap.put(tokens[i], i);
            }
            for(int i = 0; i < itemsets.length; i++){
                String itemseti = itemsets[i];
                String[] items = itemseti.split(",");
                if(updateCount(hashmap, items)){
                    counts[i]++;
                }
            }
            line = fo.readByLine();
            sind++;
            if(sind%100000 == 0){
                System.out.println(sind);
            }
        }
        fo.closeReadFile();
    }
    
    public static void PrintResult(String[] itemsets){
        fileOperator fo = new fileOperator();
        fo.openWriteFile(resultFilePath);
        for(int i = 0; i < itemsets.length; i++){
                String itemseti = itemsets[i];
                System.out.println(itemseti + "\t" + counts[i]);
                fo.writeFile(itemseti + "\t" + counts[i]);
            }
        fo.closeWriteFile();
    }
    
    public static boolean updateCount(HashMap<String, Integer> hashmap, String[] items){
//        int k = 0;
        for(int i = 0; i < items.length; i++){
            if(!hashmap.containsKey(items[i])){
                return false;
            }
        }
        return true;
    }
    
//    public static 
    
    
    
    
    
    public static String sortTokens(String[] tokens) {
        ArrayList<String> arrayList = new ArrayList();
        for (int i = 0; i < tokens.length; i++) {
            arrayList.add(tokens[i]);
        }
        
//        if(tokens.length > 3)
        Collections.sort(arrayList);
        String line = "";
        for (int i = 0; i < arrayList.size(); i++) {
            line = line + arrayList.get(i).toString()+",";
        }
        return line;
    }    
    
}
