/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAdded;

import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 *
 * @author String
 */
public class VaryLengthAnalysis {
    public static void main(String[] args){
        String trueFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewExperimentalResults\\AllResults\\Retail\\";
        String trueFileName = "retail_Extend500_all_support_0.008.dat";
//        String trueFileName = "trueCounts.txt";
        
//        String mineFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewResutls-Added\\KOrder\\Tweet\\";
        String mineFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\ExtendResults\\Retail\\";
//        String mineFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\RResult\\Retail\\";
        String mineFileName = "";
        
        Hashtable hashtable = loadTrueFrequentItemset(trueFilePath + trueFileName);
        int N = 10;
        for (int i = 1; i <= N; i++) {
            mineFileName = "retail_Extend50043992838KMV_K =203388_support_0.008_close_0.1_Seed_"+i+ ".dat";
            ArrayList arrayList = loadMinedFrequentItemset(mineFilePath + mineFileName);
            double[] metrics = PrecisionRecall(hashtable, arrayList);
            System.out.println(metrics[0] + "\t" + metrics[1]);
        }
    }
    
    public static Hashtable<String, Integer> loadTrueFrequentItemset(String fileName){
        fileOperator fo = new fileOperator();
        Hashtable<String, Integer>  hashTable = new Hashtable();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line != null){
            String[] tokens = line.split(":");
            String key = tokens[0].trim();
            int value = Integer.parseInt(tokens[1].trim());
            hashTable.put(key, value);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return hashTable;
    }
    
    public static Hashtable<String, Integer> loadTrueFrequentItemsetIBM(String fileName){
        fileOperator fo = new fileOperator();
        Hashtable<String, Integer>  hashTable = new Hashtable();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line != null){
            String[] tokens = line.split("	");
            String key = tokens[0].trim();
            double value = Double.parseDouble(tokens[1].trim());
            int val = (int) value;
            if(value >= 0.01*366947989){
            hashTable.put(key, val);}
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return hashTable;
    }
    
    public static ArrayList<String> loadMinedFrequentItemset(String fileName){
        ArrayList<String> arrayList = new ArrayList();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line != null){
            String[] tokens = line.split(":");
            String key = tokens[0].trim();
//            int value = Integer.parseInt(tokens[1].trim());
            arrayList.add(key);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return arrayList;
    }
    
    public static double[] PrecisionRecall(Hashtable<String, Integer> hashtab, ArrayList<String> arrayLi){
        int T = hashtab.size();
        int R = arrayLi.size();
//        System.out.println(T + "\t" + R);
        int C = 0;
        for(int i = 0; i < arrayLi.size(); i++){
            String key = arrayLi.get(i);
            if(hashtab.containsKey(key)){
                C++;
            }
        }
        double[] metrics = new double[2];
        metrics[0] = C*1.0/T;
        metrics[1] = C*1.0/R;
        
        return metrics;
    }
}
