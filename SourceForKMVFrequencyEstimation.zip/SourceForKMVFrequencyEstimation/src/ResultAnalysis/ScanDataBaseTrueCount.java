/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysis;

import static ResultAnalysis.FrequentItemSetResultParsing.sortFrequentItemset;
import fileUtil.fileHandle;
import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/**
 *
 * @author String
 */
public class ScanDataBaseTrueCount {

//    public static HashMap<String, Integer> itemsetMap;
    public static HashMap<String, Integer> stringArray;
    public static ArrayList<String> itemsetArray;
//    public static HashMap<String, Integer> tokenArray;
    public static double[] counts;
    public static int Index = 0;
    public static int tokenIndex = 0;
    public static String sourceFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\IBM_BigData.data";
        public static    String RFilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\BigData\\KFP\\";
    public static    String kFilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\BigData\\eKFP\\"; 

    public static void main(String[] args) {
//        //tweets_RemoveIKMV_K =188755_support_0.01_close_0.1_Seed_1
//        //tweets_RemoveIR_sample_K =188755_support_0.01_close_0.1Seed_1
//
 
        fileHandle fh = new fileHandle();
        String[] RFileNames = fh.getFileNames(RFilePath, "dat");
        String[] KFileNames = fh.getFileNames(kFilePath, "dat");
        
        stringArray = new HashMap();
        itemsetArray = new ArrayList();
        
        for(int i = 0; i < RFileNames.length; i++){
            loadFrequentItemSet(RFilePath + RFileNames[i]);
        }
        
        for(int j = 0; j < KFileNames.length; j++){
            loadFrequentItemSet(kFilePath + KFileNames[j]);
        }
        
//        int count = ScanDataBaseItem("4549");
//        System.out.println(count);

//        Iterator temp = stringArray.entrySet().iterator();
//        while(temp.hasNext()){
//            System.out.println(temp.next().toString());
//        }
//        counts = new double[stringArray.size()];
////        scanDatabase();
////        int counttmp = stringArray.get("the");
////        System.out.println(counttmp);
////        String[] itemsets = (String[]) stringArray.keySet().toArray();
////        Set temp = stringArray.entrySet();
////Set temp = stringArray.keySet();
////        for(int i = 0; i < temp.size(); i++){
////            String itemset = (String) temp.toArray()[i];
////            System.out.println(itemset + "\t" + stringArray.get(itemset));
////        }
////        System.out.println(itemsetMap.size());
//        
//        scanDatabase();
//        
//        for(int i = 0; i < counts.length; i++){
//            System.out.println(counts[i]);
//        }



    }
    
    public static int ScanDataBaseItem(String item){
              fileOperator fo = new fileOperator();
        fo.openReadFile(sourceFileName);
        String line = fo.readByLine();
        int index = 0;
        int tempcount = 0;
        while(line!=null){
            if(index%10000000==0)
            System.out.println(index);
            String[] tokens = line.split(" ");
            for(int i = 0; i < tokens.length; i++){
                if(item.equals(tokens[i])){
                    tempcount++;
                }
            }
//            HashMap tempHash = intersection(tokens);
//            countFrequency(tempHash);
            line = fo.readByLine();
            index++;
        }
        fo.closeReadFile();  
        return tempcount;
    }

    public static void loadFrequentItemSet(String fileName) {
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while (line != null) {
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
//            int count = Integer.parseInt(tokens[1].trim());
            if (!stringArray.containsKey(itemset)) {
//                itemsetMap.put(itemset, count);
                stringArray.put(itemset, Index);
                itemsetArray.add(itemset);
                Index++;
//                String[] tokenTemps = itemset.split(" ");
//                for(int i = 0; i < tokenTemps.length; i++){
//                    if(!tokenArray.containsKey(tokenTemps[i].trim())){
//                        tokenArray.put(tokenTemps[i].trim(), tokenIndex);
//                        tokenIndex++;
//                    }
//                }
            }
            line = fo.readByLine();
        }
        fo.closeReadFile();
    }
    
    public static void scanDatabase(){
        fileOperator fo = new fileOperator();
        fo.openReadFile(sourceFileName);
        String line = fo.readByLine();
        int index = 0;
        while(line!=null){
            
            System.out.println(index);
            String[] tokens = line.split(" ");
            HashMap tempHash = intersection(tokens);
//            System.out.println(tempHash.size() + "\t" + tokens.length);
            countFrequency(tempHash);
            line = fo.readByLine();
            index++;
        }
        fo.closeReadFile();
    }
    
    public static void countFrequency(HashMap tempHash){
        for(int i = 0; i < itemsetArray.size(); i++){
            String itemset = itemsetArray.get(i);
            String[] tokens = itemset.split(" ");
            if(isContain(tempHash, tokens)){
                int index = stringArray.get(itemset);
                counts[index]++;
            }
        }
//        itemsetMap
    }
    
    public static boolean isContain(HashMap tempHash, String[] tokens){
        if(tempHash.size()<tokens.length){
            return false;
        }
        
        int k = 0;
        for(int i = 0; i < tokens.length; i++){
            if(!tempHash.containsKey(tokens[i].trim())){
                return false;
            }else{
                k++;
            }
        }
        
        return true;
    }
    
    public static HashMap intersection(String[] tokens){
        HashMap<String, Integer> temp = new HashMap();
        int index = 0;
        for(int i = 0; i < tokens.length; i++){
            if(!temp.containsValue(tokens[i].trim())){
                temp.put(tokens[i].trim(), index);
                index++;
            }
//            if(tokenArray.containsKey(tokens[i].trim())){
//                int k = tokenArray.get(tokens[i].trim());
//                if(!temp.containsKey(tokens[i].trim())){
//                    temp.put(tokens[i].trim(), k);
//                }
////                temp.put(tokens[i], stringArray.get(i))
//            }
        }
        return temp;
    }
}
