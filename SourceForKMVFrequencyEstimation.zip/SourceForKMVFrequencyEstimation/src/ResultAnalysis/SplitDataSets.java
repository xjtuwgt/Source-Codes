/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysis;

import fileUtil.fileOperator;

/**
 *
 * @author String
 */
public class SplitDataSets {
    public static String sourceFileName = "C:\\Users\\String\\Document Sources\\"
            + "FIM Datasets\\Synthetic Data\\IBM_BigData.data";
    
    public static String splitFilePath = "C:\\Users\\String\\Document Sources\\"
            + "FIM Datasets\\Synthetic Data\\NewSplit\\";
    
    public static void main(String []args){
        fileOperator fo = new fileOperator();
        fo.openReadFile(sourceFileName);
        String line = fo.readByLine();
        int index = 1;
        int fileIndex = 1;
        fo.openWriteFile(splitFilePath + fileIndex + ".data");
        while(line!=null){
            if(index%5000000 == 0){
                fo.writeFile(line);
                fo.closeWriteFile();
                fileIndex++;
                fo.openWriteFile(splitFilePath + fileIndex + ".data");
                System.out.println(fileIndex);
            }else{
                fo.writeFile(line);
            }
            line = fo.readByLine();
            index++;
        }
        fo.closeReadFile();
        fo.closeWriteFile();
    }
}
