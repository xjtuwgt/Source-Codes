/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysis;

import fileUtil.fileOperator;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**
 *
 * @author String
 */
public class FrequentItemSetResultParsing {

    public static String allFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Experimental Results\\Results Tweets\\tweets_RemoveII_all_support_0.005.dat";

    public static ArrayList<FrequentItemset> itemSetList;

    public static HashMap<String, Integer> itemSetMap;
    
//    int[] counts = {111955,112677,112677,113400};
//    int[] counts = {11195476,11267723,11267723,11339970};
    

    public static void main(String[] args) {
        //tweets_RemoveIKMV_K =188755_support_0.01_close_0.1_Seed_1
        //tweets_RemoveIR_sample_K =188755_support_0.01_close_0.1Seed_1
        LoadAllResults();
//        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Experimental Results\\Results Tweets\\ResultR_Tweet\\";
        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Experimental Results\\Results Tweets\\ResultK_Tweet\\";
        int K = 113400;
        double support = 0.005;
        double close = 0.1;
//        String preFix = "R_sample_K =";
        String preFix = "KMV_K =";
        int M = 0;
        for(int i = 0; i < 30; i++){
            String fileName = filePath + preFix + K + "_support_"+support+"_close_"+close+"_Seed_"+(i+1)+".dat";
            ArrayList resulti = loadMinedResults(fileName);
            sortFrequentItemset(resulti);
//            showResults(resulti);
//            double precision = topKItemsetExtraction(resulti, 20);
//            System.out.println(precision);
            double count = closeFrequentItemset(resulti);
//            if(count !=  itemSetList.size()){
//                M++;
//            }
            System.out.println(count/resulti.size() + "\t" + count/itemSetList.size());
//            File file = new File(fileName);
//            System.out.println(file.exists());
//            System.out.println(fileName);
        }
//        System.out.println(M/100.0);

//LoadAllResults();
    }
    
    public static double[] topKItemset(ArrayList<FrequentItemset> mined, int K){
        double[] results = new double[2];
        double precition = 0;
        double recall = 0;
        double count = 0;
        for(int i = 0; i < K; i++){
            FrequentItemset truei = itemSetList.get(i);
            FrequentItemset tempi = mined.get(i);
            
            String itemset = tempi.itemset;
            if(itemSetMap.containsKey(itemset)){
               count++;
            }            
        }
        return results;
    }
    
    
    public static double topKItemsetExtraction(ArrayList<FrequentItemset> mined, int K){
//        double[] results = new double[2];
        double precition = 0;
//        double recall = 0;
        double count = 0;
        HashMap<String, Integer> tempHashMap = new HashMap();
        for(int i = 0; i < K; i++){
            FrequentItemset truei = itemSetList.get(i);
            tempHashMap.put(truei.itemset, truei.count);      
        }
        
        for (int i = 0; i < K; i++) {
            FrequentItemset tempi = mined.get(i);
            if(tempHashMap.containsKey(tempi.itemset)){
                count++;
            }
        }
        precition = count/K;
        return precition;
    }    
    
    public static double closeFrequentItemset(ArrayList<FrequentItemset> mined){
        int count = 0;
        int N = mined.size();
        for(int i = 0; i < mined.size(); i++){
            FrequentItemset tempi = mined.get(i);
            String itemset = tempi.itemset;
            if(itemSetMap.containsKey(itemset)){
               count++;
            }
        }
        
        return count;
    }
    
    public static void showResults(ArrayList<FrequentItemset> results){
        for(int i = 0; i < results.size(); i++){
            FrequentItemset tempItemset = results.get(i);
            System.out.println(tempItemset.itemset + "\t" + tempItemset.count);
        }
    }
    
    public static void LoadAllResults(){
        readAllDataFile();
        sortFrequentItemset(itemSetList);
//        for (int i = 0; i < itemSetList.size(); i++) {
//            FrequentItemset tempItemset = itemSetList.get(i);
//            System.out.println(tempItemset.count + "\t" + tempItemset.itemset);
//        }        
    }
    
    public static ArrayList loadMinedResults(String fileName){
        ArrayList<FrequentItemset> results = new ArrayList();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while (line != null) {
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
            int count = Integer.parseInt(tokens[1].trim());

            FrequentItemset freqItem = new FrequentItemset();
            freqItem.setCount(count);
            freqItem.setItemSet(itemset);
            results.add(freqItem);
            line = fo.readByLine();
        }        
        fo.closeReadFile();
        sortFrequentItemset(results);
        return results;
    }

    public static void readAllDataFile() {
        fileOperator fo = new fileOperator();
        fo.openReadFile(allFileName);
        String line = fo.readByLine();
        itemSetMap = new HashMap();
        itemSetList = new ArrayList();

        while (line != null) {
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
            int count = Integer.parseInt(tokens[1].trim());

            FrequentItemset freqItem = new FrequentItemset();
            freqItem.setCount(count);
            freqItem.setItemSet(itemset);
            itemSetList.add(freqItem);
            if (!itemSetMap.containsKey(itemset)) {
                itemSetMap.put(itemset, count);
            }
            line = fo.readByLine();
        }
        fo.closeReadFile();
    }

    public static void sortFrequentItemset(ArrayList<FrequentItemset> array) {
        Collections.sort(array);
    }
}
