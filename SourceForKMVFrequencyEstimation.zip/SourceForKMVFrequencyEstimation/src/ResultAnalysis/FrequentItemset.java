/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysis;

/**
 *
 * @author String
 */
public class FrequentItemset implements Comparable<FrequentItemset>{
    public FrequentItemset(){
    }
    
    public String itemset;
    public int count;
    public int rank;
    
    public void setRank(int r){
        rank = r;
    }
    
    public void setItemSet(String str){
        itemset = str;
    }
    public void setCount(int cou){
        count = cou;
    }


    @Override
    public int compareTo(FrequentItemset o) {
        int mycount = o.count;

        //ascending order
        return mycount - this.count;
    }
}
