/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysis;

/**
 *
 * @author String
 */
public class Node implements Comparable<Node>{
    public String itemset;
    public int count;
    public int index;
    
    public void setItemSet(String str){
        itemset = str;
    }
    public void setCount(int cou){
        count = cou;
    }
    
    public void setIndex(int ind){
        index = ind;
    }

    @Override
    public int compareTo(Node o) {
                int mycount = o.count;

        //ascending order
        return mycount - this.count;
    }
}
