/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysis;

import fileUtil.fileOperator;

/**
 *
 * @author String
 */
public class SumCount {
    public static String countFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\";
    public static void main(String[] args){
        fileOperator fo = new fileOperator();
        double[][] counts = new double[6061][];
        for(int i = 0; i < 6061; i++){
            counts[i] = new double[8];
            for(int j = 0; j < 8; j++){
                counts[i][j] = 0;
            }
        }
        for(int i = 1; i <= 8; i++){
            fo.openReadFile(countFilePath + "count" + i + ".txt");
            String line = fo.readByLine();
            int num = 0;
            while(line != null){
//                System.out.println(line);
                counts[num][i-1] = Double.parseDouble(line.trim());
                line = fo.readByLine();               
                num++;
            }
            fo.closeReadFile();
//            System.out.println(i + "\t" + num);
        }
        
        for(int i = 0; i < 6061; i++){
            for(int j = 0; j < 8; j++){
                System.out.print(counts[i][j] + "\t");
            }
            System.out.println();
        }
    }
}
