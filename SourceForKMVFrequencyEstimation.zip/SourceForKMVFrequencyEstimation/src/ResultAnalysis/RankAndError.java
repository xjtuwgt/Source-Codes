/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysis;

import fileUtil.fileHandle;
import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**
 *
 * @author String
 */
public class RankAndError {
    public static String countFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Experimental Results\\Results Tweets\\RankCount.txt";
    public static String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Experimental Results\\Results Tweets\\ResultK_Tweet\\";
//    public static String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Experimental Results\\Results Tweets\\ResultR_Tweet\\";
    
    public static ArrayList readAllFrequency(String fileName){
        ArrayList<FrequentItemset> arrayList = new ArrayList();
        fileOperator fo = new fileOperator();
        fo.openReadFile(countFileName);
        String line = fo.readByLine();
        while (line != null) {
//            System.out.println(line);
            String[] tokens = line.split(",");
//            System.out.println(tokens.length);
            String itemset = tokens[0].trim();
            int count = Integer.parseInt(tokens[2].trim());
            FrequentItemset fitemset = new FrequentItemset();
            fitemset.setItemSet(itemset);
            fitemset.setCount(count);
//            hashmap.put(itemset, count);
            arrayList.add(fitemset);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return arrayList;      
    }
    
    
    
    public static void main(String[] args){
        int K = 111955;
        double support = 0.01;
        double close = 0.1;
//        String preFix = "R_sample_K =";
        String preFix = "KMV_K =";
        
//        HashMap hashmap = loadAllCounts(countFileName);
ArrayList arrayList = readAllFrequency(countFileName);
        fileHandle fh = new fileHandle();
//        String[] fileNames = fh.getFileNames(filePath, "dat");
        for(int i = 0; i <30; i++){
            String fileNamei = filePath + preFix + K + "_support_"+support+"_close_"+close+"_Seed_"+(i+1)+".dat";
//            ArrayList arrayList = LoadSingleFile(fileNamei);
HashMap hashmap = loadSingleFile(fileNamei);
double d = rankCorrelationShip(hashmap, arrayList, 150);
System.out.println(1-d);
//            double[] resulti =  rankCorrelation(hashmap, arrayList, 150);
//            System.out.println( resulti[0] + "\t" +resulti[1]);
        }
    }
    
    public static double[] rankCorrelation(HashMap hashmap, ArrayList<FrequentItemset> arrayList, int K){
        if(K < 0){
            K = arrayList.size();
        }
        double correlation = 0;
        double rmse = 0;
        sortFrequentItemset(arrayList);
        ArrayList<FrequentItemset> tempCounts = new ArrayList();
        double[] preCounts = new double[K];
        double[] realCounts = new double[K];
        for(int i = 0; i < K; i++){
            FrequentItemset temp = (FrequentItemset) arrayList.get(i);
            String itemset = temp.itemset;
            preCounts[i] = temp.count*13444493/111955;
            FrequentItemset temp1 = new FrequentItemset();
            temp1.setItemSet(itemset);
            if(hashmap.containsKey(itemset)){
                double value = Double.parseDouble(hashmap.get(itemset).toString());
                temp1.setCount((int) value);
                realCounts[i] = value;
                tempCounts.add(temp1);
            }
        }
        rmse = RMSE(preCounts, realCounts);
        correlation = rankCorrelation(tempCounts);
        double[] array = new double[2];
        array[0] = 1- correlation;
        array[1] = rmse;
        return array;
    }
    
    public static double RMSE(double[] array1, double[] array2){
        double rmse = 0;
        for(int i = 0; i < array1.length; i++){
            rmse = rmse  + (array1[i] - array2[i])*(array1[i] - array2[i]);
        }
        rmse = rmse/array1.length;
        rmse = Math.sqrt(rmse);
        return rmse;
    }
    
    public static double rankCorrelation(ArrayList<FrequentItemset> arrayList){
        ArrayList<Node> temp = new ArrayList();
        double[] origRanks = new double[arrayList.size()]; 
        for(int i = 0; i < origRanks.length; i++){
            origRanks[i] = (i+1);
            FrequentItemset tempi = arrayList.get(i);
            Node nodetemp = new Node();
            nodetemp.setItemSet(tempi.itemset);
            nodetemp.setCount(tempi.count);
            nodetemp.setIndex(i);
            temp.add(nodetemp);
        }
        int K = origRanks.length;
        Collections.sort(temp);
        double[] trueRanks = new double[K];
        for(int i = 0; i < K; i++){
            Node nodeTemp = temp.get(i);
            trueRanks[nodeTemp.index] = (i+1);
        }
        double correlation = 0;
        for(int i = 0; i < K; i++){
            correlation = correlation + (origRanks[i] - trueRanks[i])*(origRanks[i] - trueRanks[i]);
        }
        
        correlation = correlation*6/(K*K*K - K);
        return correlation;
    }
    
    public static HashMap loadSingleFile(String fileName){
        HashMap<String, Integer> hashmap = new HashMap();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
            int count = Integer.parseInt(tokens[1].trim());
            hashmap.put(itemset, count);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return hashmap;
    }
    
    public static double rankCorrelationShip(HashMap hashmap, ArrayList arrayList, int K){
        if(K < 0){
            K = hashmap.size();
        }
        
  double correlation = 0;
        sortFrequentItemset(arrayList);
        ArrayList<FrequentItemset> tempCounts = new ArrayList();
        for(int i = 0; i < K; i++){
            FrequentItemset temp = (FrequentItemset) arrayList.get(i);
            String itemset = temp.itemset;
            FrequentItemset temp1 = new FrequentItemset();
            temp1.setItemSet(itemset);
            if(hashmap.containsKey(itemset)){
                double value = Double.parseDouble(hashmap.get(itemset).toString());
                temp1.setCount((int) value);
                tempCounts.add(temp1);
            }
        }
        System.out.println(tempCounts.size());
        correlation = rankCorrelation(tempCounts);    
        return correlation;
    }
    
    
    public static HashMap loadAllCounts(String fileName){
        HashMap hashmap = new HashMap();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String[] tokens = line.split(",");
            String itemset = tokens[0].trim();
            int count = Integer.parseInt(tokens[2].trim());
            hashmap.put(itemset, count);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return hashmap;
    }
    
    public static ArrayList LoadSingleFile(String fileName){
        ArrayList<FrequentItemset> arrayList = new ArrayList();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
//            System.out.println(line);
            String[] tokens = line.split(":");
//            System.out.println(tokens.length);
            String itemset = tokens[0].trim();
            int count = Integer.parseInt(tokens[1].trim());
            FrequentItemset fitemset = new FrequentItemset();
            fitemset.setItemSet(itemset);
            fitemset.setCount(count);
//            hashmap.put(itemset, count);
            arrayList.add(fitemset);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return arrayList;
    }
    
    public static void sortFrequentItemset(ArrayList<FrequentItemset> array) {
        Collections.sort(array);
    }    
}
