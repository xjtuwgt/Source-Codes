/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysis;

import fileUtil.fileHandle;
import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**
 *
 * @author String
 */
public class ResultAnalysisOnIBMData {
        public static String countFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Experimental Results\\Results-IBM\\RankCount.txt";
    public static String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Experimental Results\\Results-IBM\\ResultsK\\";
//    public static String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Experimental Results\\Results-IBM\\ResultsR\\";
    
    public static int N = 366947989;
    
   public static void main(String[] args){
        ResultAnalysisOnIBMData RCEA = new ResultAnalysisOnIBMData();
        ItemSetInformation allItemsets = RCEA.AllHashLoading(countFileName);
//        RCEA.sortFrequentItemset(allItemsets);
//        for(int i = 0; i < allItemsets.arrayList.size(); i++){
//            System.out.println(allItemsets.arrayList.get(i).count+ "\t" + allItemsets.arrayList.get(i).itemset + "\t" + allItemsets.arrayList.get(i).rank);
//        }
        fileHandle fh = new fileHandle();
        String[] fileNames = fh.getFileNames(filePath, "dat");
        for(int i = 0; i < fileNames.length; i++){
            double K = RCEA.ExtractNumber(fileNames[i]);
            double supp = RCEA.extractSupport(fileNames[i]);
//            System.out.println(K); m
//String fileNamei = filePath + "KMV_K =111955_support_0.01_close_0.1_Seed_1.dat";
            String fileNamei = filePath + fileNames[i];
            double ratio = N/K;
            double threhsold = supp*N;
            ItemSetInformation itemseti = RCEA.SingleLoading(fileNamei);
//            RCEA.sortFrequentItemset(itemseti);
//            System.out.println(threhsold + "\t" + ratio);
            System.out.println(RCEA.PrecisionComputation(allItemsets, itemseti, threhsold));
//            System.out.println("==========================================");
//                    RCEA.sortFrequentItemset(itemseti);
//        for(int i = 0; i < itemseti.arrayList.size(); i++){
//            System.out.println(itemseti.arrayList.get(i).count+ "\t" + itemseti.arrayList.get(i).itemset + "\t" + itemseti.arrayList.get(i).rank);
//        }
//            double[] resulti = RCEA.rankAndErrorComputation(allItemsets, itemseti, 150, false, ratio);
//            System.out.println(K + "\t" + resulti[0] +"\t" + resulti[1]);
        }
    }
   public double PrecisionComputation(ItemSetInformation allItemsets, ItemSetInformation mined, double threshold, int K){
       double precision = 0;
//       double N = mined.arrayList.size();
       for(int i = 0; i < K; i++){
           FrequentItemset frequenti = mined.arrayList.get(i);
           String itemset = frequenti.itemset;
           double count = allItemsets.hashMap.get(itemset);
           if(count > threshold){
               precision++;
           }
       }
       
       return precision/K;
   }
   public double PrecisionComputation(ItemSetInformation allItemsets, ItemSetInformation mined, double threshold){
       double precision = 0;
       double N = mined.arrayList.size();
       for(int i = 0; i < N; i++){
           FrequentItemset frequenti = mined.arrayList.get(i);
           String itemset = frequenti.itemset;
           double count = allItemsets.hashMap.get(itemset);
           if(count > threshold){
               precision++;
           }
       }
       
       return precision/N;
   }
  
   public double extractSupport(String fileName){
      String[] tokens = fileName.split("_");
        for(int i = 0; i < tokens.length; i++){
            if(tokens[i].contains("support")){
//                String[] subtokens = tokens[i].split("=");
                double num = Double.parseDouble(tokens[i+1].trim());
                return num;
            }
        }
        return -1; 
   }
    public double ExtractNumber(String fileName){
        String[] tokens = fileName.split("_");
        for(int i = 0; i < tokens.length; i++){
            if(tokens[i].contains("=")){
                String[] subtokens = tokens[i].split("=");
                double num = Double.parseDouble(subtokens[1].trim());
                return num;
            }
        }
        return -1;
    }
    
    
    public double[] rankAndErrorComputation(ItemSetInformation trueItemSet, ItemSetInformation minedItemSet, int K, boolean RSample, double ratio){
        if(K < 0){
            K = minedItemSet.arrayList.size();
        }
        sortFrequentItemset(trueItemSet);
        sortFrequentItemset(minedItemSet);
        
//                for(int i = 0; i < trueItemSet.arrayList.size(); i++){
//            System.out.println(trueItemSet.arrayList.get(i).count+ "\t" + trueItemSet.arrayList.get(i).itemset + "\t" + trueItemSet.arrayList.get(i).rank);
//        }
//        System.out.println("=================================================");
//                   for(int i = 0; i < minedItemSet.arrayList.size(); i++){
//            System.out.println(minedItemSet.arrayList.get(i).count+ "\t" + minedItemSet.arrayList.get(i).itemset + "\t" + minedItemSet.arrayList.get(i).rank);
//        }             
        
        double[] trueRanks = new double[K];
        double[] minedRanks = new double[K];
        

        
        int index = 1;
        for(int i = 0; i < K; i++){
           FrequentItemset itemseti = trueItemSet.arrayList.get(i);
           String key = itemseti.itemset;
//           trueRanks[i] = trueItemSet.hashMap.get(key);
           trueRanks[i] = itemseti.rank;
           
           if(minedItemSet.hashMap.containsKey(key)){
               for(int j = 0; j < minedItemSet.arrayList.size(); j++){
                   FrequentItemset itemsetj = minedItemSet.arrayList.get(j);
                   if(itemsetj.itemset.equals(key)){
                       minedRanks[i] = itemsetj.rank;
                       break;
                   }
               }
//               int tempIndex = minedItemSet.hashMap.get(key)-1;
//               minedRanks[i] = minedItemSet.arrayList.get(tempIndex).rank;
           }else{
               minedRanks[i] = K + index;
               index++;
           }
        }
        
//        for(int i = 0; i < K; i++){
//            System.out.println(trueRanks[i] + "\t" + minedRanks[i]);
//        }
        double[] trueCounts = new double[K];
        double[] minedCounts = new double[K];
        for(int i = 0; i < K; i++){
           FrequentItemset itemseti = minedItemSet.arrayList.get(i);
           String key = itemseti.itemset;
           if(RSample){
               minedCounts[i] = itemseti.count*ratio;
           }else{
               minedCounts[i] = itemseti.count;
           }
           
           if(trueItemSet.hashMap.containsKey(key)){
               int tempIndex = trueItemSet.hashMap.get(key) - 1;
               trueCounts[i] = trueItemSet.arrayList.get(tempIndex).count;
           }else{
               trueCounts[i] = 0;
               System.out.println("Here");
           }
        }        
        
        double[] results = new double[2];
        results[0] = rankCorrealtion(trueRanks,minedRanks);
        results[1] = estimationError(trueCounts, minedCounts);
        return results;
    }
    
    public double rankCorrealtion(double[] trueRanks, double[] minedRanks){
        double corr = 0;
        double K = trueRanks.length;
        for(int i = 0; i < trueRanks.length; i++){
            corr = corr + (trueRanks[i] - minedRanks[i])*(trueRanks[i] - minedRanks[i]);
        }
        corr = 1 - corr*6/(K*K*K - K);
        return corr;
    }
    
    public double estimationError(double[] trueCounts, double[] minedCounts){
        double mrse = 0;
        double K = trueCounts.length;
        for(int i = 0; i < trueCounts.length; i++){
//            if(trueCounts[i] == 0){
//                K--;
//                continue;
//            }
            mrse = mrse + (trueCounts[i] - minedCounts[i])*(trueCounts[i] - minedCounts[i]);
        }
        mrse = mrse/K;
        mrse = Math.sqrt(mrse);
        return mrse;
    }
    
    public ItemSetInformation AllHashLoading(String fileName){
        ItemSetInformation setInfor = new ItemSetInformation();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String[] tokens = line.split(",");
            String itemset = tokens[0].trim();
            int count = Integer.parseInt(tokens[2].trim());
            FrequentItemset freqitems = new FrequentItemset();
            freqitems.setItemSet(itemset);
            freqitems.setCount(count);
            
            setInfor.hashMap.put(itemset, count);
            setInfor.arrayList.add(freqitems);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        
        return setInfor;
    }
    
    public ItemSetInformation SingleLoading(String fileName){
        ItemSetInformation setInfor = new ItemSetInformation();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
            int count = Integer.parseInt(tokens[1].trim());
            FrequentItemset freqitems = new FrequentItemset();
            freqitems.setItemSet(itemset);
            freqitems.setCount(count);
            
            setInfor.hashMap.put(itemset, count);
            setInfor.arrayList.add(freqitems);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        
        return setInfor;
    }
    
    public void sortFrequentItemset(ItemSetInformation itemsetInfor) {
        Collections.sort(itemsetInfor.arrayList);
        for(int i = 0; i < itemsetInfor.arrayList.size(); i++){
            FrequentItemset itemseti = itemsetInfor.arrayList.get(i);
            itemseti.setRank(i+1);
            String itemvalues = itemseti.itemset;
            itemsetInfor.hashMap.replace(itemvalues, itemsetInfor.hashMap.get(itemvalues), i+1);
        }
    } 
    
    
        public class ItemSetInformation{
        public HashMap<String, Integer> hashMap;
        public ArrayList<FrequentItemset> arrayList;
        public ItemSetInformation(){
            hashMap = new HashMap();
            arrayList = new ArrayList();
        }
    }
}
