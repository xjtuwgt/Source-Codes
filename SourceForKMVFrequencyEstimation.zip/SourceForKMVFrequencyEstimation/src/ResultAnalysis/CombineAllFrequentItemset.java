/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ResultAnalysis;

import fileUtil.fileHandle;
import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 *
 * @author String
 */
public class CombineAllFrequentItemset {

    public static HashMap<String, Integer> stringArray;
    public static ArrayList<String> itemsetArray;
    public static HashMap<String, Integer> tokenArray;
//    public static String kFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Experimental Results\\Results Tweets\\ResultK_Tweet\\";
//    public static String RFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Experimental Results\\Results Tweets\\ResultR_Tweet\\";
//    public static    String RFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewExperimentalResults\\IBM\\R\\";
//    public static    String kFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewExperimentalResults\\IBM\\K\\"; 
    
    public static    String RFilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\BigData\\KFP\\";
    public static    String kFilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\BigData\\eKFP\\";     
    public static double[] counts;
    public static int Index = 0;
    public static int tokenIndex = 0;
//    public static String sourceFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\tweets_RemoveII.txt";
    public static String sourceFilePath = "C:\\Users\\String\\Document Sources\\"
            + "FIM Datasets\\Synthetic Data\\split\\";
    public static String countFilePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\split\\1.data";

    public static void main(String[] args) {
//        int fileIndex = Integer.parseInt(args[0]);
        fileHandle fh = new fileHandle();
        String[] kfileNames = fh.getFileNames(kFilePath, "dat");
        String[] RfileNames = fh.getFileNames(RFilePath, "dat");
        stringArray = new HashMap();
        tokenArray = new HashMap();
        itemsetArray = new ArrayList();
        Index = 0;
        for (int i = 0; i < kfileNames.length; i++) {
            loadFrequentItemSet(kFilePath + kfileNames[i]);
        }
        for (int i = 0; i < RfileNames.length; i++) {
            loadFrequentItemSet(RFilePath + RfileNames[i]);
        }
        counts = new double[stringArray.size()];
//        scanDatabase(fileIndex);
Iterator temp = stringArray.entrySet().iterator();
while(temp.hasNext()){
    System.out.println(temp.next().toString());
}     
//        fileOperator fo = new fileOperator();
//        fo.openWriteFile(countFilePath + "count" + fileIndex + ".txt");
//        for (int i = 0; i < counts.length; i++) {
//            System.out.println(counts[i]);
//            fo.writeFile(counts[i]+"");
//        }
//        fo.closeWriteFile();
    }

    public static HashMap intersection(String[] tokens) {
        HashMap<String, Integer> temp = new HashMap();
        int index = 0;
        for (int i = 0; i < tokens.length; i++) {
            if (tokenArray.containsKey(tokens[i].trim())) {
                if (!temp.containsValue(tokens[i].trim())) {
                    temp.put(tokens[i].trim(), index);
                    index++;
                }
            }
        }
        return temp;
    }

    public static void scanDatabase(int fileIndex) {
        fileOperator fo = new fileOperator();
        fo.openReadFile(sourceFilePath + fileIndex+".data");
        String line = fo.readByLine();
        int index = 0;
        while (line != null) {
            if(index%100000==0){
                System.out.println(index);
            }
            String[] tokens = line.split(" ");
            HashMap tempHash = intersection(tokens);
//            System.out.println(tempHash.size() + "\t" + tokens.length);
            countFrequency(tempHash);
            line = fo.readByLine();
            index++;
        }
        fo.closeReadFile();
    }

    public static void countFrequency(HashMap tempHash) {
        for (int i = 0; i < itemsetArray.size(); i++) {
            String itemset = itemsetArray.get(i);
            String[] tokens = itemset.split(" ");
            if (isContain(tempHash, tokens)) {
                int index = stringArray.get(itemset);
                counts[index]++;
            }
        }
//        itemsetMap
    }

    public static boolean isContain(HashMap tempHash, String[] tokens) {
        if (tempHash.size() < tokens.length) {
            return false;
        }

        int k = 0;
        for (int i = 0; i < tokens.length; i++) {
            if (!tempHash.containsKey(tokens[i].trim())) {
                return false;
            } else {
                k++;
            }
        }

        return true;
    }

    public static void loadFrequentItemSet(String fileName) {
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while (line != null) {
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
            if (!stringArray.containsKey(itemset)) {
                stringArray.put(itemset, Index);
                itemsetArray.add(itemset);
                Index++;
                String[] words = itemset.split(" ");
                for(int i = 0; i < words.length; i++){
                    if(!tokenArray.containsKey(words[i].trim())){
                        tokenArray.put(words[i].trim(), tokenIndex);
                        tokenIndex++;
                    }
                }
            }
            line = fo.readByLine();
        }
        fo.closeReadFile();
    }
}
