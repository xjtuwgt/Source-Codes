/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BaseLineMethods;

import BaseLineMethods.Apriori.AprioriItem;
import BaseLineMethods.Apriori.AprioriItemSet;
import HashFunctions.Node;
import KMVSynopsis.FASTOffLineKMVConstructionHugeData;
import KMVSynopsis.Item;
import closefrequentitemsetmining.FrequentItemSets;
import closefrequentitemsetmining.StaticParameters;
import fileUtil.fileOperator;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.Vector;

/**
 *
 * @author String
 */
public class BasicAprioriMethodCommandLine {

    public class Edge {

        Integer node1, node2;

        public Edge(int n1, int n2) {
            node1 = n1;
            node2 = n2;
        }

        public int getLeftNode() {
            return node1;
        }

        public int getRightNode() {
            return node2;
        }

        public int hashCode() {
            return this.node1.hashCode() * this.node2.hashCode();
        }

        @Override
        public boolean equals(Object compareTo) {
            if (!(compareTo instanceof Edge)) {
                return false;
            }
            Edge o = (Edge) compareTo;
            if (!node1.equals(o.node1)) {
                return false;
            }
            if (!node2.equals(o.node2)) {
                return false;
            }
            return true;
        }

//    public boolean equals(Object compareTo) {
//      if (!(compareTo instanceof Item)) {
//        return false;
//      }
//      
//      Item b = (Item)compareTo;
//      if (name.equals(b.getName()) && K == b.getK()) {
//        return true;
//      }
//      
//      return false;
//    }
    }

    protected double s_minSupport = 0.01;
    protected double s_closePara = 0.01;
    
    protected int s_maxItems = -1;
    protected long N = 0;
    public int K = 200;
    
    public int tempK = 0;
    public Queue<Node> priorityQueue;//Sort by hash values
    public Queue<Node> TIDpriorityQueue;//Sort by transIDs

    public fileOperator s_dataSource;//Read
    public fileOperator s_KMVDataSource;//Write
    public String s_dataSourceName;//Source data
    public String s_KMVDataSourceName;//Sampling data
    FASTOffLineKMVConstructionHugeData s_KMVConstruction;
    //========================================================================== 

//    public fileOperator s_dataSource;//Read
//    public String s_dataSourceName;
    ArrayList<AprioriItem> singletons;
    Hashtable<String, Integer> itemHashtable;
    HashMap<Edge, Integer> SketchGraph;
    
    public void setSupportThrehold(double supp){
        s_minSupport = supp;
    }
    
    public void setCloseParameter(double closePara){
        s_closePara = closePara;
    }

//    ArrayList<Edge> SketchGraph;
    protected Vector<AprioriItemSet> m_largeItemSets;

    public BasicAprioriMethodCommandLine() {
    }

    public BasicAprioriMethodCommandLine(long n, int k, String sourceName, String KMVName) {
        N = n;
        K = k;
        s_dataSourceName = sourceName;
        s_KMVDataSourceName = KMVName;
    }

    public void dataSampleWithReplacement() {
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };

        Random rand = new Random();
        rand.setSeed(seed);
        priorityQueue = new PriorityQueue<>(K, OrderOnHash);
        int TID = 0;
        while (TID < K) {//Buffering data
//            double d = Math.random();
double d = rand.nextDouble();
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            TID++;
        }

        while (TID < N) {//Sampling process
//            double d = Math.random();
double d = rand.nextDouble();
            if (d < priorityQueue.peek().getHash()) {
                Node tempNode = new Node(TID, d, null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            TID++;
        }
    }

    public void GenerateIDList() {
        Comparator<Node> OrderOnID = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                long numbera = o1.getID();
                long numberb = o2.getID();
                if (numberb > numbera) {
                    return -1;
                } else if (numberb < numbera) {
                    return 1;
                } else {
                    return 0;
                }

            }
        };

        TIDpriorityQueue = new PriorityQueue<>(K, OrderOnID);
        while (!priorityQueue.isEmpty()) {
            Node node = priorityQueue.poll();
            TIDpriorityQueue.add(node);
        }
        priorityQueue.clear();
        System.out.println(priorityQueue.size() + "\t Here" + TIDpriorityQueue.toArray().length);
        priorityQueue = null;
    }

    public void InvertSketchAndGraphContruction() {
        s_dataSource = new fileOperator();
        s_KMVDataSource = new fileOperator();
        s_dataSource.openReadFile(s_dataSourceName);
        s_KMVDataSource.openWriteFile(s_KMVDataSourceName);
        int hashIndex = 0;//Hash value
        int edgeHashIndex = 0;
        itemHashtable = new Hashtable<String, Integer>();
        SketchGraph = new HashMap<Edge, Integer>();

        singletons = new ArrayList();
//        System.out.println(TIDpriorityQueue.size()+"======================I'am Here");
        int index = 0;
        long scanIndex = 0;//can the original data set
        Node node = TIDpriorityQueue.poll();
        long sampleID = node.getID();
        String line = s_dataSource.readByLine();
        while (index < K && line != null) {
//            System.out.println(index);
            if (line.trim().equals("")) {
                line = s_dataSource.readByLine();
                continue;
            }
            while (scanIndex < sampleID && line != null) {
                if (line.trim().equals("")) {
                    line = s_dataSource.readByLine();
                    continue;
                }
//                System.out.println(scanIndex + "\t" + sampleID);
                line = s_dataSource.readByLine();
                scanIndex++;
            }
            if (scanIndex == sampleID) {//sampled transactions
                s_KMVDataSource.writeFile(line);
                String[] tokens = line.split(StaticParameters.splitKey);
                for (int i = 0; i < tokens.length; i++) {
                    if (itemHashtable.containsKey(tokens[i].trim())) {//update
                        int itemIndex = itemHashtable.get(tokens[i]);
                        AprioriItem temp = singletons.get(itemIndex);
                        temp.increaseCount();
                        temp.addKMV(node.getHash());
                    } else {//New item
                        itemHashtable.put(tokens[i], hashIndex);
                        AprioriItem temp = new AprioriItem(tokens[i]);
//                        temp.increaseCount();
                        temp.addKMV(node.getHash());
                        singletons.add(temp);
                        hashIndex++;
                    }
                    for (int j = i + 1; j < tokens.length; j++) {
                        if (!itemHashtable.containsKey(tokens[j].trim())) {//update
                            itemHashtable.put(tokens[j], hashIndex);
                            AprioriItem temp = new AprioriItem(tokens[j]);
//                            temp.increaseCount();
                            temp.addKMV(node.getHash());
                            singletons.add(temp);
                            hashIndex++;
                        }

                        int indi = itemHashtable.get(tokens[i]);
                        int indj = itemHashtable.get(tokens[j]);
                        Edge edge;
                        if (indi < indj) {
                            edge = new Edge(indi, indj);
                        } else {
                            edge = new Edge(indj, indi);
                        }
                        if (SketchGraph.containsKey(edge)) {
//                            System.out.println("Here");
                            SketchGraph.replace(edge, SketchGraph.get(edge) + 1);
                        } else {
                            SketchGraph.put(edge, 1);
                            edgeHashIndex++;
                        }
                    }
                }
//                System.out.println(index + "\t" + sampleID + "\t" + scanIndex);
                if (TIDpriorityQueue.isEmpty()) {
                    System.out.println(scanIndex + "I am here!!\t" + index);
//                    System.out.println(scanIndex + "\t" + index + "\t" + TIDpriorityQueue.size() + "\t One items " + singletons.size() + "\t" + hashIndex +  "\t Two items" + SketchGraph.size());
                    TIDpriorityQueue.clear();;
                    TIDpriorityQueue = null;
                    s_dataSource.closeReadFile();
                    s_KMVDataSource.closeWriteFile();
//                    for (int i = 0; i < singletons.size(); i++) {
//                        AprioriItem tempItem = singletons.get(i);
//                        Collections.sort(tempItem.s_KMVs);
//                        tempItem.KMV = tempItem.s_KMVs.get(tempItem.K - 2);
//                        tempItem.frequency = tempItem.K / tempItem.KMV;
//                        System.out.println(tempItem.itemName + "\t count " + tempItem.K + "\t" + tempItem.frequency);
//                    }
                    return;
                }
                node = TIDpriorityQueue.poll();
                sampleID = node.getID();
                index++;
            }

            line = s_dataSource.readByLine();
            scanIndex++;
        }

        System.out.println(scanIndex + "\t" + index + "\t" + TIDpriorityQueue.size() + "\t One items" + singletons.size() + "\t Two items" + SketchGraph.size());

        TIDpriorityQueue.clear();;
        TIDpriorityQueue = null;
        s_dataSource.closeReadFile();
        s_KMVDataSource.closeWriteFile();
    }

    public Vector<AprioriItemSet> getFrequnetOneItemSet() {
        Vector<AprioriItemSet> oneItemSet = new Vector();
        AprioriItemSet tempItemSet;
        for (int i = 0; i < singletons.size(); i++) {
            AprioriItem tempItem = singletons.get(i);
            Collections.sort(tempItem.s_KMVs);
            String name = tempItem.getName();
            int hashIndex = itemHashtable.get(name);
            int items[] = new int[1];
            items[0] = hashIndex;
            tempItemSet = new AprioriItemSet((int) N, items);
            tempItemSet.m_KMV = tempItem.s_KMVs.get(tempItem.K - 1);
            tempItemSet.s_K = tempItem.K;
            tempItemSet.s_frequency = tempItemSet.s_K / tempItemSet.m_KMV;
            if ((tempItemSet.s_frequency > N * s_minSupport*(1-this.s_closePara/2))&&(tempItem.K > tempK)) {
                oneItemSet.add(tempItemSet);
                this.m_largeItemSets.add(tempItemSet);
            }
        }
        return oneItemSet;
    }

    public Vector<AprioriItemSet> generateTwoItemSet(Vector<AprioriItemSet> oneItemSet) {
        int size = oneItemSet.size();
        Vector<AprioriItemSet> twoVector = new Vector();

        AprioriItemSet tempItemSet;

        for (int i = 0; i < size; i++) {
            AprioriItemSet seti = oneItemSet.elementAt(i);
            int itemi = seti.m_items[0];
            AprioriItem AprItemi = singletons.get(itemi);
            List listi = AprItemi.s_KMVs;
            int ki = seti.s_K;
            for (int j = i + 1; j < size; j++) {
                AprioriItemSet setj = oneItemSet.elementAt(j);
                int itemj = setj.m_items[0];
                AprioriItem AprItemj = singletons.get(itemj);
                List listj = AprItemj.s_KMVs;
                int kj = setj.s_K;

//                int tempi, tempj;
//                boolean flag = false;
                int secSize = 0;
                Edge edge;
                if (itemi > itemj) {
                    edge = new Edge(itemj, itemi);

                } else {
                    edge = new Edge(itemi, itemj);
                }
                if (!SketchGraph.containsKey(edge)) {
                    continue;
                } else {
                    secSize = SketchGraph.get(edge);
                }
//                List<Double> intersection = new ArrayList<Double>(listi.size());
//                Collections.copy(intersection, listi);
//                
//                intersection.addAll(listj);
//                int secSize = intersection.size();
//                intersection.clear();
//                intersection = null;

                List<Double> union = new ArrayList<Double>(listi);
//                Collections.copy(union, listi);
                union.removeAll(listj);
                union.addAll(listj);

//                System.out.println(secSize + "\t" + listi.size() + "\t" + listj.size() + "\t" + union.size());
                Collections.sort(union);
                int k = ki > kj ? kj : ki;
                double kmv = union.get(k - 1);
                double estimator = (secSize*1.0 / k) * ((k - 1) / kmv);
               if ((estimator > N * s_minSupport * (1 - s_closePara/2))&&(k > tempK)) {
                    if (itemi < itemj) {
                        int[] tempItems = new int[2];
                        tempItems[0] = itemi;
                        tempItems[1] = itemj;
                        tempItemSet = new AprioriItemSet((int) N, tempItems);
                    } else {
                        int[] tempItems = new int[2];
                        tempItems[0] = itemj;
                        tempItems[1] = itemi;
                        tempItemSet = new AprioriItemSet((int) N, tempItems);
                    }

                    tempItemSet.setK(k);
                    tempItemSet.setKMV(kmv);
                    tempItemSet.setFrequency(estimator);
//                    System.out.println(estimator);

                    twoVector.add(tempItemSet);
                    m_largeItemSets.add(tempItemSet);
                }
//                System.out.println(secSize + "\t" +estimator);
            }
        }
        return twoVector;
    }
    
    public void findLargeItemSets(){
        if (K > 0) {
            tempK = (int) (K * this.s_minSupport);
        }
        
        m_largeItemSets = new Vector();
        int totalNumber = 0;
        Vector<AprioriItemSet> kMinusOneSets, kSets;
        
//        double minSupport = N * this.s_minSupport;
        System.out.println("Support" + "\t" + N * this.s_minSupport*(1-this.s_closePara/2));
        Vector<AprioriItemSet> singleItems = getFrequnetOneItemSet();
        totalNumber = totalNumber + singleItems.size();
        System.out.println("Single items:" + singleItems.size());
        kSets = generateTwoItemSet(singleItems);
        totalNumber = totalNumber + kSets.size();
        System.out.println("Two items:" + kSets.size());
        if(kSets.size() == 0){
            return;
        }
        
        int i = 1;
        do{
            kMinusOneSets = kSets;
            kSets = mergeAllItemSets(kMinusOneSets, i);
            i++;
            totalNumber = totalNumber + kSets.size();
            System.out.println((i+1)+ "th itemset:" + kSets.size());
        }while(kSets.size() > 0);
        
        
        System.out.println(totalNumber);
    }
    
    public Vector mergeAllItemSets(Vector<AprioriItemSet> kMinusOneSets, int size){
        Vector newVector = new Vector();
        int numFound, k;
        
        for (int i = 0; i < kMinusOneSets.size(); i++) {
            AprioriItemSet first = (AprioriItemSet)kMinusOneSets.elementAt(i);
            int[] firstItems = first.m_items;
            out:    
            for(int j = i+1; j < kMinusOneSets.size(); j++){
                AprioriItemSet second = (AprioriItemSet)kMinusOneSets.elementAt(j);
                int[] secondItems = second.m_items;
                int[] tempItems = new int[firstItems.length + 1];
                
                
                // Find and copy common prefix of size 'size'
                numFound = 0;
                k = 0;
                while (numFound < size) {
                    if (firstItems[k] == secondItems[k]) {
                        numFound++;
                        tempItems[k] = firstItems[k];
                    } else {
                        break out;
                    }
                    k++;
                }
                
                if(k < firstItems.length){
                    int firstk = firstItems[k];
                    int secondk = secondItems[k];
                    if(firstk < secondk){
                        tempItems[k] = firstk;
                        tempItems[k+1] = secondk;
                    }else{
                        tempItems[k] = secondk;
                        tempItems[k+1] = firstk;                       
                    }
                }
                
                if(!this.pruneBySketchGraph(tempItems)){
                    AprioriItemSet result = this.generateItemSet(tempItems);
                    if(result!=null){
                        newVector.add(result);
                        this.m_largeItemSets.add(result);
                    }
                }
            }
        }
        return newVector;
    }
    
    public AprioriItemSet generateItemSet(int[] items){
//        int k = items.length;
        int vi = items[0];
        AprioriItem itemi = this.singletons.get(vi);
        List<Double> listi = itemi.s_KMVs;
        List<Double> intersection = new ArrayList(listi);
        List<Double> union = new ArrayList(listi);
        int minK = itemi.K;
        
        for(int i = 1; i < items.length; i++){
            vi = items[i];
            AprioriItem tempItemi = this.singletons.get(vi);
            int tempK = tempItemi.K;
            List<Double> tempListi = tempItemi.s_KMVs;
            intersection.retainAll(tempListi);            
            if(intersection.size() == 0){
                return null;
            }
            if (minK < tempK) {
                minK = tempK;
            }
//            union.removeAll(tempListi);
            union.addAll(tempListi);
        }
        
        if(intersection.size() == 0){
            return null;
        }
        
        int secSize = intersection.size();
        Collections.sort(union);
        double KMV = union.get(minK - 1);
        
        double estimator = (secSize*1.0/minK)*((minK - 1)/KMV);
        if(estimator > N * s_minSupport * (1 - s_closePara/2)){
            AprioriItemSet itemSet = new AprioriItemSet((int) N, items);
            itemSet.setK(K);
            itemSet.setKMV(KMV);
            itemSet.setFrequency(estimator);
            return itemSet;
        }
        
        return null;
    }
    
    public boolean pruneBySketchGraph(int[] items){
        for(int i = 0; i < items.length; i++){
            int vi = items[i];
            for(int j = i+1; j < items.length; j++){
                int vj = items[j];
                Edge edge = new Edge(vi,vj);
                if(!SketchGraph.containsKey(edge)){
                    return true;
                }
            }
        }
        
        return false;
    }
    
    public Hashtable invertMap(){
        Hashtable<Integer, String> invertable= new Hashtable();
        Set<Entry<String, Integer>> set = this.itemHashtable.entrySet();
        Iterator iterator = set.iterator();
        while(iterator.hasNext()){
           Entry<String, Integer> temp = (Entry<String, Integer>) iterator.next();
           String value = temp.getKey();
           int key = temp.getValue();
           invertable.put(key, value);
        }
        return invertable;
    }
    
    public void saveAllFrequentItems(String fileName) {
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        Hashtable<Integer, String> invertable = invertMap();
        String line = "";
        for (int i = 0; i < m_largeItemSets.size(); i++) {
            AprioriItemSet temp = m_largeItemSets.elementAt(i);
            line = "";
            for(int j = 0; j < temp.m_items.length; j++){
                line = line + " " + invertable.get(temp.m_items[j]);
            }
            
            line = line + ": " + temp.s_frequency;
            fo.writeFile(line);
        }
        fo.closeWriteFile();
    }

    public static void main(String[] args) throws IOException {
//        String fileName = "accidents";
//        String sourceFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\" + fileName + ".dat";
//        String KMVFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\KMVSampleData\\KMV_"+ fileName + ".dat";    

//        String fileName = "tweets_RemoveI";
////        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\";
//        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\";
////        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\";
//        String sourceFileName = filePath + fileName + ".txt";
//        String KMVFileName = filePath + "KMVSampleData\\KMV_"+ fileName + ".data";
//        
//        double threshold = 0.01;
//        double closeParameter = 0.1;
//
//        long N = 13444493;
//        int  K =   188755;
        
        String sourceFileName = args[0];
        String KMVFileName = args[1];
        String resultFilePath = args[2];
        double threshold = Double.parseDouble(args[3]);
        double closeParameter = Double.parseDouble(args[4]);
        long N = Long.parseLong(args[5]);
        int K = Integer.parseInt(args[6]);
    
        int Pass = 3;
        double[] runtimes = new double[Pass];
//        int[] numbers = new int[100];
        for (int i = 0; i < Pass; i++) {
            seed = i + 1;
            BasicAprioriMethodCommandLine BAM = new BasicAprioriMethodCommandLine(N, K, sourceFileName, KMVFileName);
            BAM.setCloseParameter(closeParameter);
            BAM.setSupportThrehold(threshold);

            double startTime = System.currentTimeMillis();
            BAM.dataSampleWithReplacement();
            BAM.GenerateIDList();
            BAM.InvertSketchAndGraphContruction();
            BAM.findLargeItemSets();
            double endTime = System.currentTimeMillis();
            double slapTime = (endTime - startTime) / 1000;
            System.out.println(slapTime);
            runtimes[i] = slapTime;
            String resultFile = resultFilePath + "KMVApriori_K =" + K + "_support_" + threshold + "_close_" + closeParameter + "_seed_" + seed + ".dat";
            BAM.saveAllFrequentItems(resultFile);
            
        }
//        saveRuntime(resultFilePath+ "runtime"+ K + ".txt", runtimes);
        saveRuntime(resultFilePath + "runtime" +"-"+threshold+"-"+K +".txt", runtimes);
    }
    
    public static long seed = 1;
    
    public static void saveRuntime(String fileName, double[] runtimes) throws IOException{
                File file = new File(fileName);
        if(!file.exists()){
            file.createNewFile();
        }
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        for(int i = 0; i < runtimes.length; i++){
            fo.writeFile(runtimes[i]+"");
        }
        fo.closeWriteFile();
    }
}
