/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BaseLineMethods;

import HashFunctions.Node;
import java.util.Collections;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.Vector;

/**
 *
 * @author String
 */
public class BasicSamplingMethod {
    
    
   public BasicSamplingMethod(){        
   }
   
   /**
   * creates the subsample with replacement
   * 
   * @param random	the random number generator to use
   * @param origSize	the original size of the dataset
   * @param sampleSize	the size to generate
   */
  public Queue createSubsampleWithReplacement(Random random, int origSize, 
      int sampleSize) {
    Queue<Integer> sampleIndexes = new PriorityQueue<Integer>(sampleSize);
    for (int i = 0; i < sampleSize; i++) {
	int index = random.nextInt(origSize);
        sampleIndexes.add(index);
//	push((Instance) getInputFormat().instance(index).copy());
    }
    
    return sampleIndexes;
  }
  
    
  public Queue createSubsampleWithoutReplacement(Random random, int origSize, 
      int sampleSize) {
    Queue<Integer> sampleIndexes = new PriorityQueue<Integer>(sampleSize);
    if (sampleSize > origSize) {
      sampleSize = origSize;
      System.err.println(
	  "Resampling with replacement can only use percentage <=100% - "
	  + "Using full dataset!");
    }
    
//    int N = origSize;
//    int index = random.nextInt(N);
//    sampleIndexes.add(index);
//    N--;
//    for(int i = 1; i < sampleSize; i++){
//        index = random.nextInt(N);
//        int temp = sampleIndexes.element().intValue();
//        
//        N--;
//    }
    Vector<Integer> indices = new Vector<Integer>(origSize);
//    Vector<Integer> indicesNew = new Vector<Integer>(sampleSize);

    // generate list of all indices to draw from
    for (int i = 0; i < origSize; i++)
      indices.add(i);

    
    // draw X random indices (selected ones get removed before next draw)
    for (int i = 0; i < sampleSize; i++) {
      int index = random.nextInt(indices.size());
      sampleIndexes.add(indices.get(index));
//      indicesNew.add(indices.get(index));
      indices.remove(index);
    }

//    if (getInvertSelection())
//      indicesNew = indices;
//    else
//      Collections.sort(indicesNew);

//    for (int i = 0; i < indicesNew.size(); i++)
//      push((Instance) getInputFormat().instance(indicesNew.get(i)).copy());

    // clean up
    indices.clear();
//    indicesNew.clear();
    indices = null;
//    indicesNew = null;
    return sampleIndexes;
  }    
}
