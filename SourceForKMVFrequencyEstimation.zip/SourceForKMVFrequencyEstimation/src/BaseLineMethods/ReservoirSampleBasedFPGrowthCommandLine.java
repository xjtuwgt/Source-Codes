/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BaseLineMethods;

import KMVSynopsis.Item;
import closefrequentitemsetmining.FPTreeNode;
import closefrequentitemsetmining.FPTreeRoot;
import closefrequentitemsetmining.FrequentItemSets;
import closefrequentitemsetmining.FrequentItemset;
import closefrequentitemsetmining.HeaderTable;
import closefrequentitemsetmining.StaticParameters;
import fileUtil.fileOperator;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.Set;

/**
 *
 * @author String
 */
public class ReservoirSampleBasedFPGrowthCommandLine {

    protected double s_minSupport = 0.1;
    protected double s_closeParameter = 0.01;
    protected int s_maxItems = -1;
    protected long N = 0;
    protected int K = 0;

    public fileOperator s_dataSource;//Read
    public String s_dataSourceName;

    public fileOperator s_sampleSource;
    public String s_sampleSourceName;

    ArrayList<Item> singletons;
    Hashtable<String, Integer> itemHashtable;
    protected FrequentItemSets m_largeItemSets;

    public ReservoirSampleBasedFPGrowthCommandLine() {
    }

    public void setSizeOfData(int n) {
        N = n;
    }

    public void setSampleSize(int k) {
        K = k;
    }

    public void setSourceFileName(String fileName) {
        s_dataSourceName = fileName;
    }

    public void setSampleFileName(String fileName) {
        s_sampleSourceName = fileName;
    }

    public void setThreshold(double supp) {
        this.s_minSupport = supp;
    }

    public void setCloseParameter(double closePara) {
        this.s_closeParameter = closePara;
    }

    public ArrayList CreateReveroirSample(int OrigSize, int sampleSize, Random random) {

        ArrayList<Integer> sampleIndexes = new ArrayList<Integer>(sampleSize);
        if (sampleSize > OrigSize) {
            sampleSize = OrigSize;
            System.err.println(
                    "Resampling with replacement can only use percentage <=100% - "
                    + "Using full dataset!");
        }

        int currentIndex = 0;
        while (currentIndex < OrigSize) {
            if (currentIndex < sampleSize) {
                sampleIndexes.add(currentIndex);
            } else {
                double r = random.nextDouble();
                if (r < ((double) sampleSize / (double) currentIndex)) {
                    r = random.nextDouble();
                    int replace = (int) ((double) sampleSize * r);
                    sampleIndexes.set(replace, currentIndex);
                }
            }
            currentIndex++;
        }

        Collections.sort(sampleIndexes);
        return sampleIndexes;
    }

    public void dataSampleProcess() {
        Random random = new Random();
        random.setSeed(seed);
        ArrayList<Integer> sampleIndexes = CreateReveroirSample((int) N, K, random);

        System.out.println("Sampling with reveroir");
//        while(!sampleIndexes.isEmpty()){
//            System.out.println(sampleIndexes.poll().intValue());
//        }

        s_dataSource = new fileOperator();
        s_sampleSource = new fileOperator();
        s_dataSource.openReadFile(s_dataSourceName);
        s_sampleSource.openWriteFile(s_sampleSourceName);

        int index = 0;
        long scanIndex = 0;
//       
        int sampleID = sampleIndexes.get(index);
        String line = s_dataSource.readByLine();
        while (index < K && line != null) {
            if (line.trim().equals("")) {
                line = s_dataSource.readByLine();
                continue;
            }
            while (scanIndex < sampleID && line != null) {
                if (line.trim().equals("")) {
                    line = s_dataSource.readByLine();
                    continue;
                }
//                System.out.println(scanIndex + "\t" + sampleID);
                line = s_dataSource.readByLine();
                scanIndex++;
            }
//            System.out.println(index + "\t" + sampleID);
            if (scanIndex == sampleID) {//sampled transactions
                s_sampleSource.writeFile(line);
            }
            index++;
            if (index < K) {
                sampleID = sampleIndexes.get(index);
            }

            line = s_dataSource.readByLine();
            scanIndex++;

        }
        sampleIndexes.clear();;
        sampleIndexes = null;

        System.out.println("Sampling completed~~~~");
        s_dataSource.closeReadFile();
        s_sampleSource.closeWriteFile();
    }

//    public Queue createSubsampleWithReplacement(Random random, int origSize,
//            int sampleSize) {
//        Comparator<Integer> OrderOnID = new Comparator<Integer>() {
//            @Override
//            public int compare(Integer o1, Integer o2) {
//                int numbera = o1;
//                int numberb = o2;
//                if(numberb > numbera){
//                    return -1;
//                }else  if(numberb < numbera) {
//                    return 1;
//                } else {
//                    return 0;
//                }
//            }
//        };
//        
//        Queue<Integer> sampleIndexes = new PriorityQueue<Integer>(sampleSize, OrderOnID);
//        for (int i = 0; i < sampleSize; i++) {
//            int index = random.nextInt(origSize);
//            sampleIndexes.add(index);
////	push((Instance) getInputFormat().instance(index).copy());
//        }
//
//        return sampleIndexes;
//    }
    protected void getSingletons() throws Exception {
        s_dataSource = new fileOperator();
        s_dataSource.openReadFile(s_sampleSourceName);
        singletons = new ArrayList<Item>();
        itemHashtable = new Hashtable<String, Integer>();
        int hashIndex = 0;
        String line = s_dataSource.readByLine();
        while (line != null) {
            if (line.trim().equals("")) {
                line = s_dataSource.readByLine();
                continue;
            }

            String[] tokens = line.split(StaticParameters.splitKey);
            for (int i = 0; i < tokens.length; i++) {
                if (itemHashtable.containsKey(tokens[i].trim())) {//update
                    int itemIndex = itemHashtable.get(tokens[i]);
                    Item temp = singletons.get(itemIndex);
                    temp.K = temp.K + 1;
                } else {//New item
                    itemHashtable.put(tokens[i], hashIndex);
                    Item temp = new Item(tokens[i], 1);
                    singletons.add(temp);
                    hashIndex++;
                }
            }
//            N++;
            line = s_dataSource.readByLine();
        }
//        int count = 0;
//for(int i = 0; i < singletons.size(); i++){
//    System.out.println(singletons.get(i).K);
//}
//    System.out.println(singletons.size());
        s_dataSource.closeReadFile();
//        System.out.println("Number of frequent items = " + count + "Support = " + (s_minSupport * (1 - this.s_closeParameter) * N));

    }

    protected FPTreeRoot buildFPTree(String dataFileName) {
        fileOperator fo = new fileOperator();
        fo.openReadFile(dataFileName);

        FPTreeRoot tree = new FPTreeRoot();
//        double supportThreshold = s_minSupport * N;
        int supportThreshold = (int) (s_minSupport * (1 - s_closeParameter / 2) * K);

        System.out.println("Support threshold = " + supportThreshold);

        String line = fo.readByLine();
        int index = 0;
        while (line != null) {
            String[] tokens = line.split(StaticParameters.splitKey);
            ArrayList<Item> transaction = new ArrayList<Item>();
            for (int i = 0; i < tokens.length; i++) {
                int itemIndex = itemHashtable.get(tokens[i]);
                Item itemi = singletons.get(itemIndex);//如果不用排序了是否会更快
                if (itemi.K > supportThreshold) {
                    transaction.add(itemi);
                }
            }
            Collections.sort(transaction);
            tree.addItemSet(transaction, 1);
            transaction.clear();
            transaction = null;
            line = fo.readByLine();
            index++;
        }
        fo.openReadFile(dataFileName);
        return tree;
    }

    protected void mineTree(FPTreeRoot tree, FrequentItemSets largeItemSets,
            int recursionLevel, FrequentItemset conditionalItems) {

//        double minSupport = s_minSupport * N;
        int minSupport = (int) (s_minSupport * (1 - s_closeParameter / 2) * K);

        if (!tree.isEmpty(recursionLevel)) {
//            if (s_maxItems > 0 && recursionLevel >= s_maxItems) {
//                // don't mine any further
//                return;
//            }
            Map<Item, HeaderTable> headerTable = tree.getHeaderTable();//获得头表
            Set<Item> keys = headerTable.keySet();
//      System.err.println("Number of freq item sets collected " + largeItemSets.size());
            Iterator<Item> i = keys.iterator();
            while (i.hasNext()) {
                Item item = i.next();
                HeaderTable itemHeader = headerTable.get(item);
                // check for minimum support at this level
                int support = itemHeader.getProjectedCounts().getCount(recursionLevel);
                if (support >= minSupport) {
                    // process header list at this recursion level
                    for (FPTreeNode n : itemHeader.getHeaderList()) {
                        // push count up path to root
                        int currentCount = n.getProjectedCount(recursionLevel);
                        if (currentCount > 0) {
                            FPTreeNode temp = n.getParent();
                            while (temp != tree) {
                                // set/increase for the node
                                temp.increaseProjectedCount(recursionLevel + 1, currentCount);

                                // set/increase for the header table
                                headerTable.get(temp.getItem()).
                                        getProjectedCounts().increaseCount(recursionLevel + 1, currentCount);

                                temp = temp.getParent();
                            }
                        }
                    }

                    FrequentItemset newConditional = (FrequentItemset) conditionalItems.clone();

                    // this item gets added to the conditional items
                    newConditional.addItem(item);
                    newConditional.setSupport(support);

                    // now add this conditional item set to the list of large item sets
                    largeItemSets.addItemSet(newConditional);

                    // now recursively process the new tree
                    mineTree(tree, largeItemSets, recursionLevel + 1, newConditional);

                    // reverse the propagated counts
                    for (FPTreeNode n : itemHeader.getHeaderList()) {
                        FPTreeNode temp = n.getParent();
                        while (temp != tree) {
                            temp.removeProjectedCount(recursionLevel + 1);
                            temp = temp.getParent();
                        }
                    }

                    // reverse the propagated counts in the header list
                    // at this recursion level
                    for (HeaderTable h : headerTable.values()) {
                        h.getProjectedCounts().removeCount(recursionLevel + 1);
                    }
                }
            }
        }
    }

    public void FPGrowth() throws Exception {
        this.dataSampleProcess();
        this.getSingletons();
        System.out.println(N);
        FPTreeRoot tree = buildFPTree(s_sampleSourceName);
        FrequentItemSets largeItemSets = new FrequentItemSets((int) N);
        // mine the tree
        FrequentItemset conditionalItems = new FrequentItemset(new ArrayList<Item>(), 0);
        mineTree(tree, largeItemSets, 0, conditionalItems);
//        mineTree(tree, largeItemSets, 0, conditionalItems);
        tree = null;
        m_largeItemSets = largeItemSets;
        System.out.println("Support threshold: " + this.s_minSupport * (1 - this.s_closeParameter / 2) * K);
        System.out.println("Number of frequent itemsets mined: " + m_largeItemSets.size());
        System.out.println("=============================================");
//        for (int i = 0; i < m_largeItemSets.size(); i++) {
//            System.out.println(m_largeItemSets.getItemSet(i).toString());
//        }
    }

    public void saveAllFrequentItems(String fileName) throws IOException {
        File file = new File(fileName);
        if (!file.exists()) {
            file.createNewFile();
        }
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        for (int i = 0; i < m_largeItemSets.size(); i++) {
            fo.writeFile(m_largeItemSets.getItemSet(i).toString());
        }
        fo.closeWriteFile();
    }

//    public static void main(String[] args) throws Exception {
////        String fileName = "IBM_BigData";
////        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\";
//////        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\";
//////        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\";
////        String sourceFileName = filePath + fileName + ".data";
////        String sampleFileName = filePath + "SampleData\\sample_"+ fileName + ".data";
////        
////        double threshold = 0.005;
////        double closeParameter = 0.01;
////
////        long N = 366947989;
////        int  K =   8628895/2;
//        String sourceFileName = args[0];
//        String sampleFileName = args[1];
//        String resultFilePath = args[2];
//        double threshold = Double.parseDouble(args[3]);
//        double closeParameter = Double.parseDouble(args[4]);
//        long N = Long.parseLong(args[5]);
//        int B = Integer.parseInt(args[6]);
//
//        int Pass = 30;
//        int[] ratios = {100, 50, 20, 10, 5};
//
//        for (int r = 0; r < 5; r++) {
//            int K = (int) (B / (ratios[r]*1.0));
//            double[] runtimes = new double[Pass];
////        int[] numbers = new int[100];
//            for (int i = 0; i < Pass; i++) {
//                seed = i + 1;
//                System.out.println("Run pass ==============" + (i + 1));
//                double startTime = System.currentTimeMillis();
//                ReservoirSampleBasedFPGrowthCommandLine sampfpGrowth = new ReservoirSampleBasedFPGrowthCommandLine();
//                sampfpGrowth.setSourceFileName(sourceFileName);
//                sampfpGrowth.setSampleFileName(sampleFileName);
//                sampfpGrowth.setSizeOfData((int) N);
//                sampfpGrowth.setSampleSize(K);
//                sampfpGrowth.setCloseParameter(closeParameter);
//                sampfpGrowth.setThreshold(threshold);
//
//                sampfpGrowth.FPGrowth();
//                double endTime = System.currentTimeMillis();
//                double slapTime = (endTime - startTime) / 1000;
//                runtimes[i] = slapTime;
//                System.out.println("Runtime = " + slapTime + "Seed = " + seed);
//
//                String resultFile = resultFilePath +"Ratio=" +ratios[r] + "R_sample_K =" + K + "_support_" + threshold + "_close_" + closeParameter + "_Seed_" + seed + ".dat";
//                sampfpGrowth.saveAllFrequentItems(resultFile);
//            }
//
//            for (int i = 0; i < Pass; i++) {
//                System.out.println(runtimes[i]);
//            }
////        saveRuntime(resultFilePath + "runtime.txt", runtimes);
//            saveRuntime(resultFilePath + "runtime" + "-" + threshold + "-" + K +"-" + ratios[r] + ".txt", runtimes);
//
//        }
//    }
    
      public static void main(String[] args) throws Exception {
//        String fileName = "IBM_BigData";
//        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\";
////        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\";
////        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\";
//        String sourceFileName = filePath + fileName + ".data";
//        String sampleFileName = filePath + "SampleData\\sample_"+ fileName + ".data";
//        
//        double threshold = 0.005;
//        double closeParameter = 0.01;
//
//        long N = 366947989;
//        int  K =   8628895/2;
        String sourceFileName = args[0];
        String sampleFileName = args[1];
        String resultFilePath = args[2];
        double threshold = Double.parseDouble(args[3]);
        double closeParameter = Double.parseDouble(args[4]);
        long N = Long.parseLong(args[5]);
        int K = Integer.parseInt(args[6]);

        int Pass = 10;
        double[] runtimes = new double[Pass];
            for (int i = 0; i < Pass; i++) {
                seed = i + 1;
                System.out.println("Run pass ==============" + (i + 1));
                double startTime = System.currentTimeMillis();
                ReservoirSampleBasedFPGrowthCommandLine sampfpGrowth = new ReservoirSampleBasedFPGrowthCommandLine();
                sampfpGrowth.setSourceFileName(sourceFileName);
                sampfpGrowth.setSampleFileName(sampleFileName);
                sampfpGrowth.setSizeOfData((int) N);
                sampfpGrowth.setSampleSize(K);
                sampfpGrowth.setCloseParameter(closeParameter);
                sampfpGrowth.setThreshold(threshold);

                sampfpGrowth.FPGrowth();
                double endTime = System.currentTimeMillis();
                double slapTime = (endTime - startTime) / 1000;
                runtimes[i] = slapTime;
                System.out.println("Runtime = " + slapTime + "Seed = " + seed);

                String resultFile = resultFilePath + "RSample_K =" + K + "_support_" + threshold + "_close_" + closeParameter + "_Seed_" + seed + ".dat";
                sampfpGrowth.saveAllFrequentItems(resultFile);
            }
            for (int i = 0; i < Pass; i++) {
                System.out.println(runtimes[i]);
            }
            saveRuntime(resultFilePath + "runtime" + "-" + threshold + "-" + K + ".txt", runtimes);

//        }
    }

    public static void saveRuntime(String fileName, double[] runtimes) throws IOException {
        File file = new File(fileName);
        if (!file.exists()) {
            file.createNewFile();
        }
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        for (int i = 0; i < runtimes.length; i++) {
            fo.writeFile(runtimes[i] + "");
        }
        fo.closeWriteFile();
    }

    public static long seed = 1;
}
