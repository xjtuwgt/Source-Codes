/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BaseLineMethods.Apriori;

import java.util.Vector;

/**
 *
 * @author String
 */
public class AprioriItemSet {
    public int[] m_items;
    public int s_K;
    public double m_KMV;
    public double s_frequency;
    public int m_totalTransactions;
    
  public AprioriItemSet(int totalTrans) {
    m_totalTransactions = totalTrans;
  }
  

   /**
   * Constructor
   * @param totalTrans the total number of transactions in the data
   * @param array the attribute values encoded in an int array
   */
  public AprioriItemSet(int totalTrans, int[] array){
       m_totalTransactions = totalTrans;
       m_items = array;
       s_K =1;
   }
  
  public void setK(int k){
      s_K= k;
  }
  
  public void setKMV(double kmv){
      m_KMV = kmv;
  }
  
    public void setFrequency(double freq){
      s_frequency = freq;
  }
  
  public static Vector deleteItemSets(Vector itemSets, int minSupport) {
    Vector newVector = new Vector(itemSets.size());
    for (int i = 0; i < itemSets.size(); i++) {
      AprioriItemSet current = (AprioriItemSet)itemSets.elementAt(i);
      if ((current.s_frequency >= minSupport))
	newVector.addElement(current);
    }
    return newVector;
  }
  
  public boolean equals(Object itemSet) {
    if ((itemSet == null) || !(itemSet.getClass().equals(this.getClass()))) {
      return false;
    }
    if (m_items.length != ((AprioriItemSet)itemSet).m_items.length)
      return false;
    for (int i = 0; i < m_items.length; i++)
      if (m_items[i] != ((AprioriItemSet)itemSet).m_items[i])
	return false;
    return true;
  }


  /** Merges all item sets in the set of (k-1)-item sets
   * to create the (k)-item sets and updates the counters.
   * @return the generated (k)-item sets
   * @param totalTrans the total number of transactions
   * @param itemSets the set of (k-1)-item sets
   * @param size the value of (k-1)
   */
  public static Vector mergeAllItemSets(Vector itemSets, int size, int totalTrans) {
    Vector newVector = new Vector();
    AprioriItemSet result;
    int numFound, k;

    for (int i = 0; i < itemSets.size(); i++) {
      AprioriItemSet first = (AprioriItemSet)itemSets.elementAt(i);
    out:
      for (int j = i+1; j < itemSets.size(); j++) {
	AprioriItemSet second = (AprioriItemSet)itemSets.elementAt(j);
	result = new AprioriItemSet(totalTrans);
	result.m_items = new int[first.m_items.length];
        
	// Find and copy common prefix of size 'size'
	numFound = 0;
	k = 0;
	while (numFound < size) {
	  if (first.m_items[k] == second.m_items[k]) {
	    if (first.m_items[k] != -1) 
	      numFound++;
	    result.m_items[k] = first.m_items[k];
	  } else 
	    break out;
	  k++;
	}
	
	// Check difference
	while (k < first.m_items.length) {
	  if ((first.m_items[k] != -1) && (second.m_items[k] != -1))
	    break;
	  else {
	    if (first.m_items[k] != -1)
	      result.m_items[k] = first.m_items[k];
	    else
	      result.m_items[k] = second.m_items[k];
	  }
	  k++;
	}
	if (k == first.m_items.length) {
	  result.s_frequency = 0;
         
	  newVector.addElement(result);
	}
      }
    }
    return newVector;
  }  
  
}
