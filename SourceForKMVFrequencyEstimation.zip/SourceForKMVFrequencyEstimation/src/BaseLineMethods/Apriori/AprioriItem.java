/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BaseLineMethods.Apriori;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 *
 * @author String
 */
public class AprioriItem {
    public String itemName;//The name of the item
    public int K;//The count of the item in the KMV
    public List<Double> s_KMVs;//The transactions containing the item in KMV
    public double KMV;//The K minmum value of KMV for this item
    public double frequency;
    
    public AprioriItem(String item){
        itemName = item;
        K = 1;
        s_KMVs = new ArrayList<>();
    }
    
    public void increaseCount(){
        K++;
    }
    
    public void decreaseCount(){
        K--;
    }
    
    public void addKMV(double d){
        s_KMVs.add(d);   
    }
    
    public void removeKMV(double d) {
        if (!s_KMVs.isEmpty() && s_KMVs.contains(d)) {
            s_KMVs.remove(d);
        }
    }
    
    public String getName(){
        return itemName;
    }
    
    public int getK(){
        return K;
    }
    
    public List getKMVList(){
        return this.s_KMVs;
    }
    
    public double getKMV(){
//        Collections.sort(s_KMVs);
        KMV = s_KMVs.get(s_KMVs.size() - 1);
        return KMV;
    }
    
    public double getFrequency(){
        return frequency;
    }
    
}
