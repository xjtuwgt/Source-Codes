/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BaseLineMethods;

import HashFunctions.Node;
import KMVSynopsis.Item;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;

/**
 *
 * @author String
 */
public class ReservoirSample {
    
    public ReservoirSample(){
    }
  
  
    public ArrayList CreateReveroirSample(int OrigSize, int sampleSize, Random random) {

        ArrayList<Integer> sampleIndexes = new ArrayList<Integer>(sampleSize);
        if (sampleSize > OrigSize) {
            sampleSize = OrigSize;
            System.err.println(
                    "Resampling with replacement can only use percentage <=100% - "
                    + "Using full dataset!");
        }

        int currentIndex = 0;
        while(currentIndex < OrigSize){
            if(currentIndex < sampleSize){
                sampleIndexes.add(currentIndex);
            }else{
                double r = random.nextDouble();
                if(r < ((double)sampleSize/(double)currentIndex)){
                    r = random.nextDouble();
                    int replace = (int) ((double)sampleSize*r);
                    sampleIndexes.set(replace, currentIndex);
                }
            }
            currentIndex++;
        }

        Collections.sort(sampleIndexes);
        return sampleIndexes;
    }
    
      public void KMVConstructionOnData(int N, int K){
//      
        Comparator<Node> OrderIsdn = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };//Node records the Trans ID
        Queue<Node> priorityQueue = new PriorityQueue<>(K,OrderIsdn);
        
        long index = 0;
        while(index < K){
            //====================================
            double d = Math.random();
            Node tempNode = new Node(index, d, "");
            priorityQueue.add(tempNode);
            index++;
        }
        //======================================================================
        if(index == K){//Buffer is full
               while(index < N ){
               double d = Math.random();
               if (d < priorityQueue.peek().getHash()) {//Update the KMV synopsis                   
                   Node tempNode = priorityQueue.poll();//Delete one                  
                   Node newNode = new Node(index, d, "");
                   priorityQueue.add(newNode);//Add one
//                System.out.println(priorityQueue.size());
               }
               index++;
           }
        }
        Iterator contents = priorityQueue.iterator();
        ArrayList<Integer> sampleId = new ArrayList();
        while(contents.hasNext()){
            Node node = (Node) contents.next();
//            System.out.println(node.getID());
            sampleId.add((int)node.getID());
        }
        Collections.sort(sampleId);
        System.out.println("=======================================");
          for (int i = 0; i < sampleId.size(); i++) {
              System.out.println(sampleId.get(i));
          }
    }
    
    public static void main(String[] args){
        int N = 100000;
        int M = 100;
        long randseed = 1;
        Random rand = new Random(randseed);
        ReservoirSample RSample = new ReservoirSample();
        ArrayList sampleIndexes = RSample.CreateReveroirSample(N, M, rand);
        for(int i = 0; i < sampleIndexes.size(); i++){
            System.out.println(sampleIndexes.get(i));
        }
        
        System.out.println("=======================================");
        RSample.KMVConstructionOnData(N, M);
    }
}
