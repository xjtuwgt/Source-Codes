/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

/**
 *
 * @author String
 */
public class ExcelFileReader {
    
    public static void main(String[] args) throws FileNotFoundException, IOException, BiffException{
String csvFile = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\Twitter Data sets\\tweets\\tweets.csv";
String fileSaver = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\Twitter Data sets\\tweets\\tweets.txt";
fileOperator fo = new fileOperator();
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = "\",\"";
        long count = 0;
        try 
        {
            fo.openWriteFile(fileSaver);
            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) 
            {
                
                // use comma as separator
                String[] country = line.split(cvsSplitBy);
                if(country.length >= 2){
//                System.out.println(country[1]);
count++;
                fo.writeFile(country[1]);
                }
//                System.out.println("Country [code= " + country[4] + " , name=" + country[5] + "]");
            }

            fo.closeWriteFile();
           System.out.println(count);
        }
        catch (FileNotFoundException e) 
        {
            e.printStackTrace();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        } 
        finally 
        {
            if (br != null) 
            {
                try 
                {
                    br.close();
                } 
                catch (IOException e) 
                {
                    e.printStackTrace();
                }
            }
        }
        System.out.println("Done");
    }
}
