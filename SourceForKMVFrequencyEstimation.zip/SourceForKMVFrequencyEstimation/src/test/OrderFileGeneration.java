/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

/**
 *
 * @author String
 */
public class OrderFileGeneration {
    public class Element implements Comparable<Element> {

        public int value;
        public int index;

        public Element(int v, int i) {
            value = v;
            index = i;
        }

        @Override
        public int compareTo(Element o) {
            return (int) Math.signum(o.value - this.value);
        }
    }
    
    
    public static void main(String[] args){
        int N = 0;
        String filePath = "";
        String fileName = filePath + "IBMWeight.txt";
        OrderFileGeneration orderFile = new OrderFileGeneration();
//        ArrayList arrayList = orderFile.loadArray(fileName);
//        System.out.println(arrayList.size());
//        String sortFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewResutls-Added\\All Results\\TweetSortWeight.txt";
//        Collections.sort(arrayList);
//        orderFile.writeSortFile(sortFileName, arrayList);
        String OOFileName = filePath + "IBMOrder\\OO.txt";
        String ROFileName = filePath + "IBMOrder\\RO.txt";
        String RandOFileName = filePath + "IBMOrder\\RandO.txt";
        String SRandOFileName = filePath + "IBMOrder\\SRO.txt";
        
        String FreqFirstFileName = filePath + "IBMOrder\\FreqFirst.txt";
        String FreqMidFileName = filePath +  "IBMOrder\\FreqMid.txt";
        String FreqLastOFileName = filePath + "IBMOrder\\FreqLast.txt";        

        N = 366947989;
        int K = 100000;
//        orderFile.writeOOSortFile(OOFileName, N);
//        orderFile.writeROSortFile(ROFileName, N);
        orderFile.writeRandOrderSortFile(RandOFileName, N);
        orderFile.writeSegmentRandomOrder(SRandOFileName, N, K);
        
System.out.println("I'am Herre");
//        orderFile.writeFreqFirstFile(FreqFirstFileName, arrayList);
//        orderFile.writeFreqMidFile(FreqMidFileName, arrayList);
//        orderFile.writeFreqLastFile(FreqLastOFileName, arrayList);
    }
    
    public void writeFreqFirstFile(String fileName, ArrayList<Element> arrayList){
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        for(int i = 0; i < arrayList.size(); i++){
            Element elementi = (Element) arrayList.get(i);
            fo.writeFile(elementi.index+"");
//            System.out.println(elementi.value + "\t" + elementi.index);
        }
        fo.closeWriteFile();
    }
    
    public void writeSegmentRandomOrder(String fileName, int N, int K){
        
                        Comparator<Element> OrderOnID = new Comparator<Element>() {
            public int compare(Element o1, Element o2) {
                // TODO Auto-generated method stub  
                long numbera = o1.value;
                long numberb = o2.value;
                if (numberb > numbera) {
                    return -1;
                } else if (numberb < numbera) {
                    return 1;
                } else {
                    return 0;
                }

            }
        };
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        int M = N/K;
        int[] segMents = new int[M+1];
        Random rand = new Random();
        rand.setSeed(1);
        ArrayList<Element> arrayList = new ArrayList();
        for(int i = 0; i < M; i++){
            segMents[i] = i*K;
            int randi = rand.nextInt();
            Element eli = new Element(randi, i);
            arrayList.add(eli);
        }
        Collections.sort(arrayList,OrderOnID);
        segMents[M] = N;
        for(int i = 0; i < M; i++){
            Element eli = arrayList.get(i);
            int indexi = eli.index;
            for(int j = segMents[indexi]; j < segMents[indexi+1]; j++){
                fo.writeFile(j+"");
            }
        }
        fo.closeWriteFile();
    }
    
    public void writeFreqMidFile(String fileName, ArrayList<Element> arrayList){
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        int K = 0;
        int N = arrayList.size();
        for(int i = arrayList.size() - 1; i > 0 ; i--){
            Element elementi = (Element) arrayList.get(i);
            if(elementi.value == 0){
                K++;
            }
        }
        
        for(int i = 0; i < K/2; i++){
            Element elementi = (Element) arrayList.get(N - 1 - i);
            fo.writeFile(elementi.index+"");
        }
        
        for(int i = 0; i < N - K/2; i++){
            Element elementi = (Element) arrayList.get(i);
            fo.writeFile(elementi.index+"");            
        }
        fo.closeWriteFile();
    }
    
    public void writeFreqLastFile(String fileName, ArrayList<Element> arrayList){
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        for(int i = arrayList.size()-1; i > 0; i--){
            Element elementi = (Element) arrayList.get(i);
            fo.writeFile(elementi.index+"");
//            System.out.println(elementi.value + "\t" + elementi.index);
        }
        fo.closeWriteFile();
    }    
    
    public void writeROSortFile(String fileName, int N){
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        for(int i = 0; i < N; i++){
//            Element elementi = (Element) arrayList.get(i);
            fo.writeFile((N- 1 - i)+"");
            System.out.println(i);
        }
        fo.closeWriteFile();
    }
    
    public void writeOOSortFile(String fileName, int N){
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        for(int i = 0; i < N; i++){
//            Element elementi = (Element) arrayList.get(i);
            fo.writeFile(i+"");
//            System.out.println(i);
        }
        fo.closeWriteFile();
    }    
    
    public void writeRandOrderSortFile(String fileName, int N) {
                Comparator<Element> OrderOnID = new Comparator<Element>() {
            public int compare(Element o1, Element o2) {
                // TODO Auto-generated method stub  
                long numbera = o1.value;
                long numberb = o2.value;
                if (numberb > numbera) {
                    return -1;
                } else if (numberb < numbera) {
                    return 1;
                } else {
                    return 0;
                }

            }
        };
        ArrayList<Element> arrayList = new ArrayList();
        Random rand = new Random();
        rand.setSeed(1);
        for(int i = 0; i < N; i++){
            int randi = rand.nextInt();
            Element eli = new Element(randi, i);
            arrayList.add(eli);
        }
        Collections.sort(arrayList,OrderOnID);
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        for (int i = 0; i < N; i++) {
            Element elementi = (Element) arrayList.get(i);
            fo.writeFile(elementi.index + "");
            if(i%10000000==0){
                System.out.println(i);
            }
//            
        }
        fo.closeWriteFile();
    }
    
    public ArrayList loadArray(String fileName){
        ArrayList<Element> arrayList = new ArrayList();
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        int index = 0;
        while(line != null){
            int value = Integer.parseInt(line.trim());
            Element element = new Element(value,index);
            arrayList.add(element);
            line = fo.readByLine();
            if(index%10000000==0){
                System.out.println(index);
            }
            index++;
        }
        fo.closeReadFile();
        return arrayList;
    }
    
    
    
    

}
