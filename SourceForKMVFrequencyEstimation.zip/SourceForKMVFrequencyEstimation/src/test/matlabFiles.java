/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileHandle;

/**
 *
 * @author String
 */
public class matlabFiles {
    public static void main(String[] args){
        fileHandle fh = new fileHandle();
        String filePath = "C:\\Users\\String\\Document Sources\\TKDD\\All Classification Problems\\Coding Data\\";
        String[] fileNames = fh.getFileNames(filePath, "csv", true);
        StringBuffer sb = new StringBuffer();
        sb.append("clear all; clc;\n");
        sb.append("metricMatrix = zeros(59,16);\n");
        String matfilePath = "\'C:\\Users\\String\\Document Sources\\TKDD\\All Classification Problems\\Coding Data\\";
        for(int i = 0; i < fileNames.length; i++){
//            System.out.println(fileNames[i]);
            String fileNamei = matfilePath + fileNames[i] + ".csv\'";
            sb.append("fileName = " + fileNamei + ";\n");
            sb.append("data = csvread(fileName,2,1);\n");
            sb.append("N = size(data,2);\n");
            sb.append("metricMatrix(" + (i + 1) +",:) = NumericFeatureExtraction(data(:,[1:(N-1)]));\n");
            sb.append("%====================================\n\n");
        }

         
         System.out.println(sb.toString());
    }
}
