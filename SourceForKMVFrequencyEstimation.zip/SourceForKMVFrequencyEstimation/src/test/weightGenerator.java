/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;
import java.util.HashMap;

/**
 *
 * @author String
 */
public class weightGenerator {
    public static void main(String[] args){
        String fileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewResutls-Added\\All Results\\Retail.txt";
        String dataFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewDataSets\\Orig\\retail_Extend500.txt";
        
        String saveFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewResutls-Added\\All Results\\RetailWeight.txt";
        fileOperator fo = new fileOperator();
        HashMap<String, Integer> hashMap = new HashMap();
        fo.openReadFile(fileName);
        int index = 0;
        String line = fo.readByLine();
        while(line != null){
            hashMap.put(line.trim(), index);
            index++;
            line = fo.readByLine();
        }
        fo.closeReadFile();
        
        fo.openWriteFile(saveFileName);
        fo.openReadFile(dataFileName);
        line = fo.readByLine();
        while(line != null){
            String[] tokens = line.split(" ");
            System.out.println(tokens.length);
            int count = countTokens(tokens, hashMap);
            fo.writeFile(count+"");
            line = fo.readByLine();
        }
        fo.closeReadFile();
        fo.closeWriteFile();
    }
    
    public static int countTokens(String[] tokens, HashMap hashmap){
        int count = 0;
        for(int i = 0; i < tokens.length; i++){
            if(hashmap.containsKey(tokens[i].trim())){
                count++;
            }
        }
        return count;
    }
}
