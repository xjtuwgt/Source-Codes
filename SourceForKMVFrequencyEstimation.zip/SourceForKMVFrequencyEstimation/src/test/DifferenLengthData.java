/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;

/**
 *
 * @author String
 */
public class DifferenLengthData {
    public static void main(String[] args){
        String fileN = "tweets_RemoveII";
        String fileName = "C:\\Users\\String\\Document Sources\\SIGMOD\\data sets\\";
        String filePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\VaryLengh\\Data\\";
        for(int i = 1; i < 11; i++){
            int N = i*1000000;
            writeFile(fileName + fileN+".data", filePath + fileN + N + ".data", N);
        }
    }
    
    public static void writeFile(String sourefileName, String saveFileName, int N){
        fileOperator fo = new fileOperator();
        fo.openReadFile(sourefileName);
        fo.openWriteFile(saveFileName);
        String line = fo.readByLine();
        int index = 0;
        while(index < N){
            fo.writeFile(line);
            fo.readByLine();
            line = fo.readByLine();
        }
        fo.closeReadFile();
        fo.closeWriteFile();
    }
}
