/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import ResultAnalysis.Node;
import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 *
 * @author Stri
 */
public class RSampleData {
    public static void main(String[] args){
        String trueFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewExperimentalResults\\AllResults\\Retail\\retail_Extend500_all_support_0.001.dat";
        String estimatedFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewExperimentalResults\\VarySize\\Retail\\R\\RSample_K =439_support_0.01_close_0.1_Seed_1.dat";
        
        fileOperator fo = new fileOperator();
        
    }
    
    
    public static Hashtable<String, Integer> loadTrueCount(String fileName){
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        Hashtable<String, Integer> hashtable = new Hashtable();
        String line = fo.readByLine();
        while(line!=null){
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
            int count = Integer.parseInt(tokens[1].trim());
            hashtable.put(itemset, count);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        return hashtable;
    }
    

        public static ArrayList<Node> loadEstimatedCount(String fileName){
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
//        Hashtable<String, Integer> hashtable = new Hashtable();
ArrayList<Node> arrayList = new ArrayList();
        String line = fo.readByLine();
        while(line!=null){
            String[] tokens = line.split(":");
            String itemset = tokens[0].trim();
            int count = Integer.parseInt(tokens[1].trim());
            Node node = new Node();
            node.setItemSet(itemset);
            node.setCount(count);
            arrayList.add(node);
//            FrequentItemset freqItemset = new FrequentItemset();
//            arrayList.add(itemset, count);
            line = fo.readByLine();
        }
        fo.closeReadFile();        
        return arrayList;
    }    
}
