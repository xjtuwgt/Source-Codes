/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;
import java.util.Hashtable;

/**
 *
 * @author String
 */
public class InformationProcesss {

    public static void main(String[] args) {
        fileOperator fo = new fileOperator();
        String fileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\tweets_RemoveI.txt";
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        int N = 0;
        int maxLen = 0;
        double average = 0;
        Hashtable<String, Integer> items = new Hashtable();
        String spit = " ";
        int itemIndex = 0;
        int count = 0;
        while (line != null) {
            while (line.trim().equals("")) {
                line = fo.readByLine();
            }
//            if(line.contains("I ")){
//                count++;
//            }
            String[] tokens = line.trim().split(spit);
            if (maxLen < tokens.length) {
                maxLen = tokens.length;
            }

            average = (N * average + tokens.length) / (N + 1);

            for (int i = 0; i < tokens.length; i++) {
                if (!items.containsKey(tokens[i])) {
                    items.put(tokens[i], itemIndex);
                    itemIndex++;
                }
            }
            line = fo.readByLine();
            N++;
        }

        fo.closeReadFile();
        System.out.println(N + "\t" + count + "\t"+ items.size() + "\t" + maxLen + "\t" + average);
    }
}
