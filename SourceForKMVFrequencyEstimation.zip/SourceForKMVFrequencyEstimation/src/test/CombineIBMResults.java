/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;
import java.util.Hashtable;

/**
 *
 * @author String
 */
public class CombineIBMResults {
    public static void main(String[] args){
        fileOperator fo = new fileOperator();
        String trueFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\"
                + "NewResutls-Added\\All Results\\trueCounts.txt";
        String fileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\"
                + "NewResutls-Added\\All Results\\KMV_K =171956_support_0.01_close_0.1_Seed_1.dat";
        
        Hashtable<String, Integer> hashtable = new Hashtable();
        fo.openReadFile(trueFileName);
        String line = fo.readByLine();
        while(line != null){
            String[] tokens = line.split("	");
            int index = Integer.parseInt(tokens[2].trim());
            hashtable.put(tokens[0], index);
//            System.out.println(tokens.length);
            line = fo.readByLine();
        }
        fo.closeReadFile();
        
        fo.openReadFile(fileName);
        line = fo.readByLine();
        while(line != null){
            String[] tokens = line.split(":");
            if(hashtable.containsKey(tokens[0].trim())){
                System.out.println(tokens[0].trim());
            }
            line = fo.readByLine();
        }
        fo.closeReadFile();
    }
}
