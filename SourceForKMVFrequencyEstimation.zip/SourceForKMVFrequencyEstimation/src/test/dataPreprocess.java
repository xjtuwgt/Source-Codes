/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import jdk.nashorn.internal.runtime.regexp.joni.Regex;

/**
 *
 * @author String
 */
public class dataPreprocess {
    
    public static void main(String[] args){
        String fileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\tweets.txt";
        String savefileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\tweets_RemoveII.txt";
//        String line = "tAKjY3bQXH51msJbOHYPmQ	mVHrayjG3uZ_RLHkLj-AMg	";
//        System.out.println(line.length());
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        fo.openWriteFile(savefileName);
        String line = fo.readByLine();
        int n = 0;
        int count = 0;
        while(line!=null){
//            System.out.println(line);
            String[] tokens = line.split(" ");
            if(tokens.length >=1){
//                System.out.println(line);
                String subLine = matchLine(line);
                if(!subLine.trim().equals("")){
//                System.out.println(subLine);
                fo.writeFile(subLine);
                count++;
                }
            }
//            if(line.contains("I ")){
//                count++;
//            }
//            System.out.println(tokens.length);
            line = fo.readByLine();
            n++;
        }
        
        System.out.println(count + "\t" + n);
        fo.closeReadFile();
        fo.closeWriteFile();
    }
    
    public static String matchLine(String line){
//        String pattern = "^[A-Za-z0-9]+$";
//        Pattern r = Pattern.compile(pattern);

        String[] tokens = line.split(" ");
        String matchLine = "";
        HashMap<String, String> temp = new HashMap();
        for(int i = 0; i < tokens.length; i++){
            if (!temp.containsKey(tokens[i])) {
                temp.put(tokens[i], tokens[i] + i);
//            Matcher m = r.matcher(tokens[i]);
//            if(m.find()){
//                if (!(tokens[i].trim().equals("I"))) {
                    matchLine = matchLine + " " + tokens[i].trim();
//                }
//            }
            }
        }
        
//        System.out.println(line+"\n"+matchLine);
        return matchLine.trim();
    }
}
