/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;

/**
 *
 * @author String
 */
public class test {
    public static void main(String[] args){
        String fileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\accidents.txt";
        String testFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\retail_Extend50.txt";
        
        
        
        fileOperator fo = new fileOperator();
        fo.openWriteFile(testFileName);
        fo.openReadFile(fileName);
        String line = fo.readByLine();
//        int[] counts = new int[1000];
        while(line != null){
            for(int i = 1; i < 500; i++){  
                fo.writeFile(line);
            }
              
//            String[] tokens = line.split(" ");
//            for(int i = 0; i < tokens.length; i++){
//                int n = Integer.parseInt(tokens[i].trim());
//            }
            line = fo.readByLine();
        }
//        
//        for(int i = 0; i < counts.length; i++){
//            System.out.println(i+ "\t" +counts[i]);
//        }
        fo.closeWriteFile();
        fo.closeReadFile();
    }                             
}
