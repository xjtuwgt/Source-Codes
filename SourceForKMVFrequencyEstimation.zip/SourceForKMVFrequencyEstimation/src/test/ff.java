/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;
import java.util.Date;
import java.util.Random;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 *
 * @author String
 */
public class ff {
       long time;
    String str;
    public ff(String str, long time) {
        this.time = time;
        this.str = str;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(time).append(str).toHashCode();
    }
    
    

    public static void main(String[] args) throws Exception {
        
        fileOperator fo = new fileOperator();
        String fileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewResutls-Added\\K\\IBM\\171956_9000000_0.01_0.1.txt";
        fo.openReadFile(fileName);
        String line = fo.readByLine();
//        line = fo.readByLine();
        int N = 0;
        double sum = 0;
        while(line!=null){
            double d = Double.parseDouble(line.trim());
            sum = sum + d;
            N++;
            line = fo.readByLine();
        }
        System.out.println(sum/N);
        fo.closeReadFile();
//        for(int i=0; i<1000; i++){
//            long time = new Date().getTime();
//            ff hk = new ff("ghfdhdfdd", time);
//            long hashCode = (long)hk.hashCode();
//            Random rGen = new Random(hashCode);
//            System.out.println(rGen.nextDouble());
////            Thread.sleep(1);
//        }
    }
}
