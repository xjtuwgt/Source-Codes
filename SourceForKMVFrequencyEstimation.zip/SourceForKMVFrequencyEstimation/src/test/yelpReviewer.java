/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author String
 */
public class yelpReviewer {
    public static void main(String[] args){
        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\yelp_reviews.txt";
    }
}
