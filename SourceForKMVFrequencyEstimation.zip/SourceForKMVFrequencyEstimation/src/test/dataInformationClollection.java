/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;
import java.util.Hashtable;
import java.util.Vector;

/**
 *
 * @author String
 */
public class dataInformationClollection {
    
    public static void main(String[] args){
        fileOperator fo = new fileOperator();
//        String fileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\IBM_Quest_data_generator\\data.ascii.ncust_10000.slen_20.tlen_50.nitems_15";
//String fileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\IBM_BigData.data";
String fileName = "C:\\Users\\String\\Document Sources\\SIGMOD\\data sets\\T16I5D1000K.data";
//String fileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Realworld Data\\retail_Extend500.txt";
//        String saveFileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\IBM_HugeData.data";
        fo.openReadFile(fileName);
//        fo.openWriteFile(saveFileName);
        String line = fo.readByLine();
        int N = 0;
        int maxLen = 0;
        double average = 0;
        Hashtable<String, Integer> items = new Hashtable();
        String spit = " ";
        int itemIndex = 0;
        
        while(line != null){
            while(line.trim().equals("")){
                line = fo.readByLine();
            }
//            System.out.println(line);
//            fo.writeFile(line);
            String[] tokens = line.trim().split(spit);
            if(maxLen < tokens.length){
                maxLen = tokens.length;
            }
            
//            Vector<String> lines = splitAnalysis(line);
//            for(int i = 0; i < lines.size(); i++){
//                String subline = lines.elementAt(i).toString().trim();
//                fo.writeFile(subline);
////                System.out.println(subline);
//            }
//            lines.clear();
//            lines = null;
            average = (N*average + tokens.length)/(N+1);
            
            for(int i = 0; i < tokens.length; i++){
                if(!items.containsKey(tokens[i])){
                    items.put(tokens[i], itemIndex);
                    itemIndex++;
                }
            }
            
//            if(N > 20){
//                break;
//            }
//System.out.println(N);
            line = fo.readByLine();
            N++;
        }
        
        fo.closeReadFile();
//        fo.closeWriteFile();
        System.out.println(N + "\t" + items.size() + "\t" + maxLen + "\t" + average);
    }
    
    public static Vector<String> splitAnalysis(String line){
        String[] tokens = line.split(" ");
        int n = Integer.parseInt(tokens[0].trim());
        int k = Integer.parseInt(tokens[1].trim());
        Vector<String> lines = new Vector();
        String subline = "";
        int i = 2;
        int index = 0;
        while(i < tokens.length){
            subline = "";
            for(index = 0; index < k; index++){
                subline = subline + " " + tokens[i];
                i++;
            }
//            System.out.println(k+ "\t" + subline.trim().split(" ").length);
            lines.add(subline.trim());
            if(i == tokens.length){
                break;
            }
            k = Integer.parseInt(tokens[i].trim());
            i++;
        }
        if(lines.size()!=n){
            System.err.println("Error spliting");
        }
        return lines;
    }
}
