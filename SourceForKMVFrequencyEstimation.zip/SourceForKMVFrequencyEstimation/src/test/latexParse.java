/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;

/**
 *
 * @author String
 */
public class latexParse {
    public static void main(String[] args){
        fileOperator fo = new fileOperator();
        String fileName = "C:\\Users\\String\\Desktop\\reults.txt";
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String subline = parseLine(line);
            if(!subline.trim().equals(""))
            System.out.println(subline);
            line = fo.readByLine();
        }
        fo.closeReadFile();
    }
    public static String parseLine(String line){
        String[] tokens = line.split("&");
        String pline = "";
        for(int i = 0; i < tokens.length; i++){
//            System.out.println(tokens[i]);
            if(tokens[i].contains("(")){
                String substr = tokens[i].substring(0, tokens[i].indexOf('(')).trim();
                pline = pline + "\t" + substr;
            }else{
                pline = pline + "\t" + tokens[i].trim();
            }
        }
        return pline;
    }
}
