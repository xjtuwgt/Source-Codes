/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;

/**
 *
 * @author String
 */
public class FrequentItemsExtraction {
    public static void main(String[] args){
        String fileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewResutls-Added\\All Results\\tweets_RemoveII_all_support_0.01.dat";
        fileOperator fo = new fileOperator();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String[] tokens = line.split(":");
            String[] subtokens = tokens[0].trim().split(" ");
            if(subtokens.length == 1){
                System.out.println(subtokens[0]);
            }
            line = fo.readByLine();
        }
        fo.closeReadFile();
    }
}
