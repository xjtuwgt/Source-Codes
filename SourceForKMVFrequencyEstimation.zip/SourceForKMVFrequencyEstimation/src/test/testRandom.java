/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;
import java.util.Random;

/**
 *
 * @author String
 */
public class testRandom {
    public static void main(String[] args){
        Random rand = new Random();
        rand.setSeed(1);
        fileOperator fo = new fileOperator();
        String fileName = "C:\\Users\\String\\Desktop\\test.txt";
        fo.openWriteFile(fileName);
        for(int i = 0; i < 10000000; i++){
            fo.writeFile(rand.nextDouble() + "");
        }
        fo.closeWriteFile();
    }
}
