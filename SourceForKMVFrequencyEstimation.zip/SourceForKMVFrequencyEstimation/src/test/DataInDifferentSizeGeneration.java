/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import fileUtil.fileOperator;

/**
 *
 * @author String
 */
public class DataInDifferentSizeGeneration {
    public static void main(String[] args){
        fileOperator fo = new fileOperator();
//        String fileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\Synthetic Data\\IBM_BigData.data";
        String fileName = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewDataSets\\Orig\\tweets_RemoveII.txt";
        String filePath = "C:\\Users\\String\\Document Sources\\FIM Datasets\\NewDataSets\\Retail\\";
        String origFileName = "Tweet";
//        int N = 366917;
        int[] sizes = {1000000, 3000000, 5000000, 7000000, 9000000};
        for(int i = 0; i < sizes.length; i++){
            fo.openReadFile(fileName);
            int K = sizes[i];
            System.out.println(i);
            fo.openWriteFile(filePath + origFileName + "_" + K + ".data");
            int index = 0;
            String line = fo.readByLine();
            while(index < K){
                fo.writeFile(line);
                line = fo.readByLine();
                index++;
            }
            fo.closeReadFile();
            fo.closeWriteFile();
        }
    }
}
