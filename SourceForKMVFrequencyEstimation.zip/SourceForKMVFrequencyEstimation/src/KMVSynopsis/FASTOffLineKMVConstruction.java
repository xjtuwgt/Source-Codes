/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KMVSynopsis;

import HashFunctions.Node;
import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 * This KMV Construction focuses on offline data
 * @author String
 */
public class FASTOffLineKMVConstruction {
    public fileOperator s_dataSource;//Read
    public String s_dataSourceName;
//    HashFunction s_hash;//Read file
    public Hashtable<String, Integer> s_itemHash;
    public ArrayList<Item> ItemList;//One items
    public Queue<Node> priorityQueue;//Sort by hash values
    public Queue<Node> TIDpriorityQueue;//Sort by transIDs
    
    public long N = 0;//size of the data set
    public int K = 0; //size of the KMV synopsis
    public ArrayList<String> sampleData;
    
    public FASTOffLineKMVConstruction(){
    }
    
    public FASTOffLineKMVConstruction(long n, int k){
        N = n;
        K = k;
    }
    
    public FASTOffLineKMVConstruction(long n, int k, String dataSourceName) {
        N = n;
        K = k;
        s_dataSourceName = dataSourceName;
    }
    
    public void setDataSize(long n){
        N = n;
    }
    
    public void setKMVSize(int k){
        K = k;
    }
    
    public void setDataSource(String sourceFileName){
        s_dataSourceName = sourceFileName;
    }
    //==========================================================================
    
    public void dataSampleWithReplaceMent(){
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        
        priorityQueue = new PriorityQueue<>(K,OrderOnHash);
        int TID = 0;
        while (TID < K) {//Buffering data
            double d = Math.random();
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            TID++;
        }
        
        while(TID < N){//Sampling process
            double d = Math.random();
            if(d < priorityQueue.peek().getHash()){
                Node tempNode = new Node(TID,d,null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            TID++;            
        }
    }
    
    public void GenerateIDList(){
        Comparator<Node> OrderOnID = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                long numbera = o1.getID();
                long numberb = o2.getID();
                if (numberb > numbera) {
                    return -1;
                } else if (numberb < numbera) {
                    return 1;
                } else {
                    return 0;
                }

            }
        };
        
        TIDpriorityQueue = new PriorityQueue<>(K,OrderOnID);
        while(!priorityQueue.isEmpty()){
            Node node = priorityQueue.poll();
            TIDpriorityQueue.add(node);
        }
        priorityQueue.clear();
    }
    
    
    public void InvertSketchConstruction(){//Only one scan
        s_dataSource.openReadFile(s_dataSourceName);
//        s_KMVDataSource.openWriteFile(KMVName);
        sampleData = new ArrayList<String>();
        int hashIndex = 0;
        s_itemHash = new Hashtable<String, Integer>();
        ItemList = new ArrayList();
        
        int index = 0;
        long scanIndex = 0;
        Node node = TIDpriorityQueue.peek();
        long sampleID = node.getID();
        String line = s_dataSource.readByLine();
        while(index < K && line != null){
            if (line.trim().equals("")) {
                line = s_dataSource.readByLine();
                continue;
            }
            while(scanIndex < sampleID){
                if (line.trim().equals("")) {
                    line = s_dataSource.readByLine();
                    continue;
                }
               line = s_dataSource.readByLine();
               scanIndex++; 
            }
            if(scanIndex == sampleID){//sampled transactions
                sampleData.add(line);
                String[] tokens = line.split(",");
                for (int i = 0; i < tokens.length; i++) {
                    if (s_itemHash.containsKey(tokens[i].trim())) {//update
                        int itemIndex = s_itemHash.get(tokens[i]);
                        Item temp = ItemList.get(itemIndex);
                        temp.K = temp.K + 1;
                        double tempKMV = temp.KMV;
                        if(tempKMV < node.getHash()){
                            temp.setKMV(node.getHash());
                        }
                    } else {//New item
                        s_itemHash.put(tokens[i], hashIndex);
                        Item temp = new Item(tokens[i], 1);
                        temp.setKMV(node.getHash());
                        ItemList.add(temp);
                        hashIndex++;
                    }
                }
                
                node = TIDpriorityQueue.peek();
                sampleID = node.getID();
                index++;
            }            
            line = s_dataSource.readByLine();
        }                
        s_dataSource.closeReadFile();
    }
}
