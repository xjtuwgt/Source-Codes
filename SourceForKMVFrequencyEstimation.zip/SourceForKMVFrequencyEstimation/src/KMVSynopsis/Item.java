/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KMVSynopsis;

import java.io.Serializable;
import java.util.PriorityQueue;

/**
 *
 * @author String
 */
public class Item implements Serializable, Comparable<KMVSynopsis.Item> {
    public String name;//The name of the item
    public int K;//The count of the item in the KMV
    public PriorityQueue priorityQueue;//The transactions containing the item in KMV
    public double KMV;//The K minmum value of KMV for this item
    public double frequency;
    
    public Item(String n, int k) {
        name = n;
        K = k;
    }
    
    public Item(String n, int k, double d){
        name = n;
        K = k;
        KMV = d;
        priorityQueue = new PriorityQueue<Double>();
    }
    
    public void setFrequency(){
        frequency = Math.floor(K/KMV);
//        frequency = (K-1)/KMV;
    }
    
    public void UpdateQueue(double d){
        priorityQueue.add(d);
    }

    public void DeleteMax(){
        priorityQueue.poll();
    }    
    
    public void setName(String n){
        name = n;
    }
    
    public void setK(int k){
        K = k;
    }
    
    public void setKMV(double d){
        KMV = d;
    }
    
    public String getName(){
        return name;
    }
    
    public int getK(){
        return K;
    }
    
    public double getKMV(){
        return KMV;
    }

    //==========================================================================
        
    public void increaseFrequency(int f) {
        K += f;
    }
    
    /**
     * Decrease the frequency of this item.
     * 
     * @param f the amount by which to decrease the frequency.
     */
    public void decreaseFrequency(int f) {
      K -= f;
    }
    
    /**
     * Increment the frequency of this item.
     */
    public void increaseFrequency() {
      K++;
    }
    
    /**
     * Decrement the frequency of this item.
     */
    public void decreaseFrequency() {
      K--;
    }
    
    
    
    @Override
    public int compareTo(Item o) {
        if (K == o.getK()) {
            // sort by name
            return -1 * name.compareTo(o.getName());
        }
        if (o.getK() < K) {
            return -1;
        }
        return 1;
    }
    
    public boolean equals(Object compareTo) {
      if (!(compareTo instanceof Item)) {
        return false;
      }
      
      Item b = (Item)compareTo;
      if (name.equals(b.getName()) && K == b.getK()) {
        return true;
      }
      
      return false;
    }    
}
