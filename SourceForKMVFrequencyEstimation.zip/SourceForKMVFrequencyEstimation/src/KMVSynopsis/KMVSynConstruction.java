/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KMVSynopsis;

import HashFunctions.HashFunction;
import HashFunctions.Node;
import fileUtil.fileOperator;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.PriorityQueue;
import java.util.Queue;


/**
 * For online streaming data
 * @author String
 */
public class KMVSynConstruction {
    
    fileOperator s_dataSource;//Read
    fileOperator s_KMVDataSource;//Write
//    HashFunction s_hash;//Read file
    Hashtable<String, Integer> s_itemHash;
    ArrayList<Item> ItemList;//One items
    Queue<Node> priorityQueue;

    int K = 0;
    public KMVSynConstruction(){
    }
    
    public void setKMVSize(int k){
        K = k;
    }
    
    public void LoadData() throws IOException{
        s_dataSource = new fileOperator();
//        s_dataSourece.openReadFile(fileName);
    }
    
    public void setSaveData(){
        s_KMVDataSource = new fileOperator();
//        s_KMVDataSource.openWriteFile(fileName);
    }
    
    public void KMVConstructionOnData(String sourceName,String KMVName, int K){
//      
        Comparator<Node> OrderIsdn = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };//Node records the Trans ID
        priorityQueue = new PriorityQueue<>(K,OrderIsdn);
        
        int hashIndex = 0;
        s_itemHash = new Hashtable<String, Integer>();
        ItemList = new ArrayList();
        
        s_dataSource.openReadFile(sourceName);
        s_KMVDataSource.openWriteFile(KMVName);
        String line = s_dataSource.readByLine();
        long index = 0;
        while(line!=null && index < K){
            if(line.trim().equals("")){
                line = s_dataSource.readByLine();
                continue;
            }
            //====================================
            double d = Math.random();
            Node tempNode = new Node(index, d, line);
            priorityQueue.add(tempNode);
            
            String[] tokens = line.split(",");
            for (int i = 0; i < tokens.length; i++) {
                if (s_itemHash.containsKey(tokens[i].trim())) {//update
                    int itemIndex = s_itemHash.get(tokens[i]);
                    Item temp = ItemList.get(itemIndex);
                    temp.K = temp.K + 1;
                    temp.UpdateQueue(d);
                } else {//New item
                    s_itemHash.put(tokens[i], hashIndex);
                    Item temp = new Item(tokens[i],1,d);
                    temp.UpdateQueue(d);
                    ItemList.add(temp);
                    hashIndex++;
                }
            }
            index++;
            line = s_dataSource.readByLine();
        }
        //======================================================================
        if(index == K){//Buffer is full
           while(line!=null){
               if (line.trim().equals("")) {
                   line = s_dataSource.readByLine();
                   continue;
               }
               
               double d = Math.random();
               if (d < priorityQueue.peek().getHash()) {//Update the KMV synopsis
                   
                   Node tempNode = priorityQueue.poll();//Delete one
                   String tempLine = tempNode.getLine();
                   String tempTokens[] = tempLine.split(",");
                   for(int i = 0; i < tempTokens.length; i++){
                       int itemIndex = s_itemHash.get(tempTokens[i]);
                       Item temp = ItemList.get(itemIndex);
                       temp.K = temp.K - 1;
                       temp.DeleteMax();
                   }                   
                   
                   String[] tokens = line.split(",");
                   for(int i = 0; i < tokens.length; i++){
                       int itemIndex = s_itemHash.get(tokens[i]);
                       Item temp = ItemList.get(itemIndex);
                       temp.K = temp.K + 1;
                       temp.UpdateQueue(d);
                   }
                   Node newNode = new Node(index, d, line);
                   priorityQueue.add(newNode);//Add one
//                System.out.println(priorityQueue.size());
               }
               line = s_dataSource.readByLine();
           }
        }                
        s_dataSource.closeReadFile();
        s_KMVDataSource.closeWriteFile();
    }
    
//    public void KMVConstruction(String sourceName, String KMVName){
//       
//        s_dataSource.openReadFile(sourceName);
////        s_KMVDataSource.openWriteFile(KMVName);
//        long N = 0;
//        long count = 0;
//        FastVector sampleData = new FastVector();
//        double max_hash = Double.NEGATIVE_INFINITY;
//        String line = s_dataSource.readByLine();
//        N++;
//        while(line!= null){
//            line = line.trim();
////            double v = s_hash.getNextHashValue();
//            if(count < K){
//                
//            }else{
//               
//            }
//        }
//                
//        s_dataSource.closeReadFile();
////        s_KMVDataSource.closeWriteFile();
//    }
}
