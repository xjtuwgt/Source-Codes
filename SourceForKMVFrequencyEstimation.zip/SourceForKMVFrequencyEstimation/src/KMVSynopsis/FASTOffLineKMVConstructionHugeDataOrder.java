/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KMVSynopsis;

import HashFunctions.Node;
import closefrequentitemsetmining.StaticParameters;
import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;

/**
 * This KMV Construction focuses on offline data
 * @author String
 */
public class FASTOffLineKMVConstructionHugeDataOrder {
   
    public fileOperator s_orderDataSource;
    public String s_dataOrderSourceName;

    public fileOperator s_dataSource;//Read
    public String s_dataSourceName;
    
    public fileOperator s_KMVDataSource;//Write
    public String s_KMVDataSourceName;
//    HashFunction s_hash;//Read file
    public Hashtable<String, Integer> s_itemHash;
    public ArrayList<Item> ItemList;//One items
    public Queue<Node> priorityQueue;//Sort by hash values
    public Queue<Node> TIDpriorityQueue;//Sort by transIDs
    
    public long N = 0;//size of the data set
    public int K = 0; //size of the KMV synopsis
    public long seed = 0;
    
    public void setSeed(long s){
        seed = s;
    }
    
    
    public FASTOffLineKMVConstructionHugeDataOrder(){
    }
    
    public FASTOffLineKMVConstructionHugeDataOrder(long n, int k){
        N = n;
        K = k;
    }
    
    public FASTOffLineKMVConstructionHugeDataOrder(long n, int k, String dataSourceName) {
        N = n;
        K = k;
        s_dataSourceName = dataSourceName;
    }
    
    public FASTOffLineKMVConstructionHugeDataOrder(long n, int k, String dataSourceName, String KMVSourceName) {
        N = n;
        K = k;
        s_dataSourceName = dataSourceName;
        s_KMVDataSourceName = KMVSourceName;
    }
    
    public FASTOffLineKMVConstructionHugeDataOrder(long n, int k, String dataSourceName, String orderDataName, String KMVSourceName) {
        N = n;
        K = k;
        s_dataSourceName = dataSourceName;
        s_KMVDataSourceName = KMVSourceName;
        s_dataOrderSourceName = orderDataName;
    }
    //==========================================================================
    
    public void dataSampleWithReplacementOrder(){
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        
        Random rand = new Random(seed);
        
        s_orderDataSource = new fileOperator();
        s_orderDataSource.openReadFile(s_dataOrderSourceName);
        
        priorityQueue = new PriorityQueue<>(K,OrderOnHash);
        String line = s_orderDataSource.readByLine();
        int tempIndex = 0;
        while (tempIndex < K && line!=null) {//Buffering data
//            double d = Math.random();
            while(line.trim().equals("")){
                line = s_orderDataSource.readByLine();
            }
            double d = rand.nextDouble();
            int TID = Integer.parseInt(line.trim());
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            line = s_orderDataSource.readByLine();
            tempIndex++;
        }
        
        while(tempIndex < N && line!=null){//Sampling process
//            double d = Math.random();
            while(line.trim().equals("")){
                line = s_orderDataSource.readByLine();
            }
            double d = rand.nextDouble();
            if(d < priorityQueue.peek().getHash()){
                int TID = Integer.parseInt(line.trim());
                Node tempNode = new Node(TID,d,null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            line = s_orderDataSource.readByLine();
            tempIndex++;            
        }
        
        s_orderDataSource.closeReadFile();
    }
    
public void dataSampleWithReplacementOrderAdded(){
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        
          Random rand = new Random(seed);
        Random randi = new Random(seed + 1000);
        
        s_orderDataSource = new fileOperator();
        s_orderDataSource.openReadFile(s_dataOrderSourceName);
        
        priorityQueue = new PriorityQueue<>(K,OrderOnHash);
        String line = s_orderDataSource.readByLine();
        int tempIndex = 0;
        while (tempIndex < K && line!=null) {//Buffering data
//            double d = Math.random();
            while(line.trim().equals("")){
                line = s_orderDataSource.readByLine();
            }
//            double d = rand.nextDouble();
double d0 = rand.nextDouble();
long seed = randi.nextLong();
rand = new Random();
rand.setSeed(seed);
double d = rand.nextDouble();
            int TID = Integer.parseInt(line.trim());
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            line = s_orderDataSource.readByLine();
            tempIndex++;
        }
        
        while(tempIndex < N && line!=null){//Sampling process
//            double d = Math.random();
            while(line.trim().equals("")){
                line = s_orderDataSource.readByLine();
            }
//            double d = rand.nextDouble();
double d0 = rand.nextDouble();
long seed = randi.nextLong();
rand = new Random();
rand.setSeed(seed);
double d = rand.nextDouble();
            if(d < priorityQueue.peek().getHash()){
                int TID = Integer.parseInt(line.trim());
                Node tempNode = new Node(TID,d,null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            line = s_orderDataSource.readByLine();
            tempIndex++;            
        }
        
        s_orderDataSource.closeReadFile();
    }   

public void dataSampleWithReplacementOrderAdded1(){
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        
        Random rand = new Random(seed);
        long t = rand.nextLong();
        
        Random randi = new Random();
        randi.setSeed(t);
        
        s_orderDataSource = new fileOperator();
        s_orderDataSource.openReadFile(s_dataOrderSourceName);
        
        priorityQueue = new PriorityQueue<>(K,OrderOnHash);
        String line = s_orderDataSource.readByLine();
        int tempIndex = 0;
        while (tempIndex < K && line!=null) {//Buffering data
//            double d = Math.random();
            while(line.trim().equals("")){
                line = s_orderDataSource.readByLine();
            }
//            double d = rand.nextDouble();
long s = randi.nextLong();
rand = new Random();
rand.setSeed(s*rand.nextLong());
//double d2 = randk.nextDouble();
double d = rand.nextDouble();

//double d0 = rand.nextDouble();
//long seed = randi.nextLong();
//rand = new Random();
//rand.setSeed(seed);
//double d = rand.nextDouble();
            int TID = Integer.parseInt(line.trim());
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            line = s_orderDataSource.readByLine();
            tempIndex++;
        }
        
        while(tempIndex < N && line!=null){//Sampling process
//            double d = Math.random();
            while(line.trim().equals("")){
                line = s_orderDataSource.readByLine();
            }
            long s = randi.nextLong();
rand = new Random();
rand.setSeed(s*rand.nextLong());
//double d2 = randk.nextDouble();
double d = rand.nextDouble();
//            double d = rand.nextDouble();
//double d0 = rand.nextDouble();
//long seed = randi.nextLong();
//rand = new Random();
//rand.setSeed(seed);
//double d = rand.nextDouble();
            if(d < priorityQueue.peek().getHash()){
                int TID = Integer.parseInt(line.trim());
                Node tempNode = new Node(TID,d,null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            line = s_orderDataSource.readByLine();
            tempIndex++;            
        }
        
        s_orderDataSource.closeReadFile();
    } 
    
    public void dataSampleWithReplacement(){
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        
        Random rand = new Random(seed);
        
        priorityQueue = new PriorityQueue<>(K,OrderOnHash);
        int TID = 0;
        while (TID < K) {//Buffering data
//            double d = Math.random();
double d = rand.nextDouble();
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            TID++;
        }
        
        while(TID < N){//Sampling process
//            double d = Math.random();
double d = rand.nextDouble();
            if(d < priorityQueue.peek().getHash()){
                Node tempNode = new Node(TID,d,null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            TID++;            
        }
    }
    
    public void dataSampleWithReplacementAnother(){
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        
        Random random = new Random();
        random.setSeed(555L);
        
        
        priorityQueue = new PriorityQueue<>(K,OrderOnHash);
        int TID = 0;
        while (TID < K) {//Buffering data
            double d = random.nextDouble();
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            TID++;
        }
        
        while(TID < N){//Sampling process
            double d = random.nextDouble();
            if(d < priorityQueue.peek().getHash()){
                Node tempNode = new Node(TID,d,null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            TID++;            
        }
    }    
    
    public void GenerateIDList(){
        Comparator<Node> OrderOnID = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                long numbera = o1.getID();
                long numberb = o2.getID();
                if (numberb > numbera) {
                    return -1;
                } else if (numberb < numbera) {
                    return 1;
                } else {
                    return 0;
                }

            }
        };
        
        TIDpriorityQueue = new PriorityQueue<>(K,OrderOnID);
        while(!priorityQueue.isEmpty()){
            Node node = priorityQueue.poll();
            TIDpriorityQueue.add(node);
        }
        priorityQueue.clear();
        System.out.println(priorityQueue.size() + "\t" + TIDpriorityQueue.toArray().length);
        
       
//        for(int i = 0; i< temp.length; i++){
//            System.out.println(temp[i].getID());
//        }
//        System.out.println("fdjjkjjjjjjjjjjjjjjjjjj");
        
        priorityQueue = null;
    }
    
    
    public void InvertSketchConstruction(){//Only one scan
        s_dataSource = new fileOperator();
        s_KMVDataSource = new fileOperator();
        s_dataSource.openReadFile(s_dataSourceName);
        s_KMVDataSource.openWriteFile(s_KMVDataSourceName);
        int hashIndex = 0;
        s_itemHash = new Hashtable<String, Integer>();
        ItemList = new ArrayList();
//        System.out.println(TIDpriorityQueue.size()+"======================I'am Here");
        int index = 0;
        long scanIndex = 0;
        Node node = TIDpriorityQueue.poll();
        long sampleID = node.getID();
        String line = s_dataSource.readByLine();
//        System.out.println(sampleID);
//        System.out.println(sampleID);
        while(index < K && line != null){
            if (line.trim().equals("")) {
                line = s_dataSource.readByLine();
                continue;
            }
            while(scanIndex < sampleID && line != null){
                if (line.trim().equals("")) {
                    line = s_dataSource.readByLine();
                    continue;
                }
//                System.out.println(scanIndex + "\t" + sampleID);
               line = s_dataSource.readByLine();
               scanIndex++; 
            }
            if(scanIndex == sampleID && line != null){//sampled transactions
                s_KMVDataSource.writeFile(line);
                String[] tokens = line.split(StaticParameters.splitKey);
                for (int i = 0; i < tokens.length; i++) {
                    if (s_itemHash.containsKey(tokens[i].trim())) {//update
                        int itemIndex = s_itemHash.get(tokens[i]);
                        Item temp = ItemList.get(itemIndex);
                        temp.K = temp.K + 1;
                        double tempKMV = temp.KMV;
                        if(tempKMV < node.getHash()){
                            temp.setKMV(node.getHash());
                        }
                    } else {//New item
                        s_itemHash.put(tokens[i], hashIndex);
                        Item temp = new Item(tokens[i], 1);
                        temp.setKMV(node.getHash());
                        ItemList.add(temp);
                        hashIndex++;
                    }
                }
//                System.out.println(index + "\t" + sampleID + "\t" + scanIndex);
                if (TIDpriorityQueue.isEmpty()) {
                    TIDpriorityQueue.clear();;
                    TIDpriorityQueue = null;
                    s_dataSource.closeReadFile();
                    s_KMVDataSource.closeWriteFile();
                    return;
                }
                node = TIDpriorityQueue.poll();
                sampleID = node.getID();
                index++;                
            }

            line = s_dataSource.readByLine();
            scanIndex++;
        }
        TIDpriorityQueue.clear();;
        TIDpriorityQueue = null;
        s_dataSource.closeReadFile();
        s_KMVDataSource.closeWriteFile();
    }
    
    public static void main(String[] args){
//        String sourceFileName = "C:\\Users\\String\\Desktop\\testData\\test.txt";
//String KMVFileName = "C:\\Users\\String\\Desktop\\testData\\test_KMV.txt";
        String sourceFileName = "C:\\Users\\String\\Document Sources\\data\\T40I10D100KBig.dat";
        String KMVFileName = "C:\\Users\\String\\Document Sources\\data\\T40I10D100K_KMV.dat";
        
        
        long N = 100000000;
        int K = 100000;
        FASTOffLineKMVConstructionHugeDataOrder KMV = new FASTOffLineKMVConstructionHugeDataOrder(N, K, sourceFileName, KMVFileName);
        double startTime = System.currentTimeMillis();
        KMV.dataSampleWithReplacement();
        KMV.GenerateIDList();
        KMV.InvertSketchConstruction();
        double endTime = System.currentTimeMillis();
        double slapTime = (endTime - startTime)/1000;
        System.out.println(slapTime);
        
//        Collections.sort(KMV.ItemList);
//        for(int i = 0; i < KMV.ItemList.size(); i++){
//            System.out.println(KMV.ItemList.get(i).name + "\t" + KMV.ItemList.get(i).K/KMV.ItemList.get(i).KMV);
//        }
    }
}
