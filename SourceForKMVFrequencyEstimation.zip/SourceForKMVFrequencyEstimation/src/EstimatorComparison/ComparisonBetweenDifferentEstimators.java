/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EstimatorComparison;

import BaseLineMethods.Apriori.AprioriItem;
import BaseLineMethods.Apriori.AprioriItemSet;
import static BaseLineMethods.BasicAprioriMethod.seed;
import HashFunctions.Node;
import KMVSynopsis.FASTOffLineKMVConstructionHugeData;
import closefrequentitemsetmining.StaticParameters;
import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.Vector;

/**
 *
 * @author String
 */
public class ComparisonBetweenDifferentEstimators {
    protected double s_minSupport = 0.01;
    protected double s_closePara = 0.01;
    
    protected int s_maxItems = -1;
    protected long N = 0;
    public int K = 200;
    
    public int tempK = 0;
    public Queue<Node> priorityQueue;//Sort by hash values
    public Queue<Node> TIDpriorityQueue;//Sort by transIDs

    public fileOperator s_dataSource;//Read
    public fileOperator s_KMVDataSource;//Write
    public String s_dataSourceName;//Source data
    public String s_KMVDataSourceName;//Sampling data
    FASTOffLineKMVConstructionHugeData s_KMVConstruction;
    //========================================================================== 

//    public fileOperator s_dataSource;//Read
//    public String s_dataSourceName;
    ArrayList<AprioriItem> singletons;
    Hashtable<String, Integer> itemHashtable;
    
    public void setSupportThrehold(double supp){
        s_minSupport = supp;
    }
    
    public void setCloseParameter(double closePara){
        s_closePara = closePara;
    }

//    ArrayList<Edge> SketchGraph;
    protected Vector<AprioriItemSet> m_largeItemSets;

    public ComparisonBetweenDifferentEstimators() {
    }

    public ComparisonBetweenDifferentEstimators(long n, int k, String sourceName, String KMVName) {
        N = n;
        K = k;
        s_dataSourceName = sourceName;
        s_KMVDataSourceName = KMVName;
    }

    public void dataSampleWithReplacement() {
        Comparator<Node> OrderOnHash = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                double numbera = o1.getHash();
                double numberb = o2.getHash();
                if (numberb > numbera) {
                    return 1;
                } else if (numberb < numbera) {
                    return -1;
                } else {
                    return 0;
                }

            }
        };
        Random rand = new Random();
        rand.setSeed(seed);
        priorityQueue = new PriorityQueue<>(K, OrderOnHash);
        int TID = 0;
        while (TID < K) {//Buffering data
//            double d = Math.random();
double d = rand.nextDouble();
            Node tempNode = new Node(TID, d, null);
            priorityQueue.add(tempNode);
            TID++;
        }

        while (TID < N) {//Sampling process
//            double d = Math.random();
double d = rand.nextDouble();
            if (d < priorityQueue.peek().getHash()) {
                Node tempNode = new Node(TID, d, null);
                priorityQueue.poll();
                priorityQueue.add(tempNode);
            }
            TID++;
        }
    }

    public void GenerateIDList() {
        Comparator<Node> OrderOnID = new Comparator<Node>() {
            public int compare(Node o1, Node o2) {
                // TODO Auto-generated method stub  
                long numbera = o1.getID();
                long numberb = o2.getID();
                if (numberb > numbera) {
                    return -1;
                } else if (numberb < numbera) {
                    return 1;
                } else {
                    return 0;
                }

            }
        };

        TIDpriorityQueue = new PriorityQueue<>(K, OrderOnID);
        while (!priorityQueue.isEmpty()) {
            Node node = priorityQueue.poll();
            TIDpriorityQueue.add(node);
        }
        priorityQueue.clear();
        System.out.println(priorityQueue.size() + "\t Here" + TIDpriorityQueue.toArray().length);
        priorityQueue = null;
    }

    public void InvertSketchAndGraphContruction() {
        s_dataSource = new fileOperator();
        s_KMVDataSource = new fileOperator();
        s_dataSource.openReadFile(s_dataSourceName);
        s_KMVDataSource.openWriteFile(s_KMVDataSourceName);
        int hashIndex = 0;//Hash value
        itemHashtable = new Hashtable<String, Integer>();

        singletons = new ArrayList();
//        System.out.println(TIDpriorityQueue.size()+"======================I'am Here");
        int index = 0;
        long scanIndex = 0;//can the original data set
        Node node = TIDpriorityQueue.poll();
        long sampleID = node.getID();
        String line = s_dataSource.readByLine();
        while (index < K && line != null) {
//            System.out.println(index);
            if (line.trim().equals("")) {
                line = s_dataSource.readByLine();
                continue;
            }
            while (scanIndex < sampleID && line != null) {
                if (line.trim().equals("")) {
                    line = s_dataSource.readByLine();
                    continue;
                }
//                System.out.println(scanIndex + "\t" + sampleID);
                line = s_dataSource.readByLine();
                scanIndex++;
            }
            if (scanIndex == sampleID) {//sampled transactions
                s_KMVDataSource.writeFile(line);
                String[] tokens = line.split(StaticParameters.splitKey);
                for (int i = 0; i < tokens.length; i++) {
                    if (itemHashtable.containsKey(tokens[i].trim())) {//update
                        int itemIndex = itemHashtable.get(tokens[i]);
                        AprioriItem temp = singletons.get(itemIndex);
                        temp.increaseCount();
                        temp.addKMV(node.getHash());
                    } else {//New item
                        itemHashtable.put(tokens[i], hashIndex);
                        AprioriItem temp = new AprioriItem(tokens[i]);
//                        temp.increaseCount();
                        temp.addKMV(node.getHash());
                        singletons.add(temp);
                        hashIndex++;
                    }
                    for (int j = i + 1; j < tokens.length; j++) {
                        if (!itemHashtable.containsKey(tokens[j].trim())) {//update
                            itemHashtable.put(tokens[j], hashIndex);
                            AprioriItem temp = new AprioriItem(tokens[j]);
//                            temp.increaseCount();
                            temp.addKMV(node.getHash());
                            singletons.add(temp);
                            hashIndex++;
                        }
                    }
                }
//                System.out.println(index + "\t" + sampleID + "\t" + scanIndex);
                if (TIDpriorityQueue.isEmpty()) {
                    System.out.println(scanIndex + "I am here!!\t" + index);
//                    System.out.println(scanIndex + "\t" + index + "\t" + TIDpriorityQueue.size() + "\t One items " + singletons.size() + "\t" + hashIndex +  "\t Two items" + SketchGraph.size());
                    TIDpriorityQueue.clear();;
                    TIDpriorityQueue = null;
                    s_dataSource.closeReadFile();
                    s_KMVDataSource.closeWriteFile();
//                    for (int i = 0; i < singletons.size(); i++) {
//                        AprioriItem tempItem = singletons.get(i);
//                        Collections.sort(tempItem.s_KMVs);
//                        tempItem.KMV = tempItem.s_KMVs.get(tempItem.K - 2);
//                        tempItem.frequency = tempItem.K / tempItem.KMV;
//                        System.out.println(tempItem.itemName + "\t count " + tempItem.K + "\t" + tempItem.frequency);
//                    }
                    return;
                }
                node = TIDpriorityQueue.poll();
                sampleID = node.getID();
                index++;
            }

            line = s_dataSource.readByLine();
            scanIndex++;
        }
        TIDpriorityQueue.clear();;
        TIDpriorityQueue = null;
        s_dataSource.closeReadFile();
        s_KMVDataSource.closeWriteFile();
    }

    public Vector<AprioriItemSet> getFrequnetOneItemSet() {
        Vector<AprioriItemSet> oneItemSet = new Vector();
        AprioriItemSet tempItemSet;
        for (int i = 0; i < singletons.size(); i++) {
            AprioriItem tempItem = singletons.get(i);
            Collections.sort(tempItem.s_KMVs);
            String name = tempItem.getName();
            int hashIndex = itemHashtable.get(name);
            int items[] = new int[1];
            items[0] = hashIndex;
            tempItemSet = new AprioriItemSet((int) N, items);
            tempItemSet.m_KMV = tempItem.s_KMVs.get(tempItem.K - 1);
            tempItemSet.s_K = tempItem.K;
            tempItemSet.s_frequency = tempItemSet.s_K / tempItemSet.m_KMV;
            if ((tempItemSet.s_frequency > N * s_minSupport*(1-this.s_closePara/2))&&(tempItem.K > tempK)) {
                oneItemSet.add(tempItemSet);
                this.m_largeItemSets.add(tempItemSet);
            }
        }
        return oneItemSet;
    }    
    
}
