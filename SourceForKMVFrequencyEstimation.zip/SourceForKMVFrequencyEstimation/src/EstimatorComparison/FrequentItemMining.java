/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EstimatorComparison;

import fileUtil.fileOperator;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 *
 * @author String
 */
public class FrequentItemMining {
    
    public class Item{
        String name;
        int count;
        public Item(){
            
        }
        public void setName(String n){
            name = n;
        }
        
        public void setCount(int c){
            count = c;
        }
        
        public void upDateCount(){
            count++;
        }
    }
    
    public static void main(String[] args){
        
    }
    
    public static ArrayList<Item> mineItems(String fileName){
        fileOperator fo = new fileOperator();
        ArrayList<Item> nodeList = new ArrayList();
        Hashtable<String, Integer> hashtable = new Hashtable();
        fo.openReadFile(fileName);
        String line = fo.readByLine();
        while(line!=null){
            String[] tokens = line.split("");
        }
        fo.closeReadFile();
        return nodeList;
    }
}
