/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FIMAlgorithmOrder;

import closefrequentitemsetmining.*;
import KMVSynopsis.FASTOffLineKMVConstructionHugeData;
import KMVSynopsis.FASTOffLineKMVConstructionHugeDataOrder;
import KMVSynopsis.Item;
import fileUtil.fileOperator;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author String
 */
public class FPGrowthMiningOnHugeDataOrderNew {

    protected double s_minSupport = 0.1;
    protected double s_closeParameter = 0.01;
    protected int s_maxItems = -1;

    public fileOperator s_dataSource;//Read
    public String s_dataSourceName;
    
    public fileOperator s_orderDataSource;
    public String s_dataOrderSourceName;

    public fileOperator s_KMVDataSource;//Write

    public long N = 1000;
    public int K = 200;
    public int tempK = 0;

    public String s_KMVDataSourceName;
    FASTOffLineKMVConstructionHugeDataOrder s_KMVConstructionOrder;

    public void setDataSize(long n) {
        N = n;
    }

    public void setKMVSize(int k) {
        K = k;
    }

    public void setKMVDataSourceName(String fileName) {
        s_KMVDataSourceName = fileName;
    }

    public void setOrderDataSourceName(String fileName){
        s_dataOrderSourceName = fileName;
    }
    
    public void setDataSourceName(String fileName) {
        s_dataSourceName = fileName;
    }
    
    public void setThreshold(double supp){
        this.s_minSupport = supp;
    }
    
    public void setCloseParameter(double closePara){
        this.s_closeParameter = closePara;
    }
    /**
     * Holds the large item sets found
     */
    protected FrequentItemSets m_largeItemSets;

    //===========================================
    public void KMVDataSampling() {
//        s_KMVConstruction = new FASTOffLineKMVConstructionHugeData(N, K, s_dataSourceName, s_KMVDataSourceName);
//        s_KMVConstructionOrder = new FASTOffLineKMVConstructionHugeDataOrder(N, K, s_dataSourceName, s_dataOrderSourceName, s_KMVDataSourceName);
//        s_KMVConstruction.setSeed(seed);
////        double startTime = System.currentTimeMillis();
//        s_KMVConstruction.dataSampleWithReplacement();
////        s_KMVConstruction.dataSampleWithReplacementNewAdded1();
////s_KMVConstruction.dataSampleWithReplacementSecRand();
////s_KMVConstruction.dataSampleWithReplacementRandX();
////        s_KMVConstruction.dataSampleWithReplacementAnother();
//        s_KMVConstruction.GenerateIDList();
//        s_KMVConstruction.InvertSketchConstruction();
        s_KMVConstructionOrder = new FASTOffLineKMVConstructionHugeDataOrder(N, K, s_dataSourceName, s_dataOrderSourceName, s_KMVDataSourceName);
        s_KMVConstructionOrder.setSeed(seed);
//        double startTime = System.currentTimeMillis();
//        s_KMVConstructionOrder.dataSampleWithReplacementOrder();
        s_KMVConstructionOrder.dataSampleWithReplacementOrderAdded1();
//        s_KMVConstruction.dataSampleWithReplacementAnother();
        s_KMVConstructionOrder.GenerateIDList();
        s_KMVConstructionOrder.InvertSketchConstruction();
        
        System.out.println("Database scanning is completed");
//        double endTime = System.currentTimeMillis();
//        double slapTime = (endTime - startTime) / 1000;
//        System.out.println(slapTime);
    }

//The interface to the KMV synopsis
    protected ArrayList<Item> getSingletons() throws Exception {
        ArrayList<Item> singletons = s_KMVConstructionOrder.ItemList;
//        int count = 0;
        for (int i = 0; i < singletons.size(); i++) {
            Item item = singletons.get(i);
            if(item.K >= tempK)
                item.setFrequency();
//            System.out.println(item.K + "\t" + item.getName() + "\t" + item.getKMV());
//            if(item.frequency > s_minSupport * (1 - this.s_closeParameter) * N){
//                count++;
//            }
        }
//        System.out.println("Number of frequent items = " + count + "Support = " + (s_minSupport * (1 - this.s_closeParameter) * N));
        return singletons;
    }

    protected Hashtable<String, Integer> getItemHashtable() {
        Hashtable<String, Integer> itemHashtable = s_KMVConstructionOrder.s_itemHash;
        return itemHashtable;
    }

//    protected ArrayList<Item> getOrderedSingletons() throws Exception {
//        ArrayList<Item> singletons = s_KMVConstruction.ItemList;
//        Collections.sort(singletons);
//        for (int i = 0; i < singletons.size(); i++) {
//            Item item = singletons.get(i);
//            item.setFrequency();
//        }
//        return singletons;
//    }

//    protected Hashtable<String, Integer> getSortedItemHashtable(ArrayList<Item> singletons) {
//        Hashtable<String, Integer> itemHashtable = new Hashtable<String, Integer>();
//        for (int i = 0; i < singletons.size(); i++) {
//            Item item = singletons.get(i);
//            itemHashtable.put(item.getName(), i);
//        }
//        return itemHashtable;
//    }

    /**
     * Construct the frequent pattern tree by inserting each transaction in the
     * data into the tree. Only those items from each transaction that meet the
     * minimum support threshold are inserted.
     *
     * @param singletons the singleton item sets
     * @param dataFileName the data containing the transactions
     * @param minSupport the minimum support
     * @return the root of the tree
     */
    protected FPTreeRoot buildFPTree(ArrayList<Item> singletons, Hashtable<String, Integer> itemHashtable, String dataFileName) {
        fileOperator fo = new fileOperator();
        fo.openReadFile(dataFileName);

        FPTreeRoot tree = new FPTreeRoot();
        double supportThreshold = Math.floor(s_minSupport * (1 - this.s_closeParameter/2) * N);
//double supportThreshold = s_minSupport * N;
//double supportThreshold = s_minSupport * (1 - this.s_closeParameter/2) * N;

        System.out.println("Support threshold = " + supportThreshold);

        String line = fo.readByLine();
        int index = 0;
        while (line != null) {
            String[] tokens = line.split(StaticParameters.splitKey);
            ArrayList<Item> transaction = new ArrayList<Item>();
            for (int i = 0; i < tokens.length; i++) {
                int itemIndex = itemHashtable.get(tokens[i]);
                Item itemi = singletons.get(itemIndex);//如果不用排序了是否会更快
                if (itemi.frequency >= supportThreshold) {
                    transaction.add(itemi);
                }

//                if (itemi.K >= tempK) {
//                    transaction.add(itemi);
//                }
            }
            Collections.sort(transaction);
            tree.addItemSet(transaction, 1);
            transaction.clear();
            transaction = null;
            line = fo.readByLine();
            index++;
        }
        fo.openReadFile(dataFileName);
        return tree;
    }

    /**
     * Find large item sets in the FP-tree.
     *
     * @param tree the root of the tree to mine
     * @param largeItemSets holds the large item sets found
     * @param recursionLevel the recursion level for the current projected
     * counts
     * @param conditionalItems the current set of items that the current
     * (projected) tree is conditional on
     * @param minSupport the minimum acceptable support
     */
    protected void mineKMVTree(FPTreeRoot tree, FrequentItemSets largeItemSets,
            int recursionLevel, FrequentItemset conditionalItems) {

//        double minSupport = s_minSupport * (1 - this.s_closeParameter/2) * N;
        double minSupport = Math.floor(s_minSupport * (1 - this.s_closeParameter/2) * N);
//double minSupport = s_minSupport * N;

        if (!tree.isEmpty(recursionLevel)) {
//            if (s_maxItems > 0 && recursionLevel >= s_maxItems) {
//                // don't mine any further
//                return;
//            }
            Map<Item, HeaderTable> headerTable = tree.getHeaderTable();//获得头表
            Set<Item> keys = headerTable.keySet();
//      System.err.println("Number of freq item sets collected " + largeItemSets.size());
            Iterator<Item> i = keys.iterator();
            while (i.hasNext()) {
                Item item = i.next();
                HeaderTable itemHeader = headerTable.get(item);
                // check for minimum support at this level
//                int support = itemHeader.getProjectedCounts().getCount(recursionLevel);//递归的层次应该和KMV的value值相对应
                int K = itemHeader.getProjectedCounts().getCount(recursionLevel);
                if (K < tempK) {
                    continue;
                }
                
                //Added by Wang
                double KMV = itemHeader.getProjectedKMVs().getKMV(recursionLevel);//获取对应的KMV
//                double support = (K-1) / KMV;//Estimated support
                double support = K / KMV;//Estimated support
//                if(support < minSupport){
//                    continue;
//                }

                if (support >= minSupport) {
                    // process header list at this recursion level
                    for (FPTreeNode n : itemHeader.getHeaderList()) {
                        // push count up path to root
                        int currentCount = n.getProjectedCount(recursionLevel);
                        double currentKMV = n.getProjectedKMV(recursionLevel);
                        if (currentCount > 0) {
                            FPTreeNode temp = n.getParent();
                            while (temp != tree) {
                                // set/increase for the node
                                temp.increaseProjectedCount(recursionLevel + 1, currentCount);
                                //Added by Wang
                                temp.updateProjectedKMV(recursionLevel + 1, currentKMV);

                                // set/increase for the header table
                                headerTable.get(temp.getItem()).
                                        getProjectedCounts().increaseCount(recursionLevel + 1, currentCount);

                                //Added by Wang
                                headerTable.get(temp.getItem()).getProjectedKMVs().updateKMV(recursionLevel + 1, currentKMV);

                                temp = temp.getParent();
                            }
                        }
                    }

                    FrequentItemset newConditional = (FrequentItemset) conditionalItems.clone();

                    // this item gets added to the conditional items
                    newConditional.addItem(item);
                    newConditional.setSupport((int) support);

                    // now add this conditional item set to the list of large item sets
                    largeItemSets.addItemSet(newConditional);

                    // now recursively process the new tree
                    mineKMVTree(tree, largeItemSets, recursionLevel + 1, newConditional);

                    // reverse the propagated counts
                    for (FPTreeNode n : itemHeader.getHeaderList()) {
                        FPTreeNode temp = n.getParent();
                        while (temp != tree) {
                            temp.removeProjectedCount(recursionLevel + 1);
                            temp = temp.getParent();
                        }
                    }

                    // reverse the propagated KMVs
                    for (FPTreeNode n : itemHeader.getHeaderList()) {
                        FPTreeNode temp = n.getParent();
                        while (temp != tree) {
                            temp.removeProjectedKMV(recursionLevel + 1);
//                            temp.removeProjectedCount(recursionLevel + 1);
                            temp = temp.getParent();
                        }
                    }

                    // reverse the propagated counts in the header list
                    // at this recursion level
                    for (HeaderTable h : headerTable.values()) {
                        h.getProjectedCounts().removeCount(recursionLevel + 1);
                    }

                    // reverse the propagated KMVs in the header list
                    // at this recursion level
                    for (HeaderTable h : headerTable.values()) {
                        h.getProjectedKMVs().removeKMV(recursionLevel + 1);
                    }
                }
            }
        }
    }

    public void FPGrowthMiningProcess() throws Exception {
        if(K > 0){
            tempK = (int) (K*this.s_minSupport)-1;
//            tempK = (int) (K*this.s_minSupport);
        }
        KMVDataSampling();
        ArrayList<Item> singletons = getSingletons();
        Hashtable<String, Integer> itemHashtable = getItemHashtable();
        FPTreeRoot tree = buildFPTree(singletons, itemHashtable, s_KMVDataSourceName);
// FPTreeRoot tree = this.FastBuildFPTree(singletons, itemHashtable, s_KMVDataSourceName);
        FrequentItemSets largeItemSets = new FrequentItemSets((int) N);
        // mine the tree
        FrequentItemset conditionalItems = new FrequentItemset(new ArrayList<Item>(), 0);
        System.out.println("Tree construction is completed...");
        mineKMVTree(tree, largeItemSets, 0, conditionalItems);
//        mineTree(tree, largeItemSets, 0, conditionalItems);
        tree = null;
        m_largeItemSets = largeItemSets;
        System.out.println("Support threshold: " + this.s_minSupport*(1- this.s_closeParameter/2)*N);
        System.out.println("Number of frequent itemsets mined: " + m_largeItemSets.size());
        System.out.println("=============================================");
//        for(int i = 0; i < m_largeItemSets.size(); i++){
//            System.out.println(m_largeItemSets.getItemSet(i).toString());
//        }
       
    }

    public void saveAllFrequentItems(String fileName) throws IOException {
        fileOperator fo = new fileOperator();
                File file = new File(fileName);
        if(!file.exists()){
            file.createNewFile();
        }
        fo.openWriteFile(fileName);
        for (int i = 0; i < m_largeItemSets.size(); i++) {
            fo.writeFile(m_largeItemSets.getItemSet(i).toString());
        }
        fo.closeWriteFile();
    }
    

    public static String[] orderParas = {"OO","RO","RandO","SRO","FreqFirst","FreqMid","FreqLast"};
    
    public static void main(String[] args) throws Exception {
        String fileName = "tweets_RemoveII";
        long N = 13445364;
        
        for(int oindex = 0; oindex < orderParas.length; oindex++){
        
        String orderFilePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\Order\\TweetOrder\\";
        String filePath = "C:\\Users\\String\\Document Sources\\SIGMOD\\data sets\\";
        String oFileName = orderParas[oindex];
        String orderFileName = orderFilePath + oFileName + ".txt";
        String sourceFileName = filePath + fileName + ".data";
        String KMVFileName = filePath + "KMVSampleData\\sample_" + fileName + N + ".data";

        double closeParameter = 0.1;
        double threshold = 0.005;
        double eta = 8;
        int K = 125023;

        int Pass = 5;
        double[] runtimes = new double[Pass];
        for (int i = 0; i < Pass; i++) {
            seed = i + 1;
            System.out.println("Run pass ==============" + (i + 1));
            double startTime = System.currentTimeMillis();
            FPGrowthMiningOnHugeDataOrderNew fpGrowth = new FPGrowthMiningOnHugeDataOrderNew();
            fpGrowth.setDataSourceName(sourceFileName);
            fpGrowth.setOrderDataSourceName(orderFileName);
            fpGrowth.setKMVDataSourceName(KMVFileName);
            fpGrowth.setDataSize(N);
            fpGrowth.setKMVSize(K);
            fpGrowth.setThreshold(threshold);
            fpGrowth.setCloseParameter(closeParameter);
            fpGrowth.FPGrowthMiningProcess();

            double endTime = System.currentTimeMillis();
            double slapTime = (endTime - startTime) / 1000;
            System.out.println("Runtime = " + slapTime);
            runtimes[i] = slapTime;
            String resultFile = "C:\\Users\\String\\Document Sources\\SIGMOD\\Order\\FPGrowth\\" + fileName + "_Order_" + oFileName +"_"+ N + "_K_" + K + "_support_" + threshold + "_close_" + closeParameter + "_eta_" + eta + "_seed_" + seed + ".dat";
            fpGrowth.saveAllFrequentItems(resultFile);

        }
        for (int i = 0; i < Pass; i++) {
            System.out.println(runtimes[i]);
        }
        saveRuntime("C:\\Users\\String\\Document Sources\\SIGMOD\\Order\\FPGrowth\\" + K + "_Order_" + oFileName + "_" + N + "_support_" + threshold + "_close_" + closeParameter + "_eta_" + eta + ".txt", runtimes);

        }
    }
    
        public static double[][] tweetParas = {{0.005,0.05,8,499571},
{0.005,0.06,8,346995},
{0.005,0.07,8,254988},
{0.005,0.08,8,195266},
{0.005,0.09,8,154317},
{0.005,0.1,8,125023},
{0.005,0.1,8,125023},
{0.005,0.1,16,126687},
{0.005,0.1,24,127660},
{0.005,0.1,32,128350},
{0.005,0.1,40,128886},
{0.001,0.1,8,128886},
{0.002,0.1,8,127222},
{0.003,0.1,8,126249},
{0.004,0.1,8,125559},
{0.005,0.1,8,125023},
{0.006,0.1,8,124586},
{0.007,0.1,8,124216},
{0.008,0.1,8,123895},
{0.009,0.1,8,123612},
{0.01,0.1,8,123360}};
    
     public static double[][] T15I6Paras ={{0.005,0.05,8,528371},
{0.005,0.06,8,366995},
{0.005,0.07,8,269681},
{0.005,0.08,8,206516},
{0.005,0.09,8,163205},
{0.005,0.1,8,132223},
{0.005,0.1,8,132223},
{0.005,0.1,16,133887},
{0.005,0.1,24,134860},
{0.005,0.1,32,135550},
{0.005,0.1,40,136086},
{0.001,0.1,8,136086},
{0.002,0.1,8,134422},
{0.003,0.1,8,133449},
{0.004,0.1,8,132759},
{0.005,0.1,8,132223},
{0.006,0.1,8,131786},
{0.007,0.1,8,131416},
{0.008,0.1,8,131095},
{0.009,0.1,8,130812},
{0.01,0.1,8,130560}};
    
        public static double[][] T10I4Paras = {{0.005,0.05,8,441971},
{0.005,0.06,8,306995},
{0.005,0.07,8,225600},
{0.005,0.08,8,172766},
{0.005,0.09,8,136539},
{0.005,0.1,8,110623},
{0.005,0.1,8,110623},
{0.005,0.1,16,112287},
{0.005,0.1,24,113260},
{0.005,0.1,32,113950},
{0.005,0.1,40,114486},
{0.001,0.1,8,114486},
{0.002,0.1,8,112822},
{0.003,0.1,8,111849},
{0.004,0.1,8,111159},
{0.005,0.1,8,110623},
{0.006,0.1,8,110186},
{0.007,0.1,8,109816},
{0.008,0.1,8,109495},
{0.009,0.1,8,109212},
{0.01,0.1,8,108960}}; 
    
        public static void saveRuntime(String fileName, double[] runtimes) throws IOException{
                File file = new File(fileName);
        if(!file.exists()){
            file.createNewFile();
        }
        fileOperator fo = new fileOperator();
        fo.openWriteFile(fileName);
        for(int i = 0; i < runtimes.length; i++){
            fo.writeFile(runtimes[i]+"");
        }
        fo.closeWriteFile();
    }    
    public static long seed = 1;
    
//======================testing==================================
    public void RunFPGrowth() throws Exception {
        KMVDataSampling();
        ArrayList<Item> singletons = getSingletons();
        Hashtable<String, Integer> itemHashtable = getItemHashtable();
        FPTreeRoot tree = buildFPTree(singletons, itemHashtable, s_KMVDataSourceName);

        FrequentItemSets largeItemSets = new FrequentItemSets((int) N);
        // mine the tree
        FrequentItemset conditionalItems = new FrequentItemset(new ArrayList<Item>(), 0);
        mineKMVTree(tree, largeItemSets, 0, conditionalItems);
    }

//    public void FastRunFPGrowth() throws Exception {
//        KMVDataSampling();
//        ArrayList<Item> singletons = this.getOrderedSingletons();
//        Hashtable<String, Integer> itemHashtable = this.getSortedItemHashtable(singletons);
//        FastBuildFPTree(singletons, itemHashtable, s_KMVDataSourceName);
//    }    

}
